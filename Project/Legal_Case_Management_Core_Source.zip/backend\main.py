from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from routes import cases
from routes import users
from routes import analytics
from routes import entities


app = FastAPI(
    title="Legal Case Management System"
)


# ==================================================
# CORS
# ==================================================

app.add_middleware(
    CORSMiddleware,

    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],

    allow_credentials=True,

    allow_methods=["*"],

    allow_headers=["*"],
)


# ==================================================
# ROUTES
# ==================================================

app.include_router(
    cases.router
)

app.include_router(
    users.router
)

app.include_router(
    analytics.router
)

app.include_router(
    entities.router
)


# ==================================================
# ROOT
# ==================================================

@app.get("/")
def root():

    return {
        "message":
        "Legal Case Management API is working!"
    }