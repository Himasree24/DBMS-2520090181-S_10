package com.legalcase.recordservice.entity;

import jakarta.persistence.*;
import java.time.LocalDate;
import java.time.LocalTime;

@Entity
@Table(name = "hearings")
public class Hearing {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "hearing_id")
    private Integer hearingId;

    @Column(name = "case_id", nullable = false)
    private Integer caseId;

    @Column(name = "judge_id", nullable = false)
    private Integer judgeId;

    @Column(name = "hearing_date")
    private LocalDate hearingDate;

    @Column(name = "hearing_time")
    private LocalTime hearingTime;

    @Column(name = "court_room", length = 50)
    private String courtRoom;

    @Column(name = "purpose", length = 150)
    private String purpose;

    @Column(name = "status", length = 30)
    private String status;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    public Hearing() {
    }

    public Integer getHearingId() {
        return hearingId;
    }

    public void setHearingId(Integer hearingId) {
        this.hearingId = hearingId;
    }

    public Integer getCaseId() {
        return caseId;
    }

    public void setCaseId(Integer caseId) {
        this.caseId = caseId;
    }

    public Integer getJudgeId() {
        return judgeId;
    }

    public void setJudgeId(Integer judgeId) {
        this.judgeId = judgeId;
    }

    public LocalDate getHearingDate() {
        return hearingDate;
    }

    public void setHearingDate(LocalDate hearingDate) {
        this.hearingDate = hearingDate;
    }

    public LocalTime getHearingTime() {
        return hearingTime;
    }

    public void setHearingTime(LocalTime hearingTime) {
        this.hearingTime = hearingTime;
    }

    public String getCourtRoom() {
        return courtRoom;
    }

    public void setCourtRoom(String courtRoom) {
        this.courtRoom = courtRoom;
    }

    public String getPurpose() {
        return purpose;
    }

    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
