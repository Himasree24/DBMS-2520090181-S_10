package com.legalcase.user.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class UserHealthController {

    @GetMapping("/users/health")
    public Map<String, String> health() {
        return Map.of(
            "service", "user-service",
            "status", "UP"
        );
    }
}
