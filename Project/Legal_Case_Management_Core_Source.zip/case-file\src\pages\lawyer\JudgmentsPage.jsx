import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SearchBar from '../../components/ui/SearchBar.jsx';
import FilterDropdown from '../../components/ui/FilterDropdown.jsx';
import StatusBadge from '../../components/ui/StatusBadge.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function JudgmentsPage() {
  const navigate = useNavigate();
  const { judgmentsList, casesList, judgmentsLoading } = useApp();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [outcome, setOutcome] = useState('');

  const rows = useMemo(() => {
    return judgmentsList
      .map((j) => {
        const c = casesList.find((cs) => cs.dbId === j.case_id);
        return { ...j, caseTitle: c?.title, caseNumber: c?.id };
      })
      .filter((j) => {
        const s = search.toLowerCase();
        const matchesText = (j.caseNumber || '').toLowerCase().includes(s) || (j.caseTitle || '').toLowerCase().includes(s) || (j.decision || '').toLowerCase().includes(s);
        const matchesStatus = !status || j.decision === status;
        const matchesOutcome = !outcome || j.decision === outcome;
        return matchesText && matchesStatus && matchesOutcome;
      });
  }, [judgmentsList, casesList, search, status, outcome]);

  if (judgmentsLoading) {
    return (
      <div className="page">
        <div className="page-header">
          <h1>Judgments</h1>
          <div className="subtitle">Loading judgments...</div>
        </div>
        <div className="empty-state">Loading judgments...</div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Judgments</h1>
        <div className="subtitle">Outcomes and verdicts across your cases.</div>
      </div>

      <div className="toolbar">
        <SearchBar value={search} onChange={setSearch} placeholder="Search judgments..." />
        <FilterDropdown label="Status" value={status} onChange={setStatus} options={['Pending', 'Delivered']} />
        <FilterDropdown label="Outcome" value={outcome} onChange={setOutcome} options={['Pending', 'Case Won', 'Case Lost', 'Partially Resolved', 'Guilty', 'Not Guilty']} />
      </div>

      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Case ID</th>
              <th>Case Title</th>
              <th>Judgment Date</th>
              <th>Decision</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((j) => (
              <tr key={j.judgment_id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/lawyer/cases/${j.caseNumber}`)}>
                <td className="cell-tight">{j.caseNumber || j.case_id}</td>
                <td style={{ fontWeight: 500 }}>{j.caseTitle}</td>
                <td className="cell-tight">{j.judgment_date || '—'}</td>
                <td><StatusBadge status={j.decision} /></td>
                <td><StatusBadge status={j.decision === 'Pending' ? 'Pending' : 'Delivered'} /></td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={5}><div className="empty-state"><h4>No judgments found</h4></div></td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
