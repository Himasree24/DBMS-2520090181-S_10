import React, {
  createContext,
  useContext,
  useState,
  useCallback,
  useEffect,
} from "react";

import {
  getCases,
  createCase as createCaseAPI,
  updateCase as updateCaseAPI,
  deleteCase as deleteCaseAPI,
  loginUser,
  getAnalytics,
  getStoredUser,
  storeUser,
  clearUser,
  getClients,
  getLawyers,
  getHearings,
  createHearing as createHearingAPI,
  updateHearing as updateHearingAPI,
  deleteHearing as deleteHearingAPI,
  getDocuments,
  createDocument as createDocumentAPI,
  updateDocument as updateDocumentAPI,
  deleteDocument as deleteDocumentAPI,
  getJudgments,
  createJudgment as createJudgmentAPI,
  updateJudgment as updateJudgmentAPI,
  deleteJudgment as deleteJudgmentAPI,
} from "../api.js";


const AppContext = createContext(null);

let toastId = 0;

const ROLE_KEY = "casefile_role";


// ==================================================
// CONVERT DATABASE CASE -> FRONTEND CASE
// ==================================================

function formatCase(c) {

  // Support both camelCase (from Spring Boot microservices) and snake_case (from FastAPI)
  const caseId = c.caseId ?? c.case_id;
  const caseNumber = c.caseNumber ?? c.case_number ?? "";
  const caseType = c.caseType ?? c.case_type ?? "";
  const clientId = c.clientId ?? c.client_id;
  const lawyerId = c.lawyerId ?? c.lawyer_id;
  const courtName = c.courtName ?? c.court_name ?? "";
  const filingDate = c.filingDate ?? c.filing_date ?? "";

  return {
    id: caseNumber || `CASE-${caseId}`,

    dbId: caseId,

    caseNumber: caseNumber,

    title: c.title || "",

    type: caseType,

    clientId: String(clientId),

    lawyerId: String(lawyerId),

    court: courtName,

    filingDate: filingDate,

    description: c.description || "",

    status: c.status || "",

    nextHearing: null,
  };
}


// ==================================================
// CONVERT DATABASE HEARING -> FRONTEND HEARING
// ==================================================

function formatHearing(h) {
  return {
    hearing_id: h.hearingId ?? h.hearing_id,
    case_id: h.caseId ?? h.case_id,
    judge_id: h.judgeId ?? h.judge_id,
    hearing_date: h.hearingDate ?? h.hearing_date ?? "",
    hearing_time: h.hearingTime ?? h.hearing_time ?? "",
    court_room: h.courtRoom ?? h.court_room ?? "",
    purpose: h.purpose ?? "",
    status: h.status ?? "",
    remarks: h.remarks ?? "",
  };
}


// ==================================================
// CONVERT DATABASE DOCUMENT -> FRONTEND DOCUMENT
// ==================================================

function formatDocument(d) {
  return {
    document_id: d.documentId ?? d.document_id,
    case_id: d.caseId ?? d.case_id,
    document_name: d.documentName ?? d.document_name ?? "",
    document_type: d.documentType ?? d.document_type ?? "",
    uploaded_by: d.uploadedBy ?? d.uploaded_by ?? null,
    upload_date: d.uploadDate ?? d.upload_date ?? "",
    file_path: d.filePath ?? d.file_path ?? "",
  };
}


// ==================================================
// CONVERT DATABASE JUDGMENT -> FRONTEND JUDGMENT
// ==================================================

function formatJudgment(j) {
  return {
    judgment_id: j.judgmentId ?? j.judgment_id,
    case_id: j.caseId ?? j.case_id,
    judgment_date: j.judgmentDate ?? j.judgment_date ?? "",
    decision: j.decision ?? "",
    summary: j.summary ?? "",
    remarks: j.remarks ?? "",
  };
}


// ==================================================
// APP PROVIDER
// ==================================================

export function AppProvider({ children }) {

  // ------------------------------------------------
  // ROLE (derived from authenticated user)
  // ------------------------------------------------

  const [user, setUser] = useState(() => {
    return getStoredUser();
  });

  const role = user?.role || null;


  // ------------------------------------------------
  // TOASTS
  // ------------------------------------------------

  const [toasts, setToasts] = useState([]);


  // ------------------------------------------------
  // CASES
  // ------------------------------------------------

  const [casesList, setCasesList] = useState([]);

  const [casesLoading, setCasesLoading] =
    useState(true);


  // ------------------------------------------------
  // HEARINGS
  // ------------------------------------------------

  const [hearingsList, setHearingsList] = useState([]);

  const [hearingsLoading, setHearingsLoading] = useState(true);


  // ------------------------------------------------
  // DOCUMENTS
  // ------------------------------------------------

  const [documentsList, setDocumentsList] = useState([]);

  const [documentsLoading, setDocumentsLoading] = useState(true);


  // ------------------------------------------------
  // JUDGMENTS
  // ------------------------------------------------

  const [judgmentsList, setJudgmentsList] = useState([]);

  const [judgmentsLoading, setJudgmentsLoading] = useState(true);


  // ------------------------------------------------
  // CLIENTS & LAWYERS
  // ------------------------------------------------

  const [clientsList, setClientsList] = useState([]);
  const [lawyersList, setLawyersList] = useState([]);


  // ------------------------------------------------
  // ANALYTICS
  // ------------------------------------------------

  const [analyticsData, setAnalyticsData] = useState(null);
  const [analyticsLoading, setAnalyticsLoading] = useState(false);
  const [analyticsError, setAnalyticsError] = useState(null);


  // ------------------------------------------------
  // PROFILE (derived from authenticated user)
  // ------------------------------------------------

  const [profile, setProfile] = useState(() => {
    const stored = getStoredUser();
    if (!stored) return { lawyer: {}, client: {} };
    return {
      lawyer: {
        id: stored.lawyer_id ? String(stored.lawyer_id) : "",
        name: stored.full_name || "",
        email: stored.email || "",
        phone: stored.phone || "",
        role: "Lawyer",
        specialization: "",
        initials: getInitials(stored.full_name),
      },
      client: {
        id: stored.client_id ? String(stored.client_id) : "",
        name: stored.full_name || "",
        email: stored.email || "",
        phone: stored.phone || "",
        role: "Client",
        address: "",
        initials: getInitials(stored.full_name),
      },
    };
  });


  // ------------------------------------------------
  // HELPER
  // ------------------------------------------------

  function getInitials(name) {
    if (!name) return "";
    return name
      .split(" ")
      .map((w) => w[0])
      .join("")
      .toUpperCase()
      .slice(0, 2);
  }


  // ==================================================
  // TOAST
  // ==================================================

  const pushToast = useCallback(
    (message, type = "success") => {

      const id = ++toastId;

      setToasts((prev) => [
        ...prev,
        {
          id,
          message,
          type
        }
      ]);

      setTimeout(() => {

        setToasts((prev) =>
          prev.filter(
            (toast) => toast.id !== id
          )
        );

      }, 3200);

    },
    []
  );


  // ==================================================
  // LOAD CASES FROM DATABASE
  // ==================================================

  const loadCases = useCallback(
    async () => {

      if (!getStoredUser()) {
        setCasesList([]);
        setCasesLoading(false);
        return [];
      }

      setCasesLoading(true);

      try {

        const data = await getCases();

        const formattedCases =
          data.map(formatCase);

        setCasesList(formattedCases);

        return formattedCases;

      } catch (error) {

        console.error(
          "DATABASE CONNECTION ERROR:",
          error
        );

        setCasesList([]);

        throw error;

      } finally {

        setCasesLoading(false);
      }

    },
    []
  );


  // ==================================================
  // LOAD HEARINGS FROM DATABASE
  // ==================================================

  const loadHearings = useCallback(
    async () => {

      if (!getStoredUser()) {
        setHearingsList([]);
        setHearingsLoading(false);
        return [];
      }

      setHearingsLoading(true);

      try {
        const data = await getHearings();
        const formatted = data.map(formatHearing);
        setHearingsList(formatted);
        return formatted;
      } catch (error) {
        console.error("HEARINGS FETCH ERROR:", error);
        setHearingsList([]);
        throw error;
      } finally {
        setHearingsLoading(false);
      }
    },
    []
  );


  // ==================================================
  // LOAD DOCUMENTS FROM DATABASE
  // ==================================================

  const loadDocuments = useCallback(
    async () => {

      if (!getStoredUser()) {
        setDocumentsList([]);
        setDocumentsLoading(false);
        return [];
      }

      setDocumentsLoading(true);

      try {
        const data = await getDocuments();
        const formatted = data.map(formatDocument);
        setDocumentsList(formatted);
        return formatted;
      } catch (error) {
        console.error("DOCUMENTS FETCH ERROR:", error);
        setDocumentsList([]);
        throw error;
      } finally {
        setDocumentsLoading(false);
      }
    },
    []
  );


  // ==================================================
  // LOAD JUDGMENTS FROM DATABASE
  // ==================================================

  const loadJudgments = useCallback(
    async () => {

      if (!getStoredUser()) {
        setJudgmentsList([]);
        setJudgmentsLoading(false);
        return [];
      }

      setJudgmentsLoading(true);

      try {
        const data = await getJudgments();
        const formatted = data.map(formatJudgment);
        setJudgmentsList(formatted);
        return formatted;
      } catch (error) {
        console.error("JUDGMENTS FETCH ERROR:", error);
        setJudgmentsList([]);
        throw error;
      } finally {
        setJudgmentsLoading(false);
      }
    },
    []
  );


  // ==================================================
  // LOAD CLIENTS & LAWYERS FROM DATABASE
  // ==================================================

  const loadClientsAndLawyers = useCallback(
    async () => {

      if (!getStoredUser()) {
        setClientsList([]);
        setLawyersList([]);
        return;
      }

      try {
        const [clients, lawyers] = await Promise.all([
          getClients(),
          getLawyers(),
        ]);
        setClientsList(clients);
        setLawyersList(lawyers);
      } catch (error) {
        console.error("CLIENTS/LAWYERS FETCH ERROR:", error);
      }
    },
    []
  );


  // ==================================================
  // LOAD ANALYTICS FROM DATABASE
  // ==================================================

  const loadAnalytics = useCallback(
    async () => {

      if (!getStoredUser()) {
        setAnalyticsData(null);
        return null;
      }

      setAnalyticsLoading(true);
      setAnalyticsError(null);

      try {

        const data = await getAnalytics();

        setAnalyticsData(data);

        return data;

      } catch (error) {

        console.error(
          "ANALYTICS FETCH ERROR:",
          error
        );

        setAnalyticsError(error.message);

        throw error;

      } finally {

        setAnalyticsLoading(false);
      }

    },
    []
  );


  // ==================================================
  // LOAD ALL DATA WHEN AUTH STATE CHANGES
  // ==================================================

  useEffect(() => {
    if (getStoredUser()) {
      loadCases().catch(() => {});
      loadHearings().catch(() => {});
      loadDocuments().catch(() => {});
      loadJudgments().catch(() => {});
      loadClientsAndLawyers().catch(() => {});
      loadAnalytics().catch(() => {});
    } else {
      setCasesList([]);
      setCasesLoading(false);
      setHearingsList([]);
      setHearingsLoading(false);
      setDocumentsList([]);
      setDocumentsLoading(false);
      setJudgmentsList([]);
      setJudgmentsLoading(false);
      setClientsList([]);
      setLawyersList([]);
      setAnalyticsData(null);
    }
  }, [user, loadCases, loadHearings, loadDocuments, loadJudgments, loadClientsAndLawyers, loadAnalytics]);


  // ==================================================
  // LOGIN
  // ==================================================

  const login = useCallback(
    async (email, password, role) => {

      const data = await loginUser(email, password);

      // Store user data only (no token)
      storeUser({
        user_id: data.user_id,
        full_name: data.full_name,
        email: data.email,
        role: data.role,
        client_id: data.client_id,
        lawyer_id: data.lawyer_id,
        phone: data.phone,
      });

      // Update state
      setUser({
        user_id: data.user_id,
        full_name: data.full_name,
        email: data.email,
        role: data.role,
        client_id: data.client_id,
        lawyer_id: data.lawyer_id,
        phone: data.phone,
      });

      // Also store role in legacy key for compatibility
      try {
        localStorage.setItem(ROLE_KEY, data.role);
      } catch {
        // Ignore
      }

      return data;

    },
    []
  );


  // ==================================================
  // LOGOUT
  // ==================================================

  const logout = useCallback(() => {

    clearUser();
    setUser(null);
    setCasesList([]);
    setHearingsList([]);
    setDocumentsList([]);
    setJudgmentsList([]);
    setClientsList([]);
    setLawyersList([]);
    setAnalyticsData(null);

    try {
      localStorage.removeItem(ROLE_KEY);
    } catch {
      // Ignore localStorage errors
    }

  }, []);


  // ==================================================
  // ADD CASE
  // ==================================================

  const addCase = useCallback(
    async (caseData) => {

      const createdCase =
        await createCaseAPI(caseData);

      const formattedCase =
        formatCase(createdCase);

      setCasesList((prev) => [
        formattedCase,
        ...prev
      ]);

      // Refresh analytics after mutation
      loadAnalytics().catch(() => {});

      return formattedCase;

    },
    [loadAnalytics]
  );


  // ==================================================
  // UPDATE CASE
  // ==================================================

  const updateCase = useCallback(
    async (dbId, caseData) => {

      const updatedCase =
        await updateCaseAPI(
          dbId,
          caseData
        );

      const formattedCase =
        formatCase(updatedCase);

      setCasesList((prev) =>
        prev.map((c) =>
          c.dbId === dbId
            ? formattedCase
            : c
        )
      );

      // Refresh analytics after mutation
      loadAnalytics().catch(() => {});

      return formattedCase;

    },
    [loadAnalytics]
  );


  // ==================================================
  // DELETE CASE
  // ==================================================

  const deleteCase = useCallback(
    async (dbId) => {

      await deleteCaseAPI(dbId);

      setCasesList((prev) =>
        prev.filter(
          (c) => c.dbId !== dbId
        )
      );

      // Refresh analytics after mutation
      loadAnalytics().catch(() => {});

    },
    [loadAnalytics]
  );


  // ==================================================
  // ADD HEARING
  // ==================================================

  const addHearing = useCallback(
    async (hearingData) => {
      const created = await createHearingAPI(hearingData);
      const formatted = formatHearing(created);
      setHearingsList((prev) => [formatted, ...prev]);
      loadAnalytics().catch(() => {});
      return formatted;
    },
    [loadAnalytics]
  );


  // ==================================================
  // UPDATE HEARING
  // ==================================================

  const updateHearingFn = useCallback(
    async (hearingId, hearingData) => {
      const updated = await updateHearingAPI(hearingId, hearingData);
      const formatted = formatHearing(updated);
      setHearingsList((prev) =>
        prev.map((h) => (h.hearing_id === hearingId ? formatted : h))
      );
      loadAnalytics().catch(() => {});
      return formatted;
    },
    [loadAnalytics]
  );


  // ==================================================
  // DELETE HEARING
  // ==================================================

  const deleteHearingFn = useCallback(
    async (hearingId) => {
      await deleteHearingAPI(hearingId);
      setHearingsList((prev) =>
        prev.filter((h) => h.hearing_id !== hearingId)
      );
      loadAnalytics().catch(() => {});
    },
    [loadAnalytics]
  );


  // ==================================================
  // ADD DOCUMENT
  // ==================================================

  const addDocument = useCallback(
    async (docData) => {
      const created = await createDocumentAPI(docData);
      const formatted = formatDocument(created);
      setDocumentsList((prev) => [formatted, ...prev]);
      loadAnalytics().catch(() => {});
      return formatted;
    },
    [loadAnalytics]
  );


  // ==================================================
  // UPDATE DOCUMENT
  // ==================================================

  const updateDocument = useCallback(
    async (documentId, docData) => {
      const updated = await updateDocumentAPI(documentId, docData);
      const formatted = formatDocument(updated);
      setDocumentsList((prev) =>
        prev.map((d) => (d.document_id === documentId ? formatted : d))
      );
      loadAnalytics().catch(() => {});
      return formatted;
    },
    [loadAnalytics]
  );


  // ==================================================
  // DELETE DOCUMENT
  // ==================================================

  const deleteDocument = useCallback(
    async (documentId) => {
      await deleteDocumentAPI(documentId);
      setDocumentsList((prev) =>
        prev.filter((d) => d.document_id !== documentId)
      );
      loadAnalytics().catch(() => {});
    },
    [loadAnalytics]
  );


  // ==================================================
  // ADD JUDGMENT
  // ==================================================

  const addJudgment = useCallback(
    async (judgmentData) => {
      const created = await createJudgmentAPI(judgmentData);
      const formatted = formatJudgment(created);
      setJudgmentsList((prev) => [formatted, ...prev]);
      loadAnalytics().catch(() => {});
      return formatted;
    },
    [loadAnalytics]
  );


  // ==================================================
  // UPDATE JUDGMENT
  // ==================================================

  const updateJudgment = useCallback(
    async (judgmentId, judgmentData) => {
      const updated = await updateJudgmentAPI(judgmentId, judgmentData);
      const formatted = formatJudgment(updated);
      setJudgmentsList((prev) =>
        prev.map((j) => (j.judgment_id === judgmentId ? formatted : j))
      );
      loadAnalytics().catch(() => {});
      return formatted;
    },
    [loadAnalytics]
  );


  // ==================================================
  // DELETE JUDGMENT
  // ==================================================

  const deleteJudgment = useCallback(
    async (judgmentId) => {
      await deleteJudgmentAPI(judgmentId);
      setJudgmentsList((prev) =>
        prev.filter((j) => j.judgment_id !== judgmentId)
      );
      loadAnalytics().catch(() => {});
    },
    [loadAnalytics]
  );


  // ==================================================
  // UPDATE PROFILE
  // ==================================================

  const updateProfile = useCallback(
    (role, updates) => {

      setProfile((prev) => ({
        ...prev,

        [role]: {
          ...prev[role],
          ...updates
        }
      }));

      // Also update user in localStorage
      setUser((prevUser) => {
        if (!prevUser) return prevUser;
        const updated = { ...prevUser, ...updates };
        storeUser(updated);
        return updated;
      });

    },
    []
  );


  // ==================================================
  // PROVIDER
  // ==================================================

  return (

    <AppContext.Provider
      value={{
        user,
        role,
        login,
        logout,

        toasts,
        pushToast,

        casesList,
        casesLoading,

        loadCases,
        addCase,
        updateCase,
        deleteCase,

        hearingsList,
        hearingsLoading,
        loadHearings,
        addHearing,
        updateHearing: updateHearingFn,
        deleteHearing: deleteHearingFn,

        documentsList,
        documentsLoading,
        loadDocuments,
        addDocument,
        updateDocument,
        deleteDocument,

        judgmentsList,
        judgmentsLoading,
        loadJudgments,
        addJudgment,
        updateJudgment,
        deleteJudgment,

        clientsList,
        lawyersList,
        loadClientsAndLawyers,

        analyticsData,
        analyticsLoading,
        analyticsError,
        loadAnalytics,

        profile,
        updateProfile,
      }}
    >

      {children}

    </AppContext.Provider>

  );

}


// ==================================================
// HOOK
// ==================================================

export function useApp() {

  return useContext(AppContext);

}
