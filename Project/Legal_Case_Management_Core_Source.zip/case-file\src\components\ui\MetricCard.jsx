import React from 'react';

export default function MetricCard({ icon, label, value, info, tone = 'navy', infoTone, onClick }) {
  const Comp = onClick ? 'button' : 'div';
  return (
    <Comp
      className={`metric-card ${onClick ? 'clickable' : ''}`}
      onClick={onClick}
      type={onClick ? 'button' : undefined}
    >
      <div className={`metric-icon ${tone}`}>{icon}</div>
      <div>
        <div className="metric-value">{value}</div>
        <div className="metric-label">{label}</div>
        {info && (
          <div className="metric-info">
            <span className={infoTone === 'up' ? 'up' : infoTone === 'down' ? 'down' : ''}>{info}</span>
          </div>
        )}
      </div>
    </Comp>
  );
}