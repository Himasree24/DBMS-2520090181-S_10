package com.legalcase.recordservice.repository;

import com.legalcase.recordservice.entity.Judgment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface JudgmentRepository extends JpaRepository<Judgment, Integer> {
    List<Judgment> findByCaseId(Integer caseId);
    List<Judgment> findByDecision(String decision);
}
