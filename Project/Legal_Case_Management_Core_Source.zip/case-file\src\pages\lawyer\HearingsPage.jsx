import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SearchBar from '../../components/ui/SearchBar.jsx';
import FilterDropdown from '../../components/ui/FilterDropdown.jsx';
import StatusBadge from '../../components/ui/StatusBadge.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function HearingsPage() {
  const navigate = useNavigate();
  const { hearingsList, casesList, hearingsLoading } = useApp();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('');
  const [tab, setTab] = useState('Upcoming');

  const filterHearings = useMemo(() => {
    let list = hearingsList.filter((h) => {
      const c = casesList.find((cs) => cs.dbId === h.case_id);
      const s = search.toLowerCase();
      const matchesText =
        (c?.id || '').toLowerCase().includes(s) ||
        (c?.title || '').toLowerCase().includes(s) ||
        (h.court_room || '').toLowerCase().includes(s) ||
        (h.purpose || '').toLowerCase().includes(s);
      const matchesStatus = !status || h.status === status;
      const matchesTab = !tab || h.status === tab;
      return matchesText && matchesStatus && matchesTab;
    });
    return list;
  }, [hearingsList, casesList, search, status, tab]);

  const tabs = ['Upcoming', 'Completed', 'Postponed'];

  if (hearingsLoading) {
    return (
      <div className="page">
        <div className="page-header">
          <h1>Hearings</h1>
          <div className="subtitle">Loading hearings...</div>
        </div>
        <div className="empty-state">Loading hearings...</div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Hearings</h1>
        <div className="subtitle">Track your scheduled and completed court hearings.</div>
      </div>

      <div className="tabs">
        {tabs.map((t) => (
          <button key={t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>
            {t}
          </button>
        ))}
      </div>

      <div className="toolbar">
        <SearchBar value={search} onChange={setSearch} placeholder="Search hearings..." />
        <FilterDropdown label="Status" value={status} onChange={setStatus} options={['Upcoming', 'Completed', 'Postponed']} />
      </div>

      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Case ID</th>
              <th>Case</th>
              <th>Court</th>
              <th>Date</th>
              <th>Time</th>
              <th>Purpose</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {filterHearings.map((h) => {
              const c = casesList.find((cs) => cs.dbId === h.case_id);
              return (
                <tr key={h.hearing_id}>
                  <td className="cell-tight"><button className="link-cell" onClick={() => navigate(`/lawyer/cases/${c?.id}`)}>{c?.id || h.case_id}</button></td>
                  <td>{c?.title || '—'}</td>
                  <td className="cell-muted">{h.court_room || '—'}</td>
                  <td className="cell-tight">{h.hearing_date || '—'}</td>
                  <td className="cell-tight">{h.hearing_time || '—'}</td>
                  <td>{h.purpose || '—'}</td>
                  <td><StatusBadge status={h.status} /></td>
                </tr>
              );
            })}
            {filterHearings.length === 0 && (
              <tr><td colSpan={7}><div className="empty-state"><h4>No hearings found</h4><p>Try adjusting your search or filters.</p></div></td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
