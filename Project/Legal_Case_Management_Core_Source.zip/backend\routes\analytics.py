from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, extract

from database import get_db
from models import Case, Hearing, Document, Judgment, Client
from auth import get_current_user


router = APIRouter(
    prefix="/analytics",
    tags=["Analytics"]
)

MONTH_NAMES = [
    "Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
]


# ==================================================
# OVERVIEW — All analytics in one endpoint
# ==================================================

@router.get("/overview")
def get_analytics_overview(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    # Determine case filter based on role
    case_filter = None
    if current_user.role == "client":
        client = db.query(Client).filter(
            Client.user_id == current_user.user_id
        ).first()
        if not client:
            return {
                "total_cases": 0,
                "active_cases": 0,
                "pending_cases": 0,
                "closed_cases": 0,
                "total_hearings": 0,
                "total_documents": 0,
                "total_judgments": 0,
                "cases_by_status": [],
                "cases_by_type": [],
                "cases_by_month": [],
                "hearings_by_month": [],
                "hearings_by_status": [],
                "documents_by_type": [],
                "documents_by_case": [],
                "judgments_by_decision": [],
            }
        case_filter = Case.client_id == client.client_id

    def apply_filter(query):
        if case_filter is not None:
            query = query.filter(case_filter)
        return query

    # ---- Case counts ----
    total_cases = apply_filter(db.query(func.count(Case.case_id))).scalar() or 0
    active_cases = apply_filter(db.query(func.count(Case.case_id))).filter(Case.status == "Active").scalar() or 0
    pending_cases = apply_filter(db.query(func.count(Case.case_id))).filter(Case.status == "Pending").scalar() or 0
    closed_cases = apply_filter(db.query(func.count(Case.case_id))).filter(Case.status == "Closed").scalar() or 0

    # ---- Cases by status ----
    status_rows = apply_filter(db.query(
        Case.status, func.count(Case.case_id)
    )).group_by(Case.status).all()
    cases_by_status = [
        {"name": row[0], "value": row[1]} for row in status_rows
    ]

    # ---- Cases by type ----
    type_rows = apply_filter(db.query(
        Case.case_type, func.count(Case.case_id)
    )).group_by(Case.case_type).all()
    cases_by_type = [
        {"name": row[0], "value": row[1]} for row in type_rows
    ]

    # ---- Cases by month ----
    month_rows = apply_filter(db.query(
        extract("month", Case.filing_date),
        func.count(Case.case_id)
    )).group_by(
        extract("month", Case.filing_date)
    ).all()
    cases_by_month = [
        {"month": MONTH_NAMES[int(row[0]) - 1], "cases": row[1]}
        for row in month_rows if row[0] is not None
    ]

    # Get relevant case IDs for hearings/documents/judgments
    if case_filter is not None:
        relevant_case_ids = [
            c.case_id for c in db.query(Case).filter(case_filter).all()
        ]
    else:
        relevant_case_ids = [c.case_id for c in db.query(Case).all()]

    # ---- Hearing counts ----
    hearing_query = db.query(Hearing)
    if relevant_case_ids:
        hearing_query = hearing_query.filter(Hearing.case_id.in_(relevant_case_ids))
    total_hearings = hearing_query.count() or 0

    # ---- Hearings by month ----
    hearing_month_query = db.query(
        extract("month", Hearing.hearing_date),
        func.count(Hearing.hearing_id)
    )
    if relevant_case_ids:
        hearing_month_query = hearing_month_query.filter(Hearing.case_id.in_(relevant_case_ids))
    hearing_month_rows = hearing_month_query.group_by(
        extract("month", Hearing.hearing_date)
    ).all()
    hearings_by_month = [
        {"month": MONTH_NAMES[int(row[0]) - 1], "hearings": row[1]}
        for row in hearing_month_rows if row[0] is not None
    ]

    # ---- Hearings by status ----
    hearing_status_query = db.query(
        Hearing.status, func.count(Hearing.hearing_id)
    )
    if relevant_case_ids:
        hearing_status_query = hearing_status_query.filter(Hearing.case_id.in_(relevant_case_ids))
    hearing_status_rows = hearing_status_query.group_by(
        Hearing.status
    ).all()
    hearings_by_status = [
        {"name": row[0], "value": row[1]} for row in hearing_status_rows
    ]

    # ---- Document counts ----
    doc_query = db.query(Document)
    if relevant_case_ids:
        doc_query = doc_query.filter(Document.case_id.in_(relevant_case_ids))
    total_documents = doc_query.count() or 0

    # ---- Documents by type ----
    doc_type_query = db.query(
        Document.document_type, func.count(Document.document_id)
    )
    if relevant_case_ids:
        doc_type_query = doc_type_query.filter(Document.case_id.in_(relevant_case_ids))
    doc_type_rows = doc_type_query.group_by(
        Document.document_type
    ).all()
    documents_by_type = [
        {"name": row[0], "value": row[1]} for row in doc_type_rows
    ]

    # ---- Documents by case ----
    doc_case_query = db.query(
        Document.case_id, func.count(Document.document_id)
    )
    if relevant_case_ids:
        doc_case_query = doc_case_query.filter(Document.case_id.in_(relevant_case_ids))
    doc_case_rows = doc_case_query.group_by(Document.case_id).all()

    # Get case numbers for display
    case_ids = [row[0] for row in doc_case_rows]
    case_number_map = {}
    if case_ids:
        case_number_rows = db.query(
            Case.case_id, Case.case_number
        ).filter(Case.case_id.in_(case_ids)).all()
        case_number_map = {row[0]: row[1] for row in case_number_rows}

    documents_by_case = [
        {
            "caseId": case_number_map.get(row[0], f"Case {row[0]}"),
            "count": row[1]
        }
        for row in doc_case_rows
    ]

    # ---- Judgment counts ----
    judgment_query = db.query(Judgment)
    if relevant_case_ids:
        judgment_query = judgment_query.filter(Judgment.case_id.in_(relevant_case_ids))
    total_judgments = judgment_query.count() or 0

    # ---- Judgments by decision ----
    judgment_decision_query = db.query(
        Judgment.decision, func.count(Judgment.judgment_id)
    )
    if relevant_case_ids:
        judgment_decision_query = judgment_decision_query.filter(Judgment.case_id.in_(relevant_case_ids))
    judgment_decision_rows = judgment_decision_query.group_by(
        Judgment.decision
    ).all()
    judgments_by_decision = [
        {"name": row[0], "value": row[1]} for row in judgment_decision_rows
    ]

    return {
        "total_cases": total_cases,
        "active_cases": active_cases,
        "pending_cases": pending_cases,
        "closed_cases": closed_cases,
        "total_hearings": total_hearings,
        "total_documents": total_documents,
        "total_judgments": total_judgments,
        "cases_by_status": cases_by_status,
        "cases_by_type": cases_by_type,
        "cases_by_month": cases_by_month,
        "hearings_by_month": hearings_by_month,
        "hearings_by_status": hearings_by_status,
        "documents_by_type": documents_by_type,
        "documents_by_case": documents_by_case,
        "judgments_by_decision": judgments_by_decision,
    }
