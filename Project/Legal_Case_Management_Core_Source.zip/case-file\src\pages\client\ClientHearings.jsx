import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { CalendarDays } from 'lucide-react';
import StatusBadge from '../../components/ui/StatusBadge.jsx';
import SearchBar from '../../components/ui/SearchBar.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function ClientHearings() {
  const navigate = useNavigate();
  const { casesList, hearingsList, user, hearingsLoading } = useApp();
  const [tab, setTab] = useState('Upcoming');
  const [search, setSearch] = useState('');

  const clientId = user?.client_id ? String(user.client_id) : null;

  const myHearings = useMemo(() => {
    const myCases = clientId
      ? casesList.filter((c) => c.clientId === clientId)
      : [];
    const ids = new Set(myCases.map((c) => c.id));
    const s = search.toLowerCase();
    return hearingsList
      .filter((h) => {
        const c = casesList.find((cs) => cs.dbId === h.case_id);
        return c && ids.has(c.id);
      })
      .filter((h) => h.status === tab || (tab === 'Upcoming' && h.status === 'Scheduled'))
      .filter((h) => {
        const c = casesList.find((cs) => cs.dbId === h.case_id);
        return (
          (c?.id || '').toLowerCase().includes(s) ||
          (c?.title || '').toLowerCase().includes(s) ||
          (h.court_room || '').toLowerCase().includes(s) ||
          (h.purpose || '').toLowerCase().includes(s)
        );
      });
  }, [casesList, hearingsList, tab, search, clientId]);

  const tabs = ['Upcoming', 'Completed', 'Postponed'];

  if (hearingsLoading) {
    return (
      <div className="page">
        <div className="page-header">
          <h1>Hearings</h1>
          <div className="subtitle">Loading hearings...</div>
        </div>
        <div className="empty-state">Loading hearings...</div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Hearings</h1>
        <div className="subtitle">Your scheduled and past court hearings.</div>
      </div>

      <div className="tabs">
        {tabs.map((t) => (
          <button key={t} className={`tab ${tab === t ? 'active' : ''}`} onClick={() => setTab(t)}>{t}</button>
        ))}
      </div>

      <div className="toolbar">
        <SearchBar value={search} onChange={setSearch} placeholder="Search hearings..." />
      </div>

      {myHearings.length === 0 ? (
        <div className="card empty-state">
          <CalendarDays size={40} />
          <h4>No {tab.toLowerCase()} hearings</h4>
          <p>There are no {tab.toLowerCase()} hearings for your cases.</p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {myHearings.map((h) => {
            const c = casesList.find((cs) => cs.dbId === h.case_id);
            return (
              <div
                className="case-card clickable-row"
                key={h.hearing_id}
                onClick={() => c && navigate(`/client/cases/${c.id}`)}
              >
                <div className="case-card-head">
                  <div>
                    <span className="case-id-chip">{c?.id || h.case_id}</span>
                    <span className="case-title" style={{ fontFamily: 'var(--font-serif)', fontSize: 17, marginLeft: 12 }}>{c?.title}</span>
                  </div>
                  <StatusBadge status={h.status} />
                </div>
                <div className="case-meta">
                  <div className="case-meta-item">
                    <div className="label">Date</div>
                    <div className="value">{h.hearing_date}</div>
                  </div>
                  <div className="case-meta-item">
                    <div className="label">Time</div>
                    <div className="value">{h.hearing_time}</div>
                  </div>
                  <div className="case-meta-item">
                    <div className="label">Court</div>
                    <div className="value">{h.court_room}</div>
                  </div>
                  <div className="case-meta-item">
                    <div className="label">Purpose</div>
                    <div className="value">{h.purpose}</div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
