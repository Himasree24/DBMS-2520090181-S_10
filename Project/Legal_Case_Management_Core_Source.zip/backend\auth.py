import secrets
from fastapi import Depends, HTTPException, Header
from sqlalchemy.orm import Session

from database import get_db
from models import User

# ==================================================
# TOKENLESS SESSION-BASED AUTHENTICATION
# ==================================================
# Simple server-side session store.
# Maps session_token -> user_id
# No JWT, no Bearer tokens.

active_sessions: dict[str, int] = {}


def create_session(user_id: int) -> str:
    """Create a new session for a user and return the session token."""
    token = secrets.token_urlsafe(32)
    active_sessions[token] = user_id
    return token


def destroy_session(token: str) -> None:
    """Remove a session (logout)."""
    active_sessions.pop(token, None)


def get_current_user(
    x_session_token: str = Header(None, alias="X-Session-Token"),
    db: Session = Depends(get_db),
) -> User:
    """
    Dependency that validates the session token and returns the current user.
    Reads the token from the X-Session-Token header.
    """
    if not x_session_token:
        raise HTTPException(
            status_code=401,
            detail="Not authenticated",
        )

    user_id = active_sessions.get(x_session_token)

    if not user_id:
        raise HTTPException(
            status_code=401,
            detail="Invalid or expired session",
        )

    user = db.query(User).filter(User.user_id == user_id).first()

    if not user:
        raise HTTPException(
            status_code=401,
            detail="User not found",
        )

    return user


def require_role(required_role: str):
    """Dependency factory that checks the user's role."""
    def role_checker(
        current_user: User = Depends(get_current_user),
    ) -> User:
        if current_user.role != required_role:
            raise HTTPException(
                status_code=403,
                detail=f"Access denied. Required role: {required_role}",
            )
        return current_user

    return role_checker
