package com.legalcase.user.dto;

import java.time.LocalDateTime;

public class ClientResponse {

    private Integer clientId;
    private Integer userId;
    private String fullName;
    private String email;
    private String address;
    private String phone;
    private LocalDateTime createdAt;

    public ClientResponse() {
    }

    public ClientResponse(Integer clientId, Integer userId, String fullName, String email,
                          String address, String phone, LocalDateTime createdAt) {
        this.clientId = clientId;
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.address = address;
        this.phone = phone;
        this.createdAt = createdAt;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }
}
