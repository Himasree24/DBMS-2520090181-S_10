package com.legalcase.recordservice.service;

import com.legalcase.recordservice.client.CaseServiceClient;
import com.legalcase.recordservice.dto.HearingCreateRequest;
import com.legalcase.recordservice.dto.HearingResponse;
import com.legalcase.recordservice.dto.HearingUpdateRequest;
import com.legalcase.recordservice.entity.Hearing;
import com.legalcase.recordservice.repository.HearingRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class HearingService {

    private final HearingRepository hearingRepository;
    private final CaseServiceClient caseServiceClient;

    public HearingService(HearingRepository hearingRepository,
                          CaseServiceClient caseServiceClient) {
        this.hearingRepository = hearingRepository;
        this.caseServiceClient = caseServiceClient;
    }

    public List<HearingResponse> getAllHearings() {
        return hearingRepository.findAll().stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    public HearingResponse getHearingById(Integer id) {
        Hearing hearing = hearingRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Hearing not found with id: " + id));
        return toResponse(hearing);
    }

    public List<HearingResponse> getHearingsByCaseId(Integer caseId) {
        return hearingRepository.findByCaseId(caseId).stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    @Transactional
    public HearingResponse createHearing(HearingCreateRequest request) {
        // Validate case exists via Case Service
        if (!caseServiceClient.getCaseById(request.getCaseId()).containsKey("caseId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Case not found with id: " + request.getCaseId());
        }

        Hearing hearing = new Hearing();
        hearing.setCaseId(request.getCaseId());
        hearing.setJudgeId(request.getJudgeId());
        hearing.setHearingDate(request.getHearingDate());
        hearing.setHearingTime(request.getHearingTime());
        hearing.setCourtRoom(request.getCourtRoom());
        hearing.setPurpose(request.getPurpose());
        hearing.setStatus(request.getStatus());
        hearing.setRemarks(request.getRemarks());

        Hearing saved = hearingRepository.save(hearing);
        return toResponse(saved);
    }

    @Transactional
    public HearingResponse updateHearing(Integer id, HearingUpdateRequest request) {
        Hearing hearing = hearingRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Hearing not found with id: " + id));

        // Validate case exists via Case Service
        if (!caseServiceClient.getCaseById(request.getCaseId()).containsKey("caseId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Case not found with id: " + request.getCaseId());
        }

        hearing.setCaseId(request.getCaseId());
        hearing.setJudgeId(request.getJudgeId());
        hearing.setHearingDate(request.getHearingDate());
        hearing.setHearingTime(request.getHearingTime());
        hearing.setCourtRoom(request.getCourtRoom());
        hearing.setPurpose(request.getPurpose());
        hearing.setStatus(request.getStatus());
        hearing.setRemarks(request.getRemarks());

        Hearing updated = hearingRepository.save(hearing);
        return toResponse(updated);
    }

    @Transactional
    public void deleteHearing(Integer id) {
        if (!hearingRepository.existsById(id)) {
            throw new RuntimeException("Hearing not found with id: " + id);
        }
        hearingRepository.deleteById(id);
    }

    private HearingResponse toResponse(Hearing hearing) {
        return new HearingResponse(
            hearing.getHearingId(),
            hearing.getCaseId(),
            hearing.getJudgeId(),
            hearing.getHearingDate(),
            hearing.getHearingTime(),
            hearing.getCourtRoom(),
            hearing.getPurpose(),
            hearing.getStatus(),
            hearing.getRemarks()
        );
    }
}
