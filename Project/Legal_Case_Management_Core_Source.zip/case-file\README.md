# CASE FILE — Legal Case Management & Analytics Portal

A premium, modern legal-tech frontend for a university **Database Management Systems** project (Phase 1: Frontend only).

The system manages **Cases, Clients, Lawyers, Judges, Hearings, Documents and Judgments** with two role-based dashboards — **Lawyer** and **Client**.

## Stack

- **React 19** + **Vite 8**
- **React Router v7** (routing, role-based navigation)
- **Recharts** (charts & analytics)
- **Lucide React** (icons)

## Getting started

```bash
npm install
npm run dev        # start dev server
npm run build      # production build
npm run preview    # preview production build
```

> Note: The workspace path contains an `&` which breaks the `npm.cmd run` script wrapper on Windows PowerShell. If you encounter `'is not recognized'` errors, invoke Vite directly:
>
> ```bash
> node node_modules/vite/bin/vite.js dev
> ```

## Features

- **Role selection / login** — elegant split-screen landing, choose Lawyer or Client
- **Lawyer Dashboard** — metrics, upcoming hearings, case-status donut, hearing-stats line chart, my-cases table
- **Client Dashboard** — simplified metrics, case cards, next-hearing highlight, case timeline
- **Cases** — search, status/type/date filters, sorting, add/edit case modal with validation and toasts
- **Case Details** — hero summary, vertical timeline, hearings, documents, judgment
- **Clients** (lawyer only) — list with search/sort, client detail with associated cases, hearings, documents
- **Hearings** — tabbed by Upcoming / Completed / Postponed
- **Documents** — search, case/type filters, date sort, simulated upload/view/download
- **Judgments** — status/outcome filters
- **Analytics** — metric cards, seven charts, key insights
- **Profile & Settings** — editable profile, notification & interface preferences
- **Notifications & profile dropdowns**, toast notifications
- **Fully responsive** — fixed sidebar (desktop), collapsible (tablet), drawer (mobile), scrollable tables

## Design system

- Palette: `#181931` (navy), `#44174E` (violet), `#662249` (burgundy) as dominant colors, with `#A34054` (crimson), `#ED9E5A` (amber), `#E8C1C1` (blush) as accents
- Typography: **Playfair Display** / **Cormorant Garamond** for headings, **Inter** for UI
- No rainbow charts, no neon, restrained shadows and animations

## Project structure

```
src/
  data/            mock data (cases, clients, lawyers, judges, hearings, documents, judgments) + index helper
  context/         global app state (role, toasts, cases list)
  components/
    layout/        Sidebar, Topbar, Layout
    ui/            reusable components (MetricCard, StatusBadge, Modal, Toast, DataTable-style, SortHeader, ...)
  pages/
    lawyer/        dashboard, cases, clients, hearings, documents, judgments, analytics
    client/        dashboard, cases, hearings, documents
    shared/        case details, profile, settings
  App.jsx          routing
  styles.css       global design system
```

## Phase 2 (backend integration)

Mock data lives isolated under `src/data/` and is consumed through the `helper` utility in `src/data/index.js`. In Phase 2, replace data imports with API calls to endpoints such as `GET /cases`, `GET /clients`, `GET /lawyers`, `GET /judges`, `GET /hearings`, `GET /documents`, `GET /judgments`.

No backend, database, API, authentication or external services are implemented in this phase.