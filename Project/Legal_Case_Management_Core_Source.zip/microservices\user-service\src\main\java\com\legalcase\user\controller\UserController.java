package com.legalcase.user.controller;

import com.legalcase.user.dto.ClientResponse;
import com.legalcase.user.dto.LawyerResponse;
import com.legalcase.user.dto.UserResponse;
import com.legalcase.user.entity.Client;
import com.legalcase.user.entity.Lawyer;
import com.legalcase.user.entity.User;
import com.legalcase.user.repository.ClientRepository;
import com.legalcase.user.repository.LawyerRepository;
import com.legalcase.user.repository.UserRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
public class UserController {

    private final UserRepository userRepository;
    private final ClientRepository clientRepository;
    private final LawyerRepository lawyerRepository;

    public UserController(UserRepository userRepository,
                          ClientRepository clientRepository,
                          LawyerRepository lawyerRepository) {
        this.userRepository = userRepository;
        this.clientRepository = clientRepository;
        this.lawyerRepository = lawyerRepository;
    }

    // --------------------------------------------------
    // USER ENDPOINTS
    // --------------------------------------------------

    @GetMapping("/users")
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream()
            .map(this::toUserResponse)
            .collect(Collectors.toList());
    }

    @GetMapping("/users/{id}")
    public ResponseEntity<UserResponse> getUserById(@PathVariable Integer id) {
        return userRepository.findById(id)
            .map(user -> ResponseEntity.ok(toUserResponse(user)))
            .orElse(ResponseEntity.notFound().build());
    }

    @GetMapping("/users/email/{email}")
    public ResponseEntity<UserResponse> getUserByEmail(@PathVariable String email) {
        return userRepository.findByEmail(email)
            .map(user -> ResponseEntity.ok(toUserResponse(user)))
            .orElse(ResponseEntity.notFound().build());
    }

    // --------------------------------------------------
    // CLIENT ENDPOINTS
    // --------------------------------------------------

    @GetMapping("/clients")
    public List<ClientResponse> getAllClients() {
        return clientRepository.findAll().stream()
            .map(this::toClientResponse)
            .collect(Collectors.toList());
    }

    @GetMapping("/clients/{id}")
    public ResponseEntity<ClientResponse> getClientById(@PathVariable Integer id) {
        return clientRepository.findById(id)
            .map(client -> ResponseEntity.ok(toClientResponse(client)))
            .orElse(ResponseEntity.notFound().build());
    }

    // --------------------------------------------------
    // LAWYER ENDPOINTS
    // --------------------------------------------------

    @GetMapping("/lawyers")
    public List<LawyerResponse> getAllLawyers() {
        return lawyerRepository.findAll().stream()
            .map(this::toLawyerResponse)
            .collect(Collectors.toList());
    }

    @GetMapping("/lawyers/{id}")
    public ResponseEntity<LawyerResponse> getLawyerById(@PathVariable Integer id) {
        return lawyerRepository.findById(id)
            .map(lawyer -> ResponseEntity.ok(toLawyerResponse(lawyer)))
            .orElse(ResponseEntity.notFound().build());
    }

    // --------------------------------------------------
    // DTO MAPPERS (never expose password)
    // --------------------------------------------------

    private UserResponse toUserResponse(User user) {
        return new UserResponse(
            user.getUserId(),
            user.getFullName(),
            user.getEmail(),
            user.getRole()
        );
    }

    private ClientResponse toClientResponse(Client client) {
        String fullName = client.getUser() != null ? client.getUser().getFullName() : null;
        String email = client.getUser() != null ? client.getUser().getEmail() : null;
        return new ClientResponse(
            client.getClientId(),
            client.getUser() != null ? client.getUser().getUserId() : null,
            fullName,
            email,
            client.getAddress(),
            client.getPhone(),
            client.getCreatedAt()
        );
    }

    private LawyerResponse toLawyerResponse(Lawyer lawyer) {
        String fullName = lawyer.getUser() != null ? lawyer.getUser().getFullName() : null;
        String email = lawyer.getUser() != null ? lawyer.getUser().getEmail() : null;
        return new LawyerResponse(
            lawyer.getLawyerId(),
            lawyer.getUser() != null ? lawyer.getUser().getUserId() : null,
            fullName,
            email,
            lawyer.getBarRegistrationNo(),
            lawyer.getSpecialization(),
            lawyer.getYearsExperience(),
            lawyer.getPhone()
        );
    }
}
