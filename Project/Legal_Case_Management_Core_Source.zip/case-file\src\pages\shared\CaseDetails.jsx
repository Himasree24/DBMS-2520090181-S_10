import React from "react";

import { useParams } from "react-router-dom";

import { useApp }
  from "../../context/AppContext.jsx";

import StatusBadge
  from "../../components/ui/StatusBadge.jsx";


export default function CaseDetails() {

  const { caseId } = useParams();

  const {
    casesList,
    documentsList,
    casesLoading
  } = useApp();


  // ==================================================
  // FIND CASE
  // ==================================================

  const caseItem = casesList.find(
    (c) =>
      String(c.id) === String(caseId)
  );


  // ==================================================
  // LOADING
  // ==================================================

  if (casesLoading) {

    return (

      <div className="page">

        <div className="empty-state">
          Loading case...
        </div>

      </div>

    );

  }


  // ==================================================
  // CASE NOT FOUND
  // ==================================================

  if (!caseItem) {

    return (

      <div className="page">

        <div className="empty-state">

          <h2>
            Case not found
          </h2>

          <p>
            The requested case does not
            exist in the database.
          </p>

        </div>

      </div>

    );

  }


  // ==================================================
  // DOCUMENTS
  // ==================================================

  const caseDocuments =
    documentsList.filter(
      (doc) =>
        String(doc.caseId) ===
        String(caseItem.id)
    );


  return (

    <div className="page">

      {/* ============================================ */}
      {/* HEADER */}
      {/* ============================================ */}

      <div className="page-header">

        <div>

          <h1>
            {caseItem.title}
          </h1>

          <p>
            {caseItem.id}
          </p>

        </div>


        <StatusBadge
          status={caseItem.status}
        />

      </div>


      {/* ============================================ */}
      {/* CASE INFORMATION */}
      {/* ============================================ */}

      <div className="card">

        <div className="card-header">

          <h2>
            Case Information
          </h2>

        </div>


        <div className="details-grid">


          <div className="detail-item">

            <span className="detail-label">
              Case Number
            </span>

            <span className="detail-value">
              {caseItem.id}
            </span>

          </div>


          <div className="detail-item">

            <span className="detail-label">
              Case Type
            </span>

            <span className="detail-value">
              {caseItem.type || "—"}
            </span>

          </div>


          <div className="detail-item">

            <span className="detail-label">
              Client ID
            </span>

            <span className="detail-value">
              {caseItem.clientId}
            </span>

          </div>


          <div className="detail-item">

            <span className="detail-label">
              Lawyer ID
            </span>

            <span className="detail-value">
              {caseItem.lawyerId}
            </span>

          </div>


          <div className="detail-item">

            <span className="detail-label">
              Court
            </span>

            <span className="detail-value">
              {caseItem.court || "—"}
            </span>

          </div>


          <div className="detail-item">

            <span className="detail-label">
              Filing Date
            </span>

            <span className="detail-value">
              {caseItem.filingDate || "—"}
            </span>

          </div>


          <div className="detail-item">

            <span className="detail-label">
              Status
            </span>

            <span className="detail-value">

              <StatusBadge
                status={caseItem.status}
              />

            </span>

          </div>


          <div className="detail-item">

            <span className="detail-label">
              Database ID
            </span>

            <span className="detail-value">
              {caseItem.dbId}
            </span>

          </div>

        </div>

      </div>


      {/* ============================================ */}
      {/* DESCRIPTION */}
      {/* ============================================ */}

      <div className="card">

        <div className="card-header">

          <h2>
            Description
          </h2>

        </div>


        <div className="card-body">

          <p>

            {caseItem.description ||
              "No description available."}

          </p>

        </div>

      </div>


      {/* ============================================ */}
      {/* DOCUMENTS */}
      {/* ============================================ */}

      <div className="card">

        <div className="card-header">

          <h2>
            Documents
          </h2>

        </div>


        {caseDocuments.length === 0 ? (

          <div className="empty-state">

            <p>
              No documents available.
            </p>

          </div>

        ) : (

          <div className="table-container">

            <table className="data-table">

              <thead>

                <tr>

                  <th>
                    Document
                  </th>

                  <th>
                    Type
                  </th>

                </tr>

              </thead>


              <tbody>

                {caseDocuments.map((doc) => (

                  <tr
                    key={doc.id || doc.documentId}
                  >

                    <td>
                      {doc.name ||
                        doc.documentName ||
                        "—"}
                    </td>

                    <td>
                      {doc.type ||
                        doc.documentType ||
                        "—"}
                    </td>

                  </tr>

                ))}

              </tbody>

            </table>

          </div>

        )}

      </div>

    </div>

  );

}