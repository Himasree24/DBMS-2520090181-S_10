import React from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  FolderOpen,
  Users,
  CalendarDays,
  FileText,
  Scale,
  BarChart3,
  User,
  Settings,
  LogOut,
  Gavel,
  ClipboardList,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.jsx';

function NavItem({ to, label, icon, end, badge }) {
  return (
    <NavLink
      to={to}
      end={end}
      className={({ isActive }) => (isActive ? 'nav-link active' : 'nav-link')}
    >
      {icon}
      <span>{label}</span>
      {badge && <span className="nav-badge-count">{badge}</span>}
    </NavLink>
  );
}

export default function Sidebar({ role, open, onClose }) {
  const { logout } = useApp();
  const navigate = useNavigate();
  const location = useLocation();
  const activeStatus =
    new URLSearchParams(location.search).get('status');

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <>
      <div
        className={`backdrop ${open ? 'show' : ''}`}
        onClick={onClose}
      />
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="brand">
          <div className="brand-mark">
            <Gavel size={20} />
          </div>
          <div>
            <div className="brand-name">CASE FILE</div>
            <div className="brand-tag">Legal Management Portal</div>
          </div>
        </div>

        <nav className="nav">
          {role === 'lawyer' ? (
            <>
              <NavItem to="/lawyer/dashboard" label="Dashboard" icon={<LayoutDashboard size={17} />} end />
              <div className="nav-group-label">Cases</div>
              <NavItem to="/lawyer/cases" label="All Cases" icon={<FolderOpen size={17} />} />
              <div className="nav-sub">
                <NavLink to="/lawyer/cases?status=Active" className={`nav-sub-link ${activeStatus === 'Active' ? 'active' : ''}`}>Active Cases</NavLink>
                <NavLink to="/lawyer/cases?status=Pending" className={`nav-sub-link ${activeStatus === 'Pending' ? 'active' : ''}`}>Pending Cases</NavLink>
                <NavLink to="/lawyer/cases?status=Closed" className={`nav-sub-link ${activeStatus === 'Closed' ? 'active' : ''}`}>Closed Cases</NavLink>
              </div>
              <NavItem to="/lawyer/clients" label="Clients" icon={<Users size={17} />} />
              <NavItem to="/lawyer/hearings" label="Hearings" icon={<CalendarDays size={17} />} />
              <NavItem to="/lawyer/documents" label="Documents" icon={<FileText size={17} />} />
              <NavItem to="/lawyer/judgments" label="Judgments" icon={<Scale size={17} />} />
              <NavItem to="/lawyer/analytics" label="Analytics" icon={<BarChart3 size={17} />} />
              <div className="nav-group-label">Account</div>
              <NavItem to="/lawyer/profile" label="Profile" icon={<User size={17} />} />
              <NavItem to="/lawyer/settings" label="Settings" icon={<Settings size={17} />} />
            </>
          ) : (
            <>
              <NavItem to="/client/dashboard" label="Dashboard" icon={<LayoutDashboard size={17} />} end />
              <NavItem to="/client/cases" label="My Cases" icon={<ClipboardList size={17} />} />
              <NavItem to="/client/hearings" label="Hearings" icon={<CalendarDays size={17} />} />
              <NavItem to="/client/documents" label="Documents" icon={<FileText size={17} />} />
              <div className="nav-group-label">Account</div>
              <NavItem to="/client/profile" label="Profile" icon={<User size={17} />} />
              <NavItem to="/client/settings" label="Settings" icon={<Settings size={17} />} />
            </>
          )}
        </nav>

        <div className="sidebar-footer">
          <button className="logout-link" onClick={handleLogout}>
            <LogOut size={17} />
            <span>Logout</span>
          </button>
        </div>
      </aside>
    </>
  );
}
