package com.legalcase.caseservice.controller;

import com.legalcase.caseservice.dto.CaseCreateRequest;
import com.legalcase.caseservice.dto.CaseResponse;
import com.legalcase.caseservice.dto.CaseUpdateRequest;
import com.legalcase.caseservice.dto.CaseWithUsersResponse;
import com.legalcase.caseservice.service.CaseService;
import com.legalcase.caseservice.service.CaseUserAggregationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class CaseController {

    private final CaseService caseService;
    private final CaseUserAggregationService aggregationService;

    public CaseController(CaseService caseService,
                          CaseUserAggregationService aggregationService) {
        this.caseService = caseService;
        this.aggregationService = aggregationService;
    }

    // --------------------------------------------------
    // GET ALL CASES
    // --------------------------------------------------

    @GetMapping("/cases")
    public List<CaseResponse> getAllCases(
            @RequestParam(required = false) Integer clientId,
            @RequestParam(required = false) Integer lawyerId,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String caseType) {

        if (clientId != null) {
            return caseService.getCasesByClientId(clientId);
        }
        if (lawyerId != null) {
            return caseService.getCasesByLawyerId(lawyerId);
        }
        if (status != null) {
            return caseService.getCasesByStatus(status);
        }
        if (caseType != null) {
            return caseService.getCasesByCaseType(caseType);
        }
        return caseService.getAllCases();
    }

    // --------------------------------------------------
    // GET ONE CASE
    // --------------------------------------------------

    @GetMapping("/cases/{id}")
    public ResponseEntity<CaseResponse> getCaseById(@PathVariable Integer id) {
        try {
            CaseResponse caseResponse = caseService.getCaseById(id);
            return ResponseEntity.ok(caseResponse);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // --------------------------------------------------
    // GET CASE WITH USER INFO (Service-to-Service)
    // --------------------------------------------------

    @GetMapping("/cases/{id}/with-users")
    public ResponseEntity<CaseWithUsersResponse> getCaseWithUsers(@PathVariable Integer id) {
        try {
            CaseWithUsersResponse response = aggregationService.getCaseWithUsers(id);
            return ResponseEntity.ok(response);
        } catch (org.springframework.web.server.ResponseStatusException e) {
            return ResponseEntity.status(e.getStatusCode()).build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // --------------------------------------------------
    // CREATE CASE
    // --------------------------------------------------

    @PostMapping("/cases")
    public ResponseEntity<CaseResponse> createCase(@Valid @RequestBody CaseCreateRequest request) {
        CaseResponse created = caseService.createCase(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    // --------------------------------------------------
    // UPDATE CASE
    // --------------------------------------------------

    @PutMapping("/cases/{id}")
    public ResponseEntity<CaseResponse> updateCase(@PathVariable Integer id,
                                                    @Valid @RequestBody CaseUpdateRequest request) {
        try {
            CaseResponse updated = caseService.updateCase(id, request);
            return ResponseEntity.ok(updated);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // --------------------------------------------------
    // DELETE CASE
    // --------------------------------------------------

    @DeleteMapping("/cases/{id}")
    public ResponseEntity<Void> deleteCase(@PathVariable Integer id) {
        try {
            caseService.deleteCase(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
