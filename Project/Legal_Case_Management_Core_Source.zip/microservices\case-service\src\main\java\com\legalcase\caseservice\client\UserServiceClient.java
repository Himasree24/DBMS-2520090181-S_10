package com.legalcase.caseservice.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatusCode;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.Map;

/**
 * HTTP client for Case Service to communicate with User Service.
 * All calls go through REST APIs - no direct database access.
 */
@Component
public class UserServiceClient {

    private final RestClient restClient;

    public UserServiceClient(
            @Value("${user.service.url}") String userServiceUrl) {
        this.restClient = RestClient.builder()
            .baseUrl(userServiceUrl)
            .build();
    }

    /**
     * Call User Service to get client information by ID.
     * Returns null if client not found (404).
     */
    public Map<String, Object> getClientById(Integer clientId) {
        try {
            return restClient.get()
                .uri("/clients/{id}", clientId)
                .retrieve()
                .body(Map.class);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Call User Service to get lawyer information by ID.
     * Returns null if lawyer not found (404).
     */
    public Map<String, Object> getLawyerById(Integer lawyerId) {
        try {
            return restClient.get()
                .uri("/lawyers/{id}", lawyerId)
                .retrieve()
                .body(Map.class);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Call User Service to get user information by ID.
     * Returns null if user not found (404).
     */
    public Map<String, Object> getUserById(Integer userId) {
        try {
            return restClient.get()
                .uri("/users/{id}", userId)
                .retrieve()
                .body(Map.class);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Check if User Service is available.
     */
    public boolean isUserServiceAvailable() {
        try {
            restClient.get()
                .uri("/users/health")
                .retrieve()
                .toBodilessEntity();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
