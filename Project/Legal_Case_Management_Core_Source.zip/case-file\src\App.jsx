import React, { Suspense, lazy } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useApp } from './context/AppContext.jsx';
import ToastStack from './components/ui/Toast.jsx';
import Layout from './components/layout/Layout.jsx';
import Login from './pages/Login.jsx';
import RoleLogin from './pages/shared/RoleLogin.jsx';
import RegisterPage from './pages/shared/RegisterPage.jsx';
import NotFound from './pages/NotFound.jsx';

const LawyerDashboard = lazy(() => import('./pages/lawyer/LawyerDashboard.jsx'));
const LawyerCases = lazy(() => import('./pages/lawyer/LawyerCases.jsx'));
const CaseDetails = lazy(() => import('./pages/shared/CaseDetails.jsx'));
const ClientsPage = lazy(() => import('./pages/lawyer/ClientsPage.jsx'));
const ClientDetails = lazy(() => import('./pages/lawyer/ClientDetails.jsx'));
const HearingsPage = lazy(() => import('./pages/lawyer/HearingsPage.jsx'));
const DocumentsPage = lazy(() => import('./pages/lawyer/DocumentsPage.jsx'));
const JudgmentsPage = lazy(() => import('./pages/lawyer/JudgmentsPage.jsx'));
const AnalyticsPage = lazy(() => import('./pages/lawyer/AnalyticsPage.jsx'));
const ProfilePage = lazy(() => import('./pages/shared/ProfilePage.jsx'));
const SettingsPage = lazy(() => import('./pages/shared/SettingsPage.jsx'));

const ClientDashboard = lazy(() => import('./pages/client/ClientDashboard.jsx'));
const ClientCases = lazy(() => import('./pages/client/ClientCases.jsx'));
const ClientHearings = lazy(() => import('./pages/client/ClientHearings.jsx'));
const ClientDocuments = lazy(() => import('./pages/client/ClientDocuments.jsx'));

function PageLoader() {
  return (
    <div className="page">
      <div style={{ padding: '48px 0', color: 'var(--text-faint)', fontSize: 14 }}>Loading...</div>
    </div>
  );
}

function withLoader(element) {
  return <Suspense fallback={<PageLoader />}>{element}</Suspense>;
}

function Guard({ role, children }) {
  const { role: currentRole, user } = useApp();
  if (!user || !currentRole) return <Navigate to={`/${role}/login`} replace />;
  if (currentRole !== role) return <Navigate to={`/${currentRole}/dashboard`} replace />;
  return children;
}

export default function App() {
  const { role } = useApp();

  return (
    <>
      <Routes>
        <Route path="/" element={role ? <Navigate to={`/${role}/dashboard`} replace /> : <Login />} />

        <Route path="/lawyer/login" element={<RoleLogin role="lawyer" />} />
        <Route path="/client/login" element={<RoleLogin role="client" />} />
        <Route path="/lawyer/register" element={<RegisterPage role="lawyer" />} />
        <Route path="/client/register" element={<RegisterPage role="client" />} />

        <Route path="/lawyer" element={<Guard role="lawyer"><Layout role="lawyer" /></Guard>}>
          <Route index element={<Navigate to="/lawyer/dashboard" replace />} />
          <Route path="dashboard" element={withLoader(<LawyerDashboard />)} />
          <Route path="cases" element={withLoader(<LawyerCases />)} />
          <Route path="cases/:caseId" element={withLoader(<CaseDetails role="lawyer" />)} />
          <Route path="clients" element={withLoader(<ClientsPage />)} />
          <Route path="clients/:clientId" element={withLoader(<ClientDetails />)} />
          <Route path="hearings" element={withLoader(<HearingsPage />)} />
          <Route path="documents" element={withLoader(<DocumentsPage />)} />
          <Route path="judgments" element={withLoader(<JudgmentsPage />)} />
          <Route path="analytics" element={withLoader(<AnalyticsPage />)} />
          <Route path="profile" element={withLoader(<ProfilePage role="lawyer" />)} />
          <Route path="settings" element={withLoader(<SettingsPage role="lawyer" />)} />
        </Route>

        <Route path="/client" element={<Guard role="client"><Layout role="client" /></Guard>}>
          <Route index element={<Navigate to="/client/dashboard" replace />} />
          <Route path="dashboard" element={withLoader(<ClientDashboard />)} />
          <Route path="cases" element={withLoader(<ClientCases />)} />
          <Route path="cases/:caseId" element={withLoader(<CaseDetails role="client" />)} />
          <Route path="hearings" element={withLoader(<ClientHearings />)} />
          <Route path="documents" element={withLoader(<ClientDocuments />)} />
          <Route path="profile" element={withLoader(<ProfilePage role="client" />)} />
          <Route path="settings" element={withLoader(<SettingsPage role="client" />)} />
        </Route>

        <Route path="/404" element={<NotFound />} />
        <Route path="*" element={<NotFound />} />
      </Routes>

      <ToastStack />
    </>
  );
}