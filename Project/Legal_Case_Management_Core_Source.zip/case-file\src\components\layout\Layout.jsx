import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import Sidebar from './Sidebar.jsx';
import Topbar from './Topbar.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function Layout({ role }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, profile } = useApp();

  // Use authenticated user data for display, fall back to profile
  const displayUser = user?.full_name
    ? {
        name: user.full_name,
        email: user.email || '',
        role: user.role === 'lawyer' ? 'Lawyer' : 'Client',
        initials: getInitials(user.full_name),
      }
    : role === 'lawyer' ? profile.lawyer : profile.client;

  function getInitials(name) {
    if (!name) return '';
    return name
      .split(' ')
      .map((w) => w[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  }

  return (
    <div className="layout">
      <Sidebar
        role={role}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />
      <div className="main">
        <Topbar role={role} user={displayUser} onMenu={() => setSidebarOpen(true)} />
        <Outlet context={{ role, user: displayUser }} />
      </div>
    </div>
  );
}