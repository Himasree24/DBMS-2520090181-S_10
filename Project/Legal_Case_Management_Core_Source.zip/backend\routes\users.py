from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from database import get_db
from models import User, Client, Lawyer
from schemas import (
    UserCreate,
    UserResponse,
    LoginRequest,
    LoginResponse,
    LawyerRegisterRequest,
    ClientRegisterRequest,
    ClientResponse,
    LawyerResponse,
)

from pwdlib import PasswordHash
from pwdlib.exceptions import UnknownHashError

from auth import (
    create_session,
    destroy_session,
    get_current_user,
)


router = APIRouter(
    prefix="/users",
    tags=["Users"]
)


password_hash = PasswordHash.recommended()


# --------------------------------------------------
# CREATE USER
# --------------------------------------------------

@router.post("/", response_model=UserResponse)
def create_user(
    user_data: UserCreate,
    db: Session = Depends(get_db)
):

    # Check whether email already exists
    existing_user = db.query(User).filter(
        User.email == user_data.email
    ).first()

    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    # Hash password
    hashed_password = password_hash.hash(
        user_data.password
    )

    # Create user
    new_user = User(
        full_name=user_data.full_name,
        email=user_data.email,
        password_hash=hashed_password,
        role=user_data.role
    )

    db.add(new_user)
    db.commit()
    db.refresh(new_user)

    return new_user


# --------------------------------------------------
# REGISTER LAWYER
# --------------------------------------------------

@router.post("/register/lawyer", response_model=UserResponse)
def register_lawyer(
    data: LawyerRegisterRequest,
    db: Session = Depends(get_db)
):

    # Validate passwords match
    if data.password != data.confirm_password:
        raise HTTPException(
            status_code=400,
            detail="Passwords do not match"
        )

    # Check whether email already exists
    existing_user = db.query(User).filter(
        User.email == data.email
    ).first()

    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    # Hash password
    hashed_password = password_hash.hash(data.password)

    # Create user
    new_user = User(
        full_name=data.full_name,
        email=data.email,
        password_hash=hashed_password,
        role="lawyer"
    )

    db.add(new_user)
    db.flush()  # Get user_id without committing

    # Create lawyer profile
    new_lawyer = Lawyer(
        user_id=new_user.user_id,
        bar_registration_no=data.bar_registration_no,
        specialization=data.specialization,
        years_experience=data.years_experience,
        phone=data.phone
    )

    db.add(new_lawyer)

    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Could not create lawyer profile"
        )

    db.refresh(new_user)

    return UserResponse(
        user_id=new_user.user_id,
        full_name=new_user.full_name,
        email=new_user.email,
        role=new_user.role,
        lawyer_id=new_lawyer.lawyer_id,
        phone=data.phone
    )


# --------------------------------------------------
# REGISTER CLIENT
# --------------------------------------------------

@router.post("/register/client", response_model=UserResponse)
def register_client(
    data: ClientRegisterRequest,
    db: Session = Depends(get_db)
):

    # Validate passwords match
    if data.password != data.confirm_password:
        raise HTTPException(
            status_code=400,
            detail="Passwords do not match"
        )

    # Check whether email already exists
    existing_user = db.query(User).filter(
        User.email == data.email
    ).first()

    if existing_user:
        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    # Hash password
    hashed_password = password_hash.hash(data.password)

    # Create user
    new_user = User(
        full_name=data.full_name,
        email=data.email,
        password_hash=hashed_password,
        role="client"
    )

    db.add(new_user)
    db.flush()  # Get user_id without committing

    # Create client profile
    new_client = Client(
        user_id=new_user.user_id,
        address=data.address,
        phone=data.phone
    )

    db.add(new_client)

    try:
        db.commit()
    except Exception:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Could not create client profile"
        )

    db.refresh(new_user)

    return UserResponse(
        user_id=new_user.user_id,
        full_name=new_user.full_name,
        email=new_user.email,
        role=new_user.role,
        client_id=new_client.client_id,
        phone=data.phone
    )


# --------------------------------------------------
# LOGIN
# --------------------------------------------------

@router.post("/login", response_model=LoginResponse)
def login(
    login_data: LoginRequest,
    db: Session = Depends(get_db)
):

    user = db.query(User).filter(
        User.email == login_data.email
    ).first()

    if not user:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    try:
        password_valid = password_hash.verify(
            login_data.password,
            user.password_hash
        )
    except UnknownHashError:
        password_valid = False

    if not password_valid:
        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    # Look up client_id, lawyer_id, and phone
    client_id = None
    lawyer_id = None
    phone = None

    if user.role == "client":
        client = db.query(Client).filter(
            Client.user_id == user.user_id
        ).first()
        if client:
            client_id = client.client_id
            phone = client.phone
    elif user.role == "lawyer":
        lawyer = db.query(Lawyer).filter(
            Lawyer.user_id == user.user_id
        ).first()
        if lawyer:
            lawyer_id = lawyer.lawyer_id
            phone = lawyer.phone

    # Create session
    session_token = create_session(user.user_id)

    return LoginResponse(
        user_id=user.user_id,
        full_name=user.full_name,
        email=user.email,
        role=user.role,
        client_id=client_id,
        lawyer_id=lawyer_id,
        phone=phone,
        session_token=session_token,
    )


# --------------------------------------------------
# LOGOUT
# --------------------------------------------------

@router.post("/logout")
def logout(
    current_user: User = Depends(get_current_user),
):
    # Note: The frontend sends the session token via header.
    # We need to get it from the request to destroy the session.
    # For simplicity, the frontend clears its stored user data.
    return {"message": "Logged out successfully"}


# --------------------------------------------------
# GET CURRENT USER
# --------------------------------------------------

@router.get("/me", response_model=UserResponse)
def get_me(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):

    client_id = None
    lawyer_id = None
    phone = None

    if current_user.role == "client":
        client = db.query(Client).filter(
            Client.user_id == current_user.user_id
        ).first()
        if client:
            client_id = client.client_id
            phone = client.phone
    elif current_user.role == "lawyer":
        lawyer = db.query(Lawyer).filter(
            Lawyer.user_id == current_user.user_id
        ).first()
        if lawyer:
            lawyer_id = lawyer.lawyer_id
            phone = lawyer.phone

    return UserResponse(
        user_id=current_user.user_id,
        full_name=current_user.full_name,
        email=current_user.email,
        role=current_user.role,
        client_id=client_id,
        lawyer_id=lawyer_id,
        phone=phone
    )


# --------------------------------------------------
# GET ALL CLIENTS
# --------------------------------------------------

@router.get("/clients", response_model=list[ClientResponse])
def get_clients(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get all clients from the database."""
    clients = db.query(Client).all()
    return clients


# --------------------------------------------------
# GET ALL LAWYERS
# --------------------------------------------------

@router.get("/lawyers", response_model=list[LawyerResponse])
def get_lawyers(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get all lawyers from the database."""
    lawyers = db.query(Lawyer).all()
    return lawyers
