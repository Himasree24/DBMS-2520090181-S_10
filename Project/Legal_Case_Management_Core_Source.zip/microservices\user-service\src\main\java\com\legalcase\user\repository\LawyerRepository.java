package com.legalcase.user.repository;

import com.legalcase.user.entity.Lawyer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface LawyerRepository extends JpaRepository<Lawyer, Integer> {
    List<Lawyer> findByUserUserId(Integer userId);
}
