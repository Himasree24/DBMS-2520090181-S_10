package com.legalcase.caseservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class CaseHealthController {

    @GetMapping("/cases/health")
    public Map<String, String> health() {
        return Map.of(
            "service", "case-service",
            "status", "UP"
        );
    }
}
