// ==================================================
// MICROSERVICES API LAYER
// ==================================================
// This module provides API functions for communicating with
// the Spring Boot microservices. Authentication remains
// handled by FastAPI.

const USER_SERVICE_URL = import.meta.env.VITE_USER_SERVICE_URL || "http://localhost:8081";
const CASE_SERVICE_URL = import.meta.env.VITE_CASE_SERVICE_URL || "http://localhost:8082";
const RECORD_SERVICE_URL = import.meta.env.VITE_RECORD_SERVICE_URL || "http://localhost:8083";


// ==================================================
// HELPER FUNCTIONS
// ==================================================

async function handleResponse(response, defaultMessage) {
  if (!response.ok) {
    let message = defaultMessage;
    try {
      const errorData = await response.json();
      if (errorData.detail) {
        message = errorData.detail;
      } else if (errorData.message) {
        message = errorData.message;
      } else if (errorData.error) {
        message = errorData.error;
      }
    } catch {
      // Ignore JSON parsing error
    }
    throw new Error(message);
  }
  return response.json();
}

async function serviceFetch(url, options = {}) {
  const headers = {
    ...options.headers,
  };

  if (options.body && typeof options.body === 'string') {
    headers["Content-Type"] = "application/json";
  }

  return fetch(url, { ...options, headers });
}


// ==================================================
// USER SERVICE (:8081)
// ==================================================

export async function getUsers() {
  const response = await serviceFetch(`${USER_SERVICE_URL}/users`);
  return handleResponse(response, "Failed to fetch users");
}

export async function getUser(id) {
  const response = await serviceFetch(`${USER_SERVICE_URL}/users/${id}`);
  return handleResponse(response, "Failed to fetch user");
}

export async function getUserByEmail(email) {
  const response = await serviceFetch(`${USER_SERVICE_URL}/users/email/${email}`);
  return handleResponse(response, "Failed to fetch user by email");
}

export async function getClients() {
  const response = await serviceFetch(`${USER_SERVICE_URL}/clients`);
  return handleResponse(response, "Failed to fetch clients");
}

export async function getClient(id) {
  const response = await serviceFetch(`${USER_SERVICE_URL}/clients/${id}`);
  return handleResponse(response, "Failed to fetch client");
}

export async function getLawyers() {
  const response = await serviceFetch(`${USER_SERVICE_URL}/lawyers`);
  return handleResponse(response, "Failed to fetch lawyers");
}

export async function getLawyer(id) {
  const response = await serviceFetch(`${USER_SERVICE_URL}/lawyers/${id}`);
  return handleResponse(response, "Failed to fetch lawyer");
}


// ==================================================
// CASE SERVICE (:8082)
// ==================================================

export async function getCasesFromService() {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases`);
  return handleResponse(response, "Failed to fetch cases");
}

export async function getCaseFromService(id) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases/${id}`);
  return handleResponse(response, "Failed to fetch case");
}

export async function createCaseInService(caseData) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases`, {
    method: "POST",
    body: JSON.stringify(caseData)
  });
  return handleResponse(response, "Failed to create case");
}

export async function updateCaseInService(id, caseData) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases/${id}`, {
    method: "PUT",
    body: JSON.stringify(caseData)
  });
  return handleResponse(response, "Failed to update case");
}

export async function deleteCaseFromService(id) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases/${id}`, {
    method: "DELETE"
  });
  return handleResponse(response, "Failed to delete case");
}

export async function getCasesByStatus(status) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases?status=${status}`);
  return handleResponse(response, "Failed to fetch cases by status");
}

export async function getCasesByLawyer(lawyerId) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases?lawyerId=${lawyerId}`);
  return handleResponse(response, "Failed to fetch cases by lawyer");
}

export async function getCasesByClient(clientId) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases?clientId=${clientId}`);
  return handleResponse(response, "Failed to fetch cases by client");
}

export async function getCasesByCaseType(caseType) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases?caseType=${caseType}`);
  return handleResponse(response, "Failed to fetch cases by type");
}

export async function getCaseWithUsers(id) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases/${id}/with-users`);
  return handleResponse(response, "Failed to fetch case with users");
}


// ==================================================
// RECORD SERVICE (:8083)
// ==================================================

// ---------- HEARINGS ----------

export async function getHearingsFromService() {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings`);
  return handleResponse(response, "Failed to fetch hearings");
}

export async function getHearingFromService(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings/${id}`);
  return handleResponse(response, "Failed to fetch hearing");
}

export async function getHearingsByCase(caseId) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings?caseId=${caseId}`);
  return handleResponse(response, "Failed to fetch hearings by case");
}

export async function createHearingInService(hearingData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings`, {
    method: "POST",
    body: JSON.stringify(hearingData)
  });
  return handleResponse(response, "Failed to create hearing");
}

export async function updateHearingInService(id, hearingData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings/${id}`, {
    method: "PUT",
    body: JSON.stringify(hearingData)
  });
  return handleResponse(response, "Failed to update hearing");
}

export async function deleteHearingFromService(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings/${id}`, {
    method: "DELETE"
  });
  return handleResponse(response, "Failed to delete hearing");
}

export async function getHearingWithCase(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings/${id}/with-case`);
  return handleResponse(response, "Failed to fetch hearing with case");
}

// ---------- DOCUMENTS ----------

export async function getDocumentsFromService() {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents`);
  return handleResponse(response, "Failed to fetch documents");
}

export async function getDocumentFromService(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents/${id}`);
  return handleResponse(response, "Failed to fetch document");
}

export async function getDocumentsByCase(caseId) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents?caseId=${caseId}`);
  return handleResponse(response, "Failed to fetch documents by case");
}

export async function createDocumentInService(documentData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents`, {
    method: "POST",
    body: JSON.stringify(documentData)
  });
  return handleResponse(response, "Failed to create document");
}

export async function updateDocumentInService(id, documentData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents/${id}`, {
    method: "PUT",
    body: JSON.stringify(documentData)
  });
  return handleResponse(response, "Failed to update document");
}

export async function deleteDocumentFromService(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents/${id}`, {
    method: "DELETE"
  });
  return handleResponse(response, "Failed to delete document");
}

export async function getDocumentWithCase(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents/${id}/with-case`);
  return handleResponse(response, "Failed to fetch document with case");
}

// ---------- JUDGMENTS ----------

export async function getJudgmentsFromService() {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments`);
  return handleResponse(response, "Failed to fetch judgments");
}

export async function getJudgmentFromService(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments/${id}`);
  return handleResponse(response, "Failed to fetch judgment");
}

export async function getJudgmentsByCase(caseId) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments?caseId=${caseId}`);
  return handleResponse(response, "Failed to fetch judgments by case");
}

export async function createJudgmentInService(judgmentData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments`, {
    method: "POST",
    body: JSON.stringify(judgmentData)
  });
  return handleResponse(response, "Failed to create judgment");
}

export async function updateJudgmentInService(id, judgmentData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments/${id}`, {
    method: "PUT",
    body: JSON.stringify(judgmentData)
  });
  return handleResponse(response, "Failed to update judgment");
}

export async function deleteJudgmentFromService(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments/${id}`, {
    method: "DELETE"
  });
  return handleResponse(response, "Failed to delete judgment");
}

export async function getJudgmentWithCase(id) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments/${id}/with-case`);
  return handleResponse(response, "Failed to fetch judgment with case");
}
