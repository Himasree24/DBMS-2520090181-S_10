import React from 'react';

export default function FilterDropdown({ label, value, onChange, options, placeholder }) {
  return (
    <div className="field">
      {label && <label className="field-label">{label}</label>}
      <select className="select" value={value || ''} onChange={(e) => onChange(e.target.value)}>
        <option value="">{placeholder || `All ${label || ''}`}</option>
        {options.map((o) => (
          <option key={o} value={o}>{o}</option>
        ))}
      </select>
    </div>
  );
}
