package com.legalcase.recordservice.repository;

import com.legalcase.recordservice.entity.Hearing;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HearingRepository extends JpaRepository<Hearing, Integer> {
    List<Hearing> findByCaseId(Integer caseId);
    List<Hearing> findByStatus(String status);
}
