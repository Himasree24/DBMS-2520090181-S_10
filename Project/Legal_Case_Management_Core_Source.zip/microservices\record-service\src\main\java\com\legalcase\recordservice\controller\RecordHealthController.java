package com.legalcase.recordservice.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class RecordHealthController {

    @GetMapping("/records/health")
    public Map<String, String> health() {
        return Map.of(
            "service", "record-service",
            "status", "UP"
        );
    }
}
