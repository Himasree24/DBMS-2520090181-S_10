import React from 'react';
import { Bell, Shield, Settings as SettingsIcon, Palette, Globe } from 'lucide-react';
import { useApp } from '../../context/AppContext.jsx';

function Row({ icon, title, desc, control }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 16, padding: '16px 0', borderBottom: '1px solid var(--border)' }}>
      <div className="notif-icon" style={{ background: 'rgba(68,23,78,0.08)', color: 'var(--violet)' }}>{icon}</div>
      <div style={{ flex: 1 }}>
        <div style={{ fontWeight: 600, color: 'var(--navy)', fontSize: 14 }}>{title}</div>
        <div style={{ fontSize: 12.5, color: 'var(--text-soft)', marginTop: 3 }}>{desc}</div>
      </div>
      {control}
    </div>
  );
}

export default function SettingsPage() {
  const { pushToast } = useApp();

  return (
    <div className="page">
      <div className="page-header">
        <h1>Settings</h1>
        <div className="subtitle">Preferences for your account and notifications.</div>
      </div>

      <div className="detail-section" style={{ maxWidth: 760 }}>
        <div className="section-title">Notifications</div>
        <Row
          icon={<Bell size={16} />}
          title="Upcoming hearing reminders"
          desc="Notify me 48 hours before a scheduled hearing"
          control={<label className="toggle"><input type="checkbox" defaultChecked onChange={() => pushToast('Preference updated.')} /></label>}
        />
        <Row
          icon={<Bell size={16} />}
          title="Document & case status updates"
          desc="Notify me when documents are shared or statuses change"
          control={<label className="toggle"><input type="checkbox" defaultChecked onChange={() => pushToast('Preference updated.')} /></label>}
        />
        <Row
          icon={<Shield size={16} />}
          title="Judgment alerts"
          desc="Alert me when a judgment is delivered for my cases"
          control={<label className="toggle"><input type="checkbox" defaultChecked onChange={() => pushToast('Preference updated.')} /></label>}
        />

        <div className="section-title" style={{ marginTop: 30 }}>Interface</div>
        <Row
          icon={<Palette size={16} />}
          title="Theme"
          desc="Adjust the visual theme of the portal"
          control={<select className="select" style={{ width: 140 }} onChange={() => pushToast('Theme preference updated.')}><option>Classic</option><option>Light</option></select>}
        />
        <Row
          icon={<Globe size={16} />}
          title="Timezone"
          desc="Region used for court date formatting"
          control={<select className="select" style={{ width: 140 }} onChange={() => pushToast('Timezone updated.')}><option>IST (UTC+5:30)</option><option>GMT</option></select>}
        />

        <div style={{ marginTop: 24, display: 'flex', gap: 10 }}>
          <button className="btn btn-primary" onClick={() => pushToast('Settings saved successfully.')}>
            <SettingsIcon size={15} /> Save Settings
          </button>
        </div>
      </div>
    </div>
  );
}