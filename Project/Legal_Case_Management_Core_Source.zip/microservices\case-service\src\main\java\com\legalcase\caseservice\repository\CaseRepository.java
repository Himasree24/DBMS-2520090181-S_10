package com.legalcase.caseservice.repository;

import com.legalcase.caseservice.entity.Case;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CaseRepository extends JpaRepository<Case, Integer> {
    List<Case> findByClientId(Integer clientId);
    List<Case> findByLawyerId(Integer lawyerId);
    List<Case> findByStatus(String status);
    List<Case> findByCaseType(String caseType);
}
