package com.legalcase.recordservice.service;

import com.legalcase.recordservice.client.CaseServiceClient;
import com.legalcase.recordservice.dto.DocumentCreateRequest;
import com.legalcase.recordservice.dto.DocumentResponse;
import com.legalcase.recordservice.dto.DocumentUpdateRequest;
import com.legalcase.recordservice.entity.Document;
import com.legalcase.recordservice.repository.DocumentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class DocumentService {

    private final DocumentRepository documentRepository;
    private final CaseServiceClient caseServiceClient;

    public DocumentService(DocumentRepository documentRepository,
                          CaseServiceClient caseServiceClient) {
        this.documentRepository = documentRepository;
        this.caseServiceClient = caseServiceClient;
    }

    public List<DocumentResponse> getAllDocuments() {
        return documentRepository.findAll().stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    public DocumentResponse getDocumentById(Integer id) {
        Document document = documentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Document not found with id: " + id));
        return toResponse(document);
    }

    public List<DocumentResponse> getDocumentsByCaseId(Integer caseId) {
        return documentRepository.findByCaseId(caseId).stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    @Transactional
    public DocumentResponse createDocument(DocumentCreateRequest request) {
        // Validate case exists via Case Service
        if (!caseServiceClient.getCaseById(request.getCaseId()).containsKey("caseId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Case not found with id: " + request.getCaseId());
        }

        Document document = new Document();
        document.setCaseId(request.getCaseId());
        document.setDocumentName(request.getDocumentName());
        document.setDocumentType(request.getDocumentType());
        document.setUploadedBy(request.getUploadedBy());
        document.setFilePath(request.getFilePath());

        Document saved = documentRepository.save(document);
        return toResponse(saved);
    }

    @Transactional
    public DocumentResponse updateDocument(Integer id, DocumentUpdateRequest request) {
        Document document = documentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Document not found with id: " + id));

        // Validate case exists via Case Service
        if (!caseServiceClient.getCaseById(request.getCaseId()).containsKey("caseId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Case not found with id: " + request.getCaseId());
        }

        document.setCaseId(request.getCaseId());
        document.setDocumentName(request.getDocumentName());
        document.setDocumentType(request.getDocumentType());
        document.setUploadedBy(request.getUploadedBy());
        document.setFilePath(request.getFilePath());

        Document updated = documentRepository.save(document);
        return toResponse(updated);
    }

    @Transactional
    public void deleteDocument(Integer id) {
        if (!documentRepository.existsById(id)) {
            throw new RuntimeException("Document not found with id: " + id);
        }
        documentRepository.deleteById(id);
    }

    private DocumentResponse toResponse(Document document) {
        return new DocumentResponse(
            document.getDocumentId(),
            document.getCaseId(),
            document.getDocumentName(),
            document.getDocumentType(),
            document.getUploadedBy(),
            document.getUploadDate(),
            document.getFilePath()
        );
    }
}
