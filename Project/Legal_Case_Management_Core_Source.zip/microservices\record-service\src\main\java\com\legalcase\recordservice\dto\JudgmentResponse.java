package com.legalcase.recordservice.dto;

import java.time.LocalDate;

public class JudgmentResponse {

    private Integer judgmentId;
    private Integer caseId;
    private LocalDate judgmentDate;
    private String decision;
    private String summary;
    private String remarks;

    public JudgmentResponse() {
    }

    public JudgmentResponse(Integer judgmentId, Integer caseId, LocalDate judgmentDate,
                            String decision, String summary, String remarks) {
        this.judgmentId = judgmentId;
        this.caseId = caseId;
        this.judgmentDate = judgmentDate;
        this.decision = decision;
        this.summary = summary;
        this.remarks = remarks;
    }

    public Integer getJudgmentId() { return judgmentId; }
    public void setJudgmentId(Integer judgmentId) { this.judgmentId = judgmentId; }
    public Integer getCaseId() { return caseId; }
    public void setCaseId(Integer caseId) { this.caseId = caseId; }
    public LocalDate getJudgmentDate() { return judgmentDate; }
    public void setJudgmentDate(LocalDate judgmentDate) { this.judgmentDate = judgmentDate; }
    public String getDecision() { return decision; }
    public void setDecision(String decision) { this.decision = decision; }
    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
}
