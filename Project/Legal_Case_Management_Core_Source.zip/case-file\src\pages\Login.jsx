import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Gavel, User, ArrowRight, Scale } from 'lucide-react';

export default function Login() {
  const navigate = useNavigate();

  const enter = (role) => {
    navigate(`/${role}/login`);
  };

  return (
    <div className="login-wrap">
      <div className="login-glow glow-1" />
      <div className="login-glow glow-3" />

      <div className="login-left">
        <div className="login-brand">
          <div className="brand-mark">
            <Scale size={22} />
          </div>
          <div>
            <div className="brand-name">CASE FILE</div>
            <div className="brand-tag">Legal Management Portal</div>
          </div>
        </div>

        <div className="login-lead">
          <div className="eyebrow">Legal Case Management &amp; Analytics</div>
          <h1>Where every case is managed with clarity and precision.</h1>
          <p>
            A professional platform for advocates and their clients to manage
            cases, hearings, documents and judgments — all in one refined
            space.
          </p>
        </div>

        <div className="login-foot">
          © 2026 CASE FILE · Law Practice Management
        </div>
      </div>

      <div className="login-right">
        <div className="login-glow glow-2" />
        <div className="login-cards">
          <div>
            <div className="heading">Are you a Lawyer or a Client?</div>
            <p style={{ color: '#b6afcb', fontSize: '14px', margin: '6px 0 18px' }}>
              Access your legal case management portal.
            </p>
          </div>

          <button className="role-card" onClick={() => enter('lawyer')}>
            <div className="role-card-icon lawyer">
              <Gavel size={24} />
            </div>
            <div>
              <h3>LAWYER</h3>
              <p>
                Manage cases, clients, hearings, documents and legal records.
              </p>
              <span className="role-cta">
                Continue as Lawyer <ArrowRight size={15} />
              </span>
            </div>
          </button>

          <button
            className="role-card"
            onClick={() => enter('client')}
            style={{ background: 'rgba(102,34,73,0.28)', borderColor: 'rgba(237,158,90,0.35)' }}
          >
            <div className="role-card-icon client">
              <User size={24} />
            </div>
            <div>
              <h3>CLIENT</h3>
              <p>
                Track your cases, upcoming hearings, documents and case updates.
              </p>
              <span className="role-cta">
                Continue as Client <ArrowRight size={15} />
              </span>
            </div>
          </button>
        </div>

        <div style={{ marginTop: '24px', textAlign: 'center', fontSize: '14px', color: '#b6afcb' }}>
          Don't have an account?{' '}
          <Link to="/lawyer/register" style={{ color: '#ed9e5a', textDecoration: 'none', marginRight: '12px' }}>
            Register as Lawyer
          </Link>
          <Link to="/client/register" style={{ color: '#ed9e5a', textDecoration: 'none' }}>
            Register as Client
          </Link>
        </div>
      </div>
    </div>
  );
}
