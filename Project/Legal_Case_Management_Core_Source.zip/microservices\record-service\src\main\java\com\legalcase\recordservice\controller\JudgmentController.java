package com.legalcase.recordservice.controller;

import com.legalcase.recordservice.dto.JudgmentCreateRequest;
import com.legalcase.recordservice.dto.JudgmentResponse;
import com.legalcase.recordservice.dto.JudgmentUpdateRequest;
import com.legalcase.recordservice.dto.JudgmentWithCaseResponse;
import com.legalcase.recordservice.service.JudgmentService;
import com.legalcase.recordservice.service.RecordCaseAggregationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class JudgmentController {

    private final JudgmentService judgmentService;
    private final RecordCaseAggregationService aggregationService;

    public JudgmentController(JudgmentService judgmentService,
                              RecordCaseAggregationService aggregationService) {
        this.judgmentService = judgmentService;
        this.aggregationService = aggregationService;
    }

    @GetMapping("/records/judgments")
    public List<JudgmentResponse> getAllJudgments(
            @RequestParam(required = false) Integer caseId) {
        if (caseId != null) {
            return judgmentService.getJudgmentsByCaseId(caseId);
        }
        return judgmentService.getAllJudgments();
    }

    @GetMapping("/records/judgments/{id}")
    public ResponseEntity<JudgmentResponse> getJudgmentById(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(judgmentService.getJudgmentById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // --------------------------------------------------
    // GET JUDGMENT WITH CASE INFO (Service-to-Service)
    // --------------------------------------------------

    @GetMapping("/records/judgments/{id}/with-case")
    public ResponseEntity<JudgmentWithCaseResponse> getJudgmentWithCase(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(aggregationService.getJudgmentWithCase(id));
        } catch (org.springframework.web.server.ResponseStatusException e) {
            return ResponseEntity.status(e.getStatusCode()).build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/records/judgments")
    public ResponseEntity<JudgmentResponse> createJudgment(@Valid @RequestBody JudgmentCreateRequest request) {
        JudgmentResponse created = judgmentService.createJudgment(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/records/judgments/{id}")
    public ResponseEntity<JudgmentResponse> updateJudgment(@PathVariable Integer id,
                                                           @Valid @RequestBody JudgmentUpdateRequest request) {
        try {
            return ResponseEntity.ok(judgmentService.updateJudgment(id, request));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/records/judgments/{id}")
    public ResponseEntity<Void> deleteJudgment(@PathVariable Integer id) {
        try {
            judgmentService.deleteJudgment(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
