package com.legalcase.recordservice.dto;

import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;

public class JudgmentCreateRequest {

    @NotNull(message = "Case ID is required")
    private Integer caseId;

    private LocalDate judgmentDate;
    private String decision;
    private String summary;
    private String remarks;

    public JudgmentCreateRequest() {
    }

    public Integer getCaseId() { return caseId; }
    public void setCaseId(Integer caseId) { this.caseId = caseId; }
    public LocalDate getJudgmentDate() { return judgmentDate; }
    public void setJudgmentDate(LocalDate judgmentDate) { this.judgmentDate = judgmentDate; }
    public String getDecision() { return decision; }
    public void setDecision(String decision) { this.decision = decision; }
    public String getSummary() { return summary; }
    public void setSummary(String summary) { this.summary = summary; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
}
