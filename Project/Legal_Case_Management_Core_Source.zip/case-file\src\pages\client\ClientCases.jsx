import React, {
  useMemo
} from "react";

import { useApp }
  from "../../context/AppContext.jsx";

import StatusBadge
  from "../../components/ui/StatusBadge.jsx";


export default function ClientCases() {

  const {
    casesList,
    casesLoading,
    user
  } = useApp();


  // ==================================================
  // CLIENT ID (from authenticated user)
  // ==================================================

  const clientId = user?.client_id
    ? String(user.client_id)
    : null;


  // ==================================================
  // FILTER CLIENT CASES
  // ==================================================

  const clientCases = useMemo(() => {

    return casesList.filter(
      (c) =>
        String(c.clientId) === clientId
    );

  }, [
    casesList,
    clientId
  ]);


  return (

    <div className="page">

      {/* ============================================ */}
      {/* HEADER */}
      {/* ============================================ */}

      <div className="page-header">

        <div>

          <h1>
            My Cases
          </h1>

          <p>
            Cases associated with your account
          </p>

        </div>

      </div>


      {/* ============================================ */}
      {/* CONTENT */}
      {/* ============================================ */}

      <div className="card">

        {casesLoading ? (

          <div className="empty-state">
            Loading cases...
          </div>

        ) : clientCases.length === 0 ? (

          <div className="empty-state">

            <h3>
              No cases found
            </h3>

            <p>
              No cases are currently associated
              with client ID {clientId}.
            </p>

          </div>

        ) : (

          <div className="table-container">

            <table className="data-table">

              <thead>

                <tr>

                  <th>
                    Case Number
                  </th>

                  <th>
                    Title
                  </th>

                  <th>
                    Type
                  </th>

                  <th>
                    Lawyer
                  </th>

                  <th>
                    Court
                  </th>

                  <th>
                    Filing Date
                  </th>

                  <th>
                    Status
                  </th>

                </tr>

              </thead>


              <tbody>

                {clientCases.map((c) => (

                  <tr key={c.dbId}>

                    <td>
                      <strong>
                        {c.id}
                      </strong>
                    </td>


                    <td>
                      {c.title || "—"}
                    </td>


                    <td>
                      {c.type || "—"}
                    </td>


                    <td>
                      Lawyer {c.lawyerId}
                    </td>


                    <td>
                      {c.court || "—"}
                    </td>


                    <td>
                      {c.filingDate || "—"}
                    </td>


                    <td>

                      <StatusBadge
                        status={c.status}
                      />

                    </td>

                  </tr>

                ))}

              </tbody>

            </table>

          </div>

        )}

      </div>

    </div>

  );

}