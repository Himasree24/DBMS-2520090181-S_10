import React, { useState } from 'react';
import Modal from '../ui/Modal.jsx';
import { useApp } from '../../context/AppContext.jsx';

const DOC_TYPES = ['Petition', 'Evidence', 'Court Order', 'Hearing Notice', 'Affidavit', 'Agreement'];

export default function DocumentModal({ open, onClose, onSave, count, uploadedBy }) {
  const { casesList } = useApp();
  const [form, setForm] = useState({ name: '', caseId: '', type: 'Petition' });
  const [errors, setErrors] = useState({});

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const validate = () => {
    const e = {};
    if (!form.name.trim()) e.name = 'Document name is required';
    if (!form.caseId) e.caseId = 'Select a case';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev) => {
    ev.preventDefault();
    if (!validate()) return;
    onSave({
      name: form.name.trim(),
      caseId: form.caseId,
      type: form.type,
    });
  };

  const reset = () => {
    setForm({ name: '', caseId: '', type: 'Petition' });
    setErrors({});
  };

  return (
    <Modal
      open={open}
      onClose={() => { reset(); onClose(); }}
      title="Upload Document"
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={() => { reset(); onClose(); }}>Cancel</button>
          <button type="submit" className="btn btn-primary" form="doc-form">Upload</button>
        </>
      }
    >
      <form id="doc-form" onSubmit={submit} className="modal-body">
        <div className="field">
          <label className="field-label">Document Name</label>
          <input className="input" value={form.name} onChange={(e) => set('name', e.target.value)} placeholder="e.g. Updated Petition" />
          {errors.name && <span style={{ color: 'var(--crimson)', fontSize: 12 }}>{errors.name}</span>}
        </div>

        <div className="field">
          <label className="field-label">Case</label>
          <select className="select" value={form.caseId} onChange={(e) => set('caseId', e.target.value)}>
            <option value="">Select case</option>
            {casesList.map((c) => <option key={c.dbId} value={c.dbId}>{c.id} · {c.title}</option>)}
          </select>
          {errors.caseId && <span style={{ color: 'var(--crimson)', fontSize: 12 }}>{errors.caseId}</span>}
        </div>

        <div className="field">
          <label className="field-label">Document Type</label>
          <select className="select" value={form.type} onChange={(e) => set('type', e.target.value)}>
            {DOC_TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
          </select>
        </div>
      </form>
    </Modal>
  );
}
