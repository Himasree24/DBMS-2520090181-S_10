package com.legalcase.recordservice.entity;

import jakarta.persistence.*;
import java.time.LocalDate;

@Entity
@Table(name = "judgments")
public class Judgment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "judgment_id")
    private Integer judgmentId;

    @Column(name = "case_id", nullable = false, unique = true)
    private Integer caseId;

    @Column(name = "judgment_date")
    private LocalDate judgmentDate;

    @Column(name = "decision", length = 100)
    private String decision;

    @Column(name = "summary", columnDefinition = "TEXT")
    private String summary;

    @Column(name = "remarks", columnDefinition = "TEXT")
    private String remarks;

    public Judgment() {
    }

    public Integer getJudgmentId() {
        return judgmentId;
    }

    public void setJudgmentId(Integer judgmentId) {
        this.judgmentId = judgmentId;
    }

    public Integer getCaseId() {
        return caseId;
    }

    public void setCaseId(Integer caseId) {
        this.caseId = caseId;
    }

    public LocalDate getJudgmentDate() {
        return judgmentDate;
    }

    public void setJudgmentDate(LocalDate judgmentDate) {
        this.judgmentDate = judgmentDate;
    }

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
