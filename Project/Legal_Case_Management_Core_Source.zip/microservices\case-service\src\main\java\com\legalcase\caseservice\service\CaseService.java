package com.legalcase.caseservice.service;

import com.legalcase.caseservice.client.UserServiceClient;
import com.legalcase.caseservice.dto.CaseCreateRequest;
import com.legalcase.caseservice.dto.CaseResponse;
import com.legalcase.caseservice.dto.CaseUpdateRequest;
import com.legalcase.caseservice.entity.Case;
import com.legalcase.caseservice.repository.CaseRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CaseService {

    private final CaseRepository caseRepository;
    private final UserServiceClient userServiceClient;

    public CaseService(CaseRepository caseRepository,
                       UserServiceClient userServiceClient) {
        this.caseRepository = caseRepository;
        this.userServiceClient = userServiceClient;
    }

    public List<CaseResponse> getAllCases() {
        return caseRepository.findAll().stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    public CaseResponse getCaseById(Integer id) {
        Case caseEntity = caseRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Case not found with id: " + id));
        return toResponse(caseEntity);
    }

    public List<CaseResponse> getCasesByClientId(Integer clientId) {
        return caseRepository.findByClientId(clientId).stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    public List<CaseResponse> getCasesByLawyerId(Integer lawyerId) {
        return caseRepository.findByLawyerId(lawyerId).stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    public List<CaseResponse> getCasesByStatus(String status) {
        return caseRepository.findByStatus(status).stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    public List<CaseResponse> getCasesByCaseType(String caseType) {
        return caseRepository.findByCaseType(caseType).stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    @Transactional
    public CaseResponse createCase(CaseCreateRequest request) {
        // Validate client exists via User Service
        if (request.getClientId() != null && !userServiceClient.getClientById(request.getClientId()).containsKey("clientId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Client not found with id: " + request.getClientId());
        }
        // Validate lawyer exists via User Service
        if (request.getLawyerId() != null && !userServiceClient.getLawyerById(request.getLawyerId()).containsKey("lawyerId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Lawyer not found with id: " + request.getLawyerId());
        }

        Case caseEntity = new Case();
        caseEntity.setClientId(request.getClientId());
        caseEntity.setLawyerId(request.getLawyerId());
        caseEntity.setCaseNumber(request.getCaseNumber());
        caseEntity.setTitle(request.getTitle());
        caseEntity.setCaseType(request.getCaseType());
        caseEntity.setDescription(request.getDescription());
        caseEntity.setStatus(request.getStatus());
        caseEntity.setFilingDate(request.getFilingDate());
        caseEntity.setCourtName(request.getCourtName());

        Case saved = caseRepository.save(caseEntity);
        return toResponse(saved);
    }

    @Transactional
    public CaseResponse updateCase(Integer id, CaseUpdateRequest request) {
        Case caseEntity = caseRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Case not found with id: " + id));

        // Validate client exists via User Service
        if (request.getClientId() != null && !userServiceClient.getClientById(request.getClientId()).containsKey("clientId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Client not found with id: " + request.getClientId());
        }
        // Validate lawyer exists via User Service
        if (request.getLawyerId() != null && !userServiceClient.getLawyerById(request.getLawyerId()).containsKey("lawyerId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Lawyer not found with id: " + request.getLawyerId());
        }

        caseEntity.setClientId(request.getClientId());
        caseEntity.setLawyerId(request.getLawyerId());
        caseEntity.setCaseNumber(request.getCaseNumber());
        caseEntity.setTitle(request.getTitle());
        caseEntity.setCaseType(request.getCaseType());
        caseEntity.setDescription(request.getDescription());
        caseEntity.setStatus(request.getStatus());
        caseEntity.setFilingDate(request.getFilingDate());
        caseEntity.setCourtName(request.getCourtName());

        Case updated = caseRepository.save(caseEntity);
        return toResponse(updated);
    }

    @Transactional
    public void deleteCase(Integer id) {
        if (!caseRepository.existsById(id)) {
            throw new RuntimeException("Case not found with id: " + id);
        }
        caseRepository.deleteById(id);
    }

    private CaseResponse toResponse(Case caseEntity) {
        return new CaseResponse(
            caseEntity.getCaseId(),
            caseEntity.getClientId(),
            caseEntity.getLawyerId(),
            caseEntity.getCaseNumber(),
            caseEntity.getTitle(),
            caseEntity.getCaseType(),
            caseEntity.getDescription(),
            caseEntity.getStatus(),
            caseEntity.getFilingDate(),
            caseEntity.getCourtName()
        );
    }
}
