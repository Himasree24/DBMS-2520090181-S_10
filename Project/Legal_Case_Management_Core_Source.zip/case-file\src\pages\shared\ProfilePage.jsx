import React, { useState } from 'react';
import { Mail, Phone, MapPin, Pencil, Lock, Briefcase } from 'lucide-react';
import Modal from '../../components/ui/Modal.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function ProfilePage({ role }) {
  const { user, profile, updateProfile, pushToast } = useApp();

  // Use the current logged-in user from context
  const profileData = user?.full_name
    ? {
        id: role === 'lawyer' ? (user.lawyer_id ? String(user.lawyer_id) : '') : (user.client_id ? String(user.client_id) : ''),
        name: user.full_name || '',
        email: user.email || '',
        phone: user.phone || '',
        role: role === 'lawyer' ? 'Lawyer' : 'Client',
        specialization: '',
        address: '',
        initials: getInitials(user.full_name),
      }
    : profile[role];

  const [editOpen, setEditOpen] = useState(false);
  const [form, setForm] = useState({ name: '', email: '', phone: '', address: '', specialization: '' });

  function getInitials(name) {
    if (!name) return '';
    return name
      .split(' ')
      .map((w) => w[0])
      .join('')
      .toUpperCase()
      .slice(0, 2);
  }

  const openEditor = () => {
    setForm({
      name: profileData?.name || '',
      email: profileData?.email || '',
      phone: profileData?.phone || '',
      address: profileData?.address || '',
      specialization: profileData?.specialization || '',
    });
    setEditOpen(true);
  };

  if (!profileData) {
    return (
      <div className="page">
        <div className="empty-state">
          <h4>Profile not available</h4>
        </div>
      </div>
    );
  }

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const save = (e) => {
    e.preventDefault();
    const updates = { name: form.name, email: form.email, phone: form.phone };
    if (role === 'lawyer') updates.specialization = form.specialization;
    else updates.address = form.address;
    updateProfile(role, updates);
    setEditOpen(false);
    pushToast('Profile updated successfully.');
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1>Profile</h1>
        <div className="subtitle">Your account details.</div>
      </div>

      <div className="chart-card" style={{ maxWidth: 760 }}>
        <div className="profile-card">
          <div className="avatar lg">{profileData.initials}</div>
          <div className="profile-info">
            <h2>{profileData.name}</h2>
            <span className="badge badge-active">
              <span className="badge-dot" /> {profileData.role}
            </span>
            {profileData.specialization && (
              <div style={{ marginTop: 8, fontSize: 13, color: 'var(--text-soft)', display: 'flex', alignItems: 'center', gap: 6 }}>
                <Briefcase size={14} /> {profileData.specialization}
              </div>
            )}
          </div>
        </div>

        <div className="detail-strip">
          <div className="info-item">
            <div className="label">Email</div>
            <div className="value" style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Mail size={14} style={{ color: 'var(--burgundy)' }} /> {profileData.email}</div>
          </div>
          <div className="info-item">
            <div className="label">Phone</div>
            <div className="value" style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Phone size={14} style={{ color: 'var(--burgundy)' }} /> {profileData.phone || '—'}</div>
          </div>
          {profileData.address && (
            <div className="info-item">
              <div className="label">Address</div>
              <div className="value" style={{ display: 'flex', alignItems: 'center', gap: 6 }}><MapPin size={14} style={{ color: 'var(--burgundy)' }} /> {profileData.address}</div>
            </div>
          )}
          <div className="info-item">
            <div className="label">User ID</div>
            <div className="value">{profileData.id || '—'}</div>
          </div>
        </div>

        <div style={{ display: 'flex', gap: 10, marginTop: 24, paddingTop: 20, borderTop: '1px solid var(--border)' }}>
          <button className="btn btn-primary" onClick={openEditor}>
            <Pencil size={15} /> Edit Profile
          </button>
          <button className="btn btn-secondary" onClick={() => pushToast('Password change is simulated in this demo.')}>
            <Lock size={15} /> Change Password
          </button>
        </div>
      </div>

      <Modal
        open={editOpen}
        onClose={() => setEditOpen(false)}
        title="Edit Profile"
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setEditOpen(false)}>Cancel</button>
            <button type="submit" className="btn btn-primary" form="profile-form">Save Changes</button>
          </>
        }
      >
        <form id="profile-form" className="modal-body" onSubmit={save}>
          <div className="field">
            <label className="field-label">Full Name</label>
            <input className="input" value={form.name} onChange={(e) => set('name', e.target.value)} />
          </div>
          <div className="field">
            <label className="field-label">Email</label>
            <input className="input" type="email" value={form.email} onChange={(e) => set('email', e.target.value)} />
          </div>
          <div className="field">
            <label className="field-label">Phone</label>
            <input className="input" value={form.phone} onChange={(e) => set('phone', e.target.value)} />
          </div>
          {role === 'lawyer' ? (
            <div className="field">
              <label className="field-label">Specialization</label>
              <input className="input" value={form.specialization} onChange={(e) => set('specialization', e.target.value)} />
            </div>
          ) : (
            <div className="field">
              <label className="field-label">Address</label>
              <input className="input" value={form.address} onChange={(e) => set('address', e.target.value)} />
            </div>
          )}
        </form>
      </Modal>
    </div>
  );
}
