import React, { useMemo, useState } from "react";
import { Search, Plus, Pencil, Trash2 } from "lucide-react";
import CaseFormModal from "../../components/ui/CaseFormModal.jsx";
import StatusBadge from "../../components/ui/StatusBadge.jsx";
import { useApp } from "../../context/AppContext.jsx";


export default function LawyerCases() {

  const {
    casesList,
    casesLoading,
    addCase,
    updateCase,
    deleteCase,
    pushToast
  } = useApp();


  const [search, setSearch] =
    useState("");

  const [statusFilter, setStatusFilter] =
    useState("All");


  const [modalOpen, setModalOpen] =
    useState(false);

  const [editCase, setEditCase] =
    useState(null);


  // ==================================================
  // FILTER CASES
  // ==================================================

  const filteredCases = useMemo(() => {

    const query =
      search.trim().toLowerCase();


    return casesList.filter((c) => {

      const matchesSearch =
        !query ||

        String(c.id || "")
          .toLowerCase()
          .includes(query) ||

        String(c.title || "")
          .toLowerCase()
          .includes(query) ||

        String(c.type || "")
          .toLowerCase()
          .includes(query) ||

        String(c.clientId || "")
          .toLowerCase()
          .includes(query) ||

        String(c.status || "")
          .toLowerCase()
          .includes(query);


      const matchesStatus =
        statusFilter === "All" ||
        String(c.status)
          .toLowerCase() ===
        statusFilter.toLowerCase();


      return (
        matchesSearch &&
        matchesStatus
      );

    });

  }, [
    casesList,
    search,
    statusFilter
  ]);


  // ==================================================
  // OPEN ADD MODAL
  // ==================================================

  const handleAddClick = () => {

    setEditCase(null);

    setModalOpen(true);

  };


  // ==================================================
  // OPEN EDIT MODAL
  // ==================================================

  const handleEditClick = (caseItem) => {

    setEditCase(caseItem);

    setModalOpen(true);

  };


  // ==================================================
  // SAVE CASE
  // ==================================================

  const handleSave = async (caseData) => {

    try {

      if (editCase) {

        await updateCase(
          editCase.dbId,
          caseData
        );

        pushToast(
          "Case updated successfully.",
          "success"
        );

      } else {

        await addCase(caseData);

        pushToast(
          "Case added successfully.",
          "success"
        );

      }


      setModalOpen(false);

      setEditCase(null);

    } catch (error) {

      console.error(
        "CASE SAVE ERROR:",
        error
      );

      pushToast(
        error.message ||
        "Could not save case.",
        "error"
      );

      throw error;

    }

  };


  // ==================================================
  // DELETE CASE
  // ==================================================

  const handleDelete = async (caseItem) => {

    const confirmed =
      window.confirm(
        `Are you sure you want to delete ${caseItem.id}?`
      );


    if (!confirmed) {
      return;
    }


    try {

      await deleteCase(
        caseItem.dbId
      );

      pushToast(
        "Case deleted successfully.",
        "success"
      );

    } catch (error) {

      console.error(
        "DELETE CASE ERROR:",
        error
      );

      pushToast(
        error.message ||
        "Could not delete case.",
        "error"
      );

    }

  };


  return (

    <div className="page">

      {/* ============================================ */}
      {/* HEADER */}
      {/* ============================================ */}

      <div className="page-header">

        <div>

          <h1>
            Cases
          </h1>

          <p>
            Manage legal cases
          </p>

        </div>


        <button
          className="btn btn-primary"
          onClick={handleAddClick}
        >

          <Plus size={18} />

          Add Case

        </button>

      </div>


      {/* ============================================ */}
      {/* FILTERS */}
      {/* ============================================ */}

      <div className="toolbar">

        <div className="search-box">

          <Search size={18} />

          <input
            type="text"
            placeholder="Search cases..."
            value={search}
            onChange={(e) =>
              setSearch(e.target.value)
            }
          />

        </div>


        <select
          value={statusFilter}
          onChange={(e) =>
            setStatusFilter(e.target.value)
          }
        >

          <option value="All">
            All Status
          </option>

          <option value="Active">
            Active
          </option>

          <option value="Pending">
            Pending
          </option>

          <option value="Closed">
            Closed
          </option>

        </select>

      </div>


      {/* ============================================ */}
      {/* CASE TABLE */}
      {/* ============================================ */}

      <div className="card">

        {casesLoading ? (

          <div className="empty-state">
            Loading cases...
          </div>

        ) : filteredCases.length === 0 ? (

          <div className="empty-state">

            <h3>
              No cases found
            </h3>

            <p>
              Add a case or change your search.
            </p>

          </div>

        ) : (

          <div className="table-container">

            <table className="data-table">

              <thead>

                <tr>

                  <th>
                    Case Number
                  </th>

                  <th>
                    Title
                  </th>

                  <th>
                    Type
                  </th>

                  <th>
                    Client
                  </th>

                  <th>
                    Lawyer
                  </th>

                  <th>
                    Court
                  </th>

                  <th>
                    Filing Date
                  </th>

                  <th>
                    Status
                  </th>

                  <th>
                    Actions
                  </th>

                </tr>

              </thead>


              <tbody>

                {filteredCases.map((c) => (

                  <tr key={c.dbId}>

                    <td>
                      <strong>
                        {c.id}
                      </strong>
                    </td>


                    <td>
                      {c.title || "—"}
                    </td>


                    <td>
                      {c.type || "—"}
                    </td>


                    <td>
                      Client {c.clientId}
                    </td>


                    <td>
                      Lawyer {c.lawyerId}
                    </td>


                    <td>
                      {c.court || "—"}
                    </td>


                    <td>
                      {c.filingDate || "—"}
                    </td>


                    <td>

                      <StatusBadge
                        status={c.status}
                      />

                    </td>


                    <td>

                      <div className="table-actions">

                        <button
                          className="icon-btn"
                          title="Edit case"
                          onClick={() =>
                            handleEditClick(c)
                          }
                        >

                          <Pencil size={17} />

                        </button>


                        <button
                          className="icon-btn danger"
                          title="Delete case"
                          onClick={() =>
                            handleDelete(c)
                          }
                        >

                          <Trash2 size={17} />

                        </button>

                      </div>

                    </td>

                  </tr>

                ))}

              </tbody>

            </table>

          </div>

        )}

      </div>


      {/* ============================================ */}
      {/* CASE FORM */}
      {/* ============================================ */}

      <CaseFormModal
        key={
          editCase
            ? `edit-${editCase.dbId}`
            : "new-case"
        }

        open={modalOpen}

        onClose={() => {

          setModalOpen(false);

          setEditCase(null);

        }}

        onSave={handleSave}

        editCase={editCase}
      />

    </div>

  );

}