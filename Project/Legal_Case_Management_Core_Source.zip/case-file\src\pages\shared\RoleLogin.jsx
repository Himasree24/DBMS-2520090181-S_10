import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Scale, ArrowLeft, Mail, Lock } from 'lucide-react';
import { useApp } from '../../context/AppContext.jsx';

export default function RoleLogin({ role }) {
  const { login } = useApp();
  const navigate = useNavigate();
  const isLawyer = role === 'lawyer';

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await login(email.trim(), password, role);
      navigate(`/${role}/dashboard`);
    } catch (err) {
      setError(err.message || 'Login failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-wrap">
      <div className="login-glow glow-1" />
      <div className="login-glow glow-3" />

      <div className="login-left">
        <div className="login-brand">
          <div className="brand-mark">
            <Scale size={22} />
          </div>
          <div>
            <div className="brand-name">CASE FILE</div>
            <div className="brand-tag">Legal Management Portal</div>
          </div>
        </div>

        <div className="login-lead">
          <div className="eyebrow">Legal Case Management &amp; Analytics</div>
          <h1>
            {isLawyer
              ? 'Every argument, prepared. Every case, accounted.'
              : 'Your legal matters, clearly tracked.'}
          </h1>
          <p>
            Sign in to continue to the {isLawyer ? 'advocate' : 'client'} portal
            where every case, hearing and document is managed with clarity and
            precision.
          </p>
        </div>

        <div className="login-foot">© 2026 CASE FILE · Law Practice Management</div>
      </div>

      <div className="login-right">
        <div className="login-glow glow-2" />
        <div className="auth-panel">
          <button className="back-link" onClick={() => navigate('/')}>
            <ArrowLeft size={15} /> Back to role selection
          </button>

          <div className="auth-heading">{isLawyer ? 'Welcome back, Advocate.' : 'Welcome back.'}</div>
          <div className="auth-sub">
            {isLawyer
              ? 'Sign in to access your legal case management portal.'
              : 'Sign in to access your legal case information.'}
          </div>

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="field">
              <label className="field-label" htmlFor="login-email">Email</label>
              <div className="input-icon">
                <Mail size={16} />
                <input
                  id="login-email"
                  className="input"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  autoComplete="email"
                  required
                />
              </div>
            </div>

            <div className="field">
              <label className="field-label" htmlFor="login-password">Password</label>
              <div className="input-icon">
                <Lock size={16} />
                <input
                  id="login-password"
                  className="input"
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  autoComplete="current-password"
                  required
                />
              </div>
            </div>

            {error && <div className="auth-error">{error}</div>}

            <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
              {loading ? 'Signing in...' : 'Sign In'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
