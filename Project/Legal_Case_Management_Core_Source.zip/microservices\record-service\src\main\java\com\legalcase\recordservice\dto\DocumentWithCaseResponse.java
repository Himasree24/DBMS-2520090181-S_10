package com.legalcase.recordservice.dto;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Aggregated response combining document data with case information
 * retrieved from Case Service via REST API.
 */
public class DocumentWithCaseResponse {

    private DocumentInfo document;
    private Map<String, Object> caseInfo;

    public DocumentWithCaseResponse() {
    }

    public DocumentWithCaseResponse(DocumentInfo document, Map<String, Object> caseInfo) {
        this.document = document;
        this.caseInfo = caseInfo;
    }

    public DocumentInfo getDocument() {
        return document;
    }

    public void setDocument(DocumentInfo document) {
        this.document = document;
    }

    public Map<String, Object> getCaseInfo() {
        return caseInfo;
    }

    public void setCaseInfo(Map<String, Object> caseInfo) {
        this.caseInfo = caseInfo;
    }

    /**
     * Inner class for document information.
     */
    public static class DocumentInfo {
        private Integer documentId;
        private Integer caseId;
        private String documentName;
        private String documentType;
        private Integer uploadedBy;
        private LocalDateTime uploadDate;
        private String filePath;

        public DocumentInfo() {
        }

        public DocumentInfo(Integer documentId, Integer caseId, String documentName,
                            String documentType, Integer uploadedBy, LocalDateTime uploadDate,
                            String filePath) {
            this.documentId = documentId;
            this.caseId = caseId;
            this.documentName = documentName;
            this.documentType = documentType;
            this.uploadedBy = uploadedBy;
            this.uploadDate = uploadDate;
            this.filePath = filePath;
        }

        public Integer getDocumentId() { return documentId; }
        public void setDocumentId(Integer documentId) { this.documentId = documentId; }
        public Integer getCaseId() { return caseId; }
        public void setCaseId(Integer caseId) { this.caseId = caseId; }
        public String getDocumentName() { return documentName; }
        public void setDocumentName(String documentName) { this.documentName = documentName; }
        public String getDocumentType() { return documentType; }
        public void setDocumentType(String documentType) { this.documentType = documentType; }
        public Integer getUploadedBy() { return uploadedBy; }
        public void setUploadedBy(Integer uploadedBy) { this.uploadedBy = uploadedBy; }
        public LocalDateTime getUploadDate() { return uploadDate; }
        public void setUploadDate(LocalDateTime uploadDate) { this.uploadDate = uploadDate; }
        public String getFilePath() { return filePath; }
        public void setFilePath(String filePath) { this.filePath = filePath; }
    }
}
