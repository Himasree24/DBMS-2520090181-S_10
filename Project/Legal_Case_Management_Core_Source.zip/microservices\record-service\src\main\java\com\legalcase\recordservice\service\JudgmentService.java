package com.legalcase.recordservice.service;

import com.legalcase.recordservice.client.CaseServiceClient;
import com.legalcase.recordservice.dto.JudgmentCreateRequest;
import com.legalcase.recordservice.dto.JudgmentResponse;
import com.legalcase.recordservice.dto.JudgmentUpdateRequest;
import com.legalcase.recordservice.entity.Judgment;
import com.legalcase.recordservice.repository.JudgmentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class JudgmentService {

    private final JudgmentRepository judgmentRepository;
    private final CaseServiceClient caseServiceClient;

    public JudgmentService(JudgmentRepository judgmentRepository,
                           CaseServiceClient caseServiceClient) {
        this.judgmentRepository = judgmentRepository;
        this.caseServiceClient = caseServiceClient;
    }

    public List<JudgmentResponse> getAllJudgments() {
        return judgmentRepository.findAll().stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    public JudgmentResponse getJudgmentById(Integer id) {
        Judgment judgment = judgmentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Judgment not found with id: " + id));
        return toResponse(judgment);
    }

    public List<JudgmentResponse> getJudgmentsByCaseId(Integer caseId) {
        return judgmentRepository.findByCaseId(caseId).stream()
            .map(this::toResponse)
            .collect(Collectors.toList());
    }

    @Transactional
    public JudgmentResponse createJudgment(JudgmentCreateRequest request) {
        // Validate case exists via Case Service
        if (!caseServiceClient.getCaseById(request.getCaseId()).containsKey("caseId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Case not found with id: " + request.getCaseId());
        }

        Judgment judgment = new Judgment();
        judgment.setCaseId(request.getCaseId());
        judgment.setJudgmentDate(request.getJudgmentDate());
        judgment.setDecision(request.getDecision());
        judgment.setSummary(request.getSummary());
        judgment.setRemarks(request.getRemarks());

        Judgment saved = judgmentRepository.save(judgment);
        return toResponse(saved);
    }

    @Transactional
    public JudgmentResponse updateJudgment(Integer id, JudgmentUpdateRequest request) {
        Judgment judgment = judgmentRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Judgment not found with id: " + id));

        // Validate case exists via Case Service
        if (!caseServiceClient.getCaseById(request.getCaseId()).containsKey("caseId")) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Case not found with id: " + request.getCaseId());
        }

        judgment.setCaseId(request.getCaseId());
        judgment.setJudgmentDate(request.getJudgmentDate());
        judgment.setDecision(request.getDecision());
        judgment.setSummary(request.getSummary());
        judgment.setRemarks(request.getRemarks());

        Judgment updated = judgmentRepository.save(judgment);
        return toResponse(updated);
    }

    @Transactional
    public void deleteJudgment(Integer id) {
        if (!judgmentRepository.existsById(id)) {
            throw new RuntimeException("Judgment not found with id: " + id);
        }
        judgmentRepository.deleteById(id);
    }

    private JudgmentResponse toResponse(Judgment judgment) {
        return new JudgmentResponse(
            judgment.getJudgmentId(),
            judgment.getCaseId(),
            judgment.getJudgmentDate(),
            judgment.getDecision(),
            judgment.getSummary(),
            judgment.getRemarks()
        );
    }
}
