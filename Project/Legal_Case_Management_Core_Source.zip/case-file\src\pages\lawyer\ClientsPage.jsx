import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import SearchBar from '../../components/ui/SearchBar.jsx';
import SortHeader from '../../components/ui/SortHeader.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function ClientsPage() {
  const navigate = useNavigate();
  const { clientsList, casesList, clientsList: clients } = useApp();
  const [search, setSearch] = useState('');
  const [sort, setSort] = useState({ key: '', dir: 'asc' });

  const allClients = useMemo(() => {
    let list = clientsList.map((cl) => {
      const userCases = casesList.filter((c) => c.clientId === String(cl.client_id));
      return {
        ...cl,
        name: cl.user_id ? `Client ${cl.client_id}` : `Client ${cl.client_id}`,
        email: '',
        phone: cl.phone || '',
        activeCases: userCases.filter((c) => c.status === 'Active').length,
        totalCases: userCases.length,
      };
    });
    list = list.filter((cl) => {
      const s = search.toLowerCase();
      return cl.name.toLowerCase().includes(s) || cl.email.toLowerCase().includes(s) || String(cl.client_id).toLowerCase().includes(s);
    });
    return list;
  }, [clientsList, casesList, search]);

  const sorted = useMemo(() => {
    let list = [...allClients];
    if (sort.key) {
      list.sort((a, b) => {
        let av = a[sort.key], bv = b[sort.key];
        if (typeof av === 'string') { av = av.toLowerCase(); bv = bv.toLowerCase(); }
        if (av < bv) return sort.dir === 'asc' ? -1 : 1;
        if (av > bv) return sort.dir === 'asc' ? 1 : -1;
        return 0;
      });
    }
    return list;
  }, [allClients, sort]);

  const toggleSort = (key) => {
    setSort((s) => (s.key === key ? { key, dir: s.dir === 'asc' ? 'desc' : 'asc' } : { key, dir: 'asc' }));
  };

  return (
    <div className="page">
      <div className="page-header">
        <h1>Clients</h1>
        <div className="subtitle">Manage the clients associated with your practice.</div>
      </div>

      <div className="toolbar">
        <SearchBar value={search} onChange={setSearch} placeholder="Search clients..." />
      </div>

      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <SortHeader label="Client ID" k="client_id" sortKey={sort.key} sortDir={sort.dir} onSort={toggleSort} />
              <SortHeader label="Client Name" k="name" sortKey={sort.key} sortDir={sort.dir} onSort={toggleSort} />
              <th>Email</th>
              <th>Phone</th>
              <SortHeader label="Active Cases" k="activeCases" sortKey={sort.key} sortDir={sort.dir} onSort={toggleSort} />
              <SortHeader label="Total Cases" k="totalCases" sortKey={sort.key} sortDir={sort.dir} onSort={toggleSort} />
            </tr>
          </thead>
          <tbody>
            {sorted.map((cl) => (
              <tr key={cl.client_id} style={{ cursor: 'pointer' }} onClick={() => navigate(`/lawyer/clients/${cl.client_id}`)}>
                <td className="cell-tight">{cl.client_id}</td>
                <td style={{ fontWeight: 500 }}>{cl.name}</td>
                <td className="cell-muted">{cl.email}</td>
                <td className="cell-tight">{cl.phone}</td>
                <td><span className="badge badge-active"><span className="badge-dot" />{cl.activeCases}</span></td>
                <td className="cell-muted">{cl.totalCases}</td>
              </tr>
            ))}
            {sorted.length === 0 && (
              <tr><td colSpan={6}><div className="empty-state"><h4>No clients found</h4></div></td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
