import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Scale, ArrowLeft, Mail, Lock, User, Briefcase } from 'lucide-react';
import { registerLawyer, registerClient } from '../../api.js';

export default function RegisterPage({ role }) {
  const navigate = useNavigate();
  const isLawyer = role === 'lawyer';

  const [formData, setFormData] = useState({
    full_name: '',
    email: '',
    password: '',
    confirmPassword: '',
    bar_registration_no: '',
    specialization: '',
    years_experience: '',
    address: '',
    phone: '',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const validate = () => {
    if (!formData.full_name.trim()) return 'Full name is required.';
    if (!formData.email.trim()) return 'Email is required.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) return 'Please enter a valid email address.';
    if (!formData.password) return 'Password is required.';
    if (formData.password.length < 6) return 'Password must be at least 6 characters.';
    if (!formData.confirmPassword) return 'Please confirm your password.';
    if (formData.password !== formData.confirmPassword) return 'Passwords do not match.';
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');

    const validationError = validate();
    if (validationError) {
      setError(validationError);
      return;
    }

    setLoading(true);

    try {
      const payload = {
        full_name: formData.full_name.trim(),
        email: formData.email.trim(),
        password: formData.password,
      };

      if (isLawyer) {
        if (formData.bar_registration_no) payload.bar_registration_no = formData.bar_registration_no;
        if (formData.specialization) payload.specialization = formData.specialization;
        if (formData.years_experience) payload.years_experience = parseInt(formData.years_experience, 10);
        await registerLawyer(payload);
      } else {
        if (formData.address) payload.address = formData.address;
        if (formData.phone) payload.phone = formData.phone;
        await registerClient(payload);
      }

      navigate(`/${role}/login`);
    } catch (err) {
      setError(err.message || 'Registration failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="login-wrap">
      <div className="login-glow glow-1" />
      <div className="login-glow glow-3" />

      <div className="login-left">
        <div className="login-brand">
          <div className="brand-mark">
            <Scale size={22} />
          </div>
          <div>
            <div className="brand-name">CASE FILE</div>
            <div className="brand-tag">Legal Management Portal</div>
          </div>
        </div>

        <div className="login-lead">
          <div className="eyebrow">Legal Case Management &amp; Analytics</div>
          <h1>
            {isLawyer
              ? 'Join as an Advocate.'
              : 'Join as a Client.'}
          </h1>
          <p>
            Create your {isLawyer ? 'advocate' : 'client'} account to get started.
          </p>
        </div>

        <div className="login-foot">&copy; 2026 CASE FILE &middot; Law Practice Management</div>
      </div>

      <div className="login-right">
        <div className="login-glow glow-2" />
        <div className="auth-panel">
          <button className="back-link" onClick={() => navigate('/')}>
            <ArrowLeft size={15} /> Back to role selection
          </button>

          <div className="auth-heading">
            {isLawyer ? 'Advocate Registration' : 'Client Registration'}
          </div>
          <div className="auth-sub">
            Fill in your details to create your account.
          </div>

          <form className="auth-form" onSubmit={handleSubmit}>
            <div className="field">
              <label className="field-label" htmlFor="reg-name">Full Name</label>
              <div className="input-icon">
                <User size={16} />
                <input
                  id="reg-name"
                  name="full_name"
                  className="input"
                  type="text"
                  value={formData.full_name}
                  onChange={handleChange}
                  placeholder="Your full name"
                  required
                />
              </div>
            </div>

            <div className="field">
              <label className="field-label" htmlFor="reg-email">Email</label>
              <div className="input-icon">
                <Mail size={16} />
                <input
                  id="reg-email"
                  name="email"
                  className="input"
                  type="email"
                  value={formData.email}
                  onChange={handleChange}
                  placeholder="you@example.com"
                  required
                />
              </div>
            </div>

            {isLawyer && (
              <>
                <div className="field">
                  <label className="field-label" htmlFor="reg-bar">Bar Registration No. (optional)</label>
                  <div className="input-icon">
                    <Briefcase size={16} />
                    <input
                      id="reg-bar"
                      name="bar_registration_no"
                      className="input"
                      type="text"
                      value={formData.bar_registration_no}
                      onChange={handleChange}
                      placeholder="e.g., BAR/12345/2020"
                    />
                  </div>
                </div>

                <div className="field">
                  <label className="field-label" htmlFor="reg-spec">Specialization (optional)</label>
                  <div className="input-icon">
                    <Briefcase size={16} />
                    <input
                      id="reg-spec"
                      name="specialization"
                      className="input"
                      type="text"
                      value={formData.specialization}
                      onChange={handleChange}
                      placeholder="e.g., Criminal Law"
                    />
                  </div>
                </div>

                <div className="field">
                  <label className="field-label" htmlFor="reg-exp">Years of Experience (optional)</label>
                  <div className="input-icon">
                    <Briefcase size={16} />
                    <input
                      id="reg-exp"
                      name="years_experience"
                      className="input"
                      type="number"
                      min="0"
                      value={formData.years_experience}
                      onChange={handleChange}
                      placeholder="e.g., 5"
                    />
                  </div>
                </div>
              </>
            )}

            {!isLawyer && (
              <>
                <div className="field">
                  <label className="field-label" htmlFor="reg-address">Address (optional)</label>
                  <div className="input-icon">
                    <User size={16} />
                    <input
                      id="reg-address"
                      name="address"
                      className="input"
                      type="text"
                      value={formData.address}
                      onChange={handleChange}
                      placeholder="Your address"
                    />
                  </div>
                </div>

                <div className="field">
                  <label className="field-label" htmlFor="reg-phone">Phone (optional)</label>
                  <div className="input-icon">
                    <User size={16} />
                    <input
                      id="reg-phone"
                      name="phone"
                      className="input"
                      type="tel"
                      value={formData.phone}
                      onChange={handleChange}
                      placeholder="Your phone number"
                    />
                  </div>
                </div>
              </>
            )}

            <div className="field">
              <label className="field-label" htmlFor="reg-password">Password</label>
              <div className="input-icon">
                <Lock size={16} />
                <input
                  id="reg-password"
                  name="password"
                  className="input"
                  type="password"
                  value={formData.password}
                  onChange={handleChange}
                  placeholder="Create a password"
                  required
                />
              </div>
            </div>

            <div className="field">
              <label className="field-label" htmlFor="reg-confirm">Confirm Password</label>
              <div className="input-icon">
                <Lock size={16} />
                <input
                  id="reg-confirm"
                  name="confirmPassword"
                  className="input"
                  type="password"
                  value={formData.confirmPassword}
                  onChange={handleChange}
                  placeholder="Confirm your password"
                  required
                />
              </div>
            </div>

            {error && <div className="auth-error">{error}</div>}

            <button className="btn btn-primary btn-block" type="submit" disabled={loading}>
              {loading ? 'Creating account...' : 'Create Account'}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
