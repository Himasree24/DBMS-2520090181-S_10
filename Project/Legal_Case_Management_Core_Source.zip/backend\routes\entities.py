from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from database import get_db
from models import (
    Hearing,
    Document,
    Judgment,
    Case,
    Client,
    Lawyer,
    Judge,
    User,
)
from schemas import (
    HearingCreate,
    HearingResponse,
    DocumentResponse,
    JudgmentCreate,
    JudgmentResponse,
)

from auth import get_current_user


# ==================================================
# ROUTER
# ==================================================

router = APIRouter(
    prefix="/entities",
    tags=["Entities"]
)


# ==================================================
# HELPER: Check if user can access a case
# ==================================================

def can_access_case(
    case_id: int,
    current_user: User,
    db: Session,
) -> bool:
    """Check if the current user can access the given case."""
    case = db.query(Case).filter(Case.case_id == case_id).first()
    if not case:
        return False

    if current_user.role == "lawyer":
        return True
    elif current_user.role == "client":
        client = db.query(Client).filter(
            Client.user_id == current_user.user_id
        ).first()
        return client and case.client_id == client.client_id
    return False


# ==================================================
# HEARINGS
# ==================================================

@router.get("/hearings", response_model=list[HearingResponse])
def get_hearings(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get hearings based on the logged-in user's role."""
    if current_user.role == "lawyer":
        hearings = db.query(Hearing).all()
    elif current_user.role == "client":
        client = db.query(Client).filter(
            Client.user_id == current_user.user_id
        ).first()
        if not client:
            return []
        # Get case IDs for this client
        case_ids = [
            c.case_id for c in db.query(Case).filter(
                Case.client_id == client.client_id
            ).all()
        ]
        hearings = db.query(Hearing).filter(
            Hearing.case_id.in_(case_ids)
        ).all() if case_ids else []
    else:
        raise HTTPException(status_code=403, detail="Access denied")

    return hearings


@router.get("/hearings/{hearing_id}", response_model=HearingResponse)
def get_hearing(
    hearing_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    hearing = db.query(Hearing).filter(
        Hearing.hearing_id == hearing_id
    ).first()

    if not hearing:
        raise HTTPException(status_code=404, detail="Hearing not found")

    if not can_access_case(hearing.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    return hearing


@router.post("/hearings", response_model=HearingResponse)
def create_hearing(
    data: HearingCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can create hearings"
        )

    if not can_access_case(data.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    new_hearing = Hearing(
        case_id=data.case_id,
        judge_id=data.judge_id,
        hearing_date=data.hearing_date,
        hearing_time=data.hearing_time,
        court_room=data.court_room,
        purpose=data.purpose,
        status=data.status,
        remarks=data.remarks,
    )

    try:
        db.add(new_hearing)
        db.commit()
        db.refresh(new_hearing)
        return new_hearing
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Could not create hearing. Check case_id and judge_id."
        )


@router.put("/hearings/{hearing_id}", response_model=HearingResponse)
def update_hearing(
    hearing_id: int,
    data: HearingCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can update hearings"
        )

    hearing = db.query(Hearing).filter(
        Hearing.hearing_id == hearing_id
    ).first()

    if not hearing:
        raise HTTPException(status_code=404, detail="Hearing not found")

    if not can_access_case(hearing.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    hearing.case_id = data.case_id
    hearing.judge_id = data.judge_id
    hearing.hearing_date = data.hearing_date
    hearing.hearing_time = data.hearing_time
    hearing.court_room = data.court_room
    hearing.purpose = data.purpose
    hearing.status = data.status
    hearing.remarks = data.remarks

    try:
        db.commit()
        db.refresh(hearing)
        return hearing
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Could not update hearing. Check case_id and judge_id."
        )


@router.delete("/hearings/{hearing_id}")
def delete_hearing(
    hearing_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can delete hearings"
        )

    hearing = db.query(Hearing).filter(
        Hearing.hearing_id == hearing_id
    ).first()

    if not hearing:
        raise HTTPException(status_code=404, detail="Hearing not found")

    if not can_access_case(hearing.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    db.delete(hearing)
    db.commit()
    return {"message": "Hearing deleted successfully", "hearing_id": hearing_id}


# ==================================================
# DOCUMENTS
# ==================================================

@router.get("/documents", response_model=list[DocumentResponse])
def get_documents(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get documents based on the logged-in user's role."""
    if current_user.role == "lawyer":
        documents = db.query(Document).all()
    elif current_user.role == "client":
        client = db.query(Client).filter(
            Client.user_id == current_user.user_id
        ).first()
        if not client:
            return []
        case_ids = [
            c.case_id for c in db.query(Case).filter(
                Case.client_id == client.client_id
            ).all()
        ]
        documents = db.query(Document).filter(
            Document.case_id.in_(case_ids)
        ).all() if case_ids else []
    else:
        raise HTTPException(status_code=403, detail="Access denied")

    return documents


@router.get("/documents/{document_id}", response_model=DocumentResponse)
def get_document(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    document = db.query(Document).filter(
        Document.document_id == document_id
    ).first()

    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    if not can_access_case(document.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    return document


@router.post("/documents", response_model=DocumentResponse)
def create_document(
    data: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can create documents"
        )

    case_id = data.get("case_id")
    if not can_access_case(case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    new_document = Document(
        case_id=case_id,
        document_name=data.get("document_name"),
        document_type=data.get("document_type"),
        uploaded_by=current_user.user_id,
        file_path=data.get("file_path"),
    )

    try:
        db.add(new_document)
        db.commit()
        db.refresh(new_document)
        return new_document
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Could not create document. Check case_id."
        )


@router.put("/documents/{document_id}", response_model=DocumentResponse)
def update_document(
    document_id: int,
    data: dict,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can update documents"
        )

    document = db.query(Document).filter(
        Document.document_id == document_id
    ).first()

    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    if not can_access_case(document.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    document.case_id = data.get("case_id", document.case_id)
    document.document_name = data.get("document_name", document.document_name)
    document.document_type = data.get("document_type", document.document_type)
    document.file_path = data.get("file_path", document.file_path)

    try:
        db.commit()
        db.refresh(document)
        return document
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Could not update document. Check case_id."
        )


@router.delete("/documents/{document_id}")
def delete_document(
    document_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can delete documents"
        )

    document = db.query(Document).filter(
        Document.document_id == document_id
    ).first()

    if not document:
        raise HTTPException(status_code=404, detail="Document not found")

    if not can_access_case(document.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    db.delete(document)
    db.commit()
    return {"message": "Document deleted successfully", "document_id": document_id}


# ==================================================
# JUDGMENTS
# ==================================================

@router.get("/judgments", response_model=list[JudgmentResponse])
def get_judgments(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get judgments based on the logged-in user's role."""
    if current_user.role == "lawyer":
        judgments = db.query(Judgment).all()
    elif current_user.role == "client":
        client = db.query(Client).filter(
            Client.user_id == current_user.user_id
        ).first()
        if not client:
            return []
        case_ids = [
            c.case_id for c in db.query(Case).filter(
                Case.client_id == client.client_id
            ).all()
        ]
        judgments = db.query(Judgment).filter(
            Judgment.case_id.in_(case_ids)
        ).all() if case_ids else []
    else:
        raise HTTPException(status_code=403, detail="Access denied")

    return judgments


@router.get("/judgments/{judgment_id}", response_model=JudgmentResponse)
def get_judgment(
    judgment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    judgment = db.query(Judgment).filter(
        Judgment.judgment_id == judgment_id
    ).first()

    if not judgment:
        raise HTTPException(status_code=404, detail="Judgment not found")

    if not can_access_case(judgment.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    return judgment


@router.post("/judgments", response_model=JudgmentResponse)
def create_judgment(
    data: JudgmentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can create judgments"
        )

    if not can_access_case(data.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    new_judgment = Judgment(
        case_id=data.case_id,
        judgment_date=data.judgment_date,
        decision=data.decision,
        summary=data.summary,
        remarks=data.remarks,
    )

    try:
        db.add(new_judgment)
        db.commit()
        db.refresh(new_judgment)
        return new_judgment
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Could not create judgment. Check case_id."
        )


@router.put("/judgments/{judgment_id}", response_model=JudgmentResponse)
def update_judgment(
    judgment_id: int,
    data: JudgmentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can update judgments"
        )

    judgment = db.query(Judgment).filter(
        Judgment.judgment_id == judgment_id
    ).first()

    if not judgment:
        raise HTTPException(status_code=404, detail="Judgment not found")

    if not can_access_case(judgment.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    judgment.case_id = data.case_id
    judgment.judgment_date = data.judgment_date
    judgment.decision = data.decision
    judgment.summary = data.summary
    judgment.remarks = data.remarks

    try:
        db.commit()
        db.refresh(judgment)
        return judgment
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail="Could not update judgment. Check case_id."
        )


@router.delete("/judgments/{judgment_id}")
def delete_judgment(
    judgment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can delete judgments"
        )

    judgment = db.query(Judgment).filter(
        Judgment.judgment_id == judgment_id
    ).first()

    if not judgment:
        raise HTTPException(status_code=404, detail="Judgment not found")

    if not can_access_case(judgment.case_id, current_user, db):
        raise HTTPException(status_code=403, detail="Access denied")

    db.delete(judgment)
    db.commit()
    return {"message": "Judgment deleted successfully", "judgment_id": judgment_id}


# ==================================================
# JUDGES (read-only for dropdowns)
# ==================================================

@router.get("/judges")
def get_judges(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    """Get all judges for dropdown selections."""
    judges = db.query(Judge).all()
    return [
        {
            "judge_id": j.judge_id,
            "full_name": j.full_name,
            "court_name": j.court_name,
        }
        for j in judges
    ]
