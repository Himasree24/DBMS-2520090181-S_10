package com.legalcase.user.dto;

public class LawyerResponse {

    private Integer lawyerId;
    private Integer userId;
    private String fullName;
    private String email;
    private String barRegistrationNo;
    private String specialization;
    private Integer yearsExperience;
    private String phone;

    public LawyerResponse() {
    }

    public LawyerResponse(Integer lawyerId, Integer userId, String fullName, String email,
                          String barRegistrationNo, String specialization,
                          Integer yearsExperience, String phone) {
        this.lawyerId = lawyerId;
        this.userId = userId;
        this.fullName = fullName;
        this.email = email;
        this.barRegistrationNo = barRegistrationNo;
        this.specialization = specialization;
        this.yearsExperience = yearsExperience;
        this.phone = phone;
    }

    public Integer getLawyerId() {
        return lawyerId;
    }

    public void setLawyerId(Integer lawyerId) {
        this.lawyerId = lawyerId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getBarRegistrationNo() {
        return barRegistrationNo;
    }

    public void setBarRegistrationNo(String barRegistrationNo) {
        this.barRegistrationNo = barRegistrationNo;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public Integer getYearsExperience() {
        return yearsExperience;
    }

    public void setYearsExperience(Integer yearsExperience) {
        this.yearsExperience = yearsExperience;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
