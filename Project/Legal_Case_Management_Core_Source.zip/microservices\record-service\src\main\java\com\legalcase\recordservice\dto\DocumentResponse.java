package com.legalcase.recordservice.dto;

import java.time.LocalDateTime;

public class DocumentResponse {

    private Integer documentId;
    private Integer caseId;
    private String documentName;
    private String documentType;
    private Integer uploadedBy;
    private LocalDateTime uploadDate;
    private String filePath;

    public DocumentResponse() {
    }

    public DocumentResponse(Integer documentId, Integer caseId, String documentName,
                            String documentType, Integer uploadedBy, LocalDateTime uploadDate,
                            String filePath) {
        this.documentId = documentId;
        this.caseId = caseId;
        this.documentName = documentName;
        this.documentType = documentType;
        this.uploadedBy = uploadedBy;
        this.uploadDate = uploadDate;
        this.filePath = filePath;
    }

    public Integer getDocumentId() { return documentId; }
    public void setDocumentId(Integer documentId) { this.documentId = documentId; }
    public Integer getCaseId() { return caseId; }
    public void setCaseId(Integer caseId) { this.caseId = caseId; }
    public String getDocumentName() { return documentName; }
    public void setDocumentName(String documentName) { this.documentName = documentName; }
    public String getDocumentType() { return documentType; }
    public void setDocumentType(String documentType) { this.documentType = documentType; }
    public Integer getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(Integer uploadedBy) { this.uploadedBy = uploadedBy; }
    public LocalDateTime getUploadDate() { return uploadDate; }
    public void setUploadDate(LocalDateTime uploadDate) { this.uploadDate = uploadDate; }
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
}
