"""
Seed/Fix script for development users.

Generates proper Argon2 password hashes using the SAME PasswordHash.recommended()
configuration used by the application, and updates the users table.

This script is idempotent — running it multiple times will not create duplicates.

Usage:
    cd backend
    .venv\\Scripts\\python.exe seed_users.py
"""

import sys
import os

# Add backend directory to path so we can import from the backend package
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pwdlib import PasswordHash
from database import SessionLocal
from models import User


# ==================================================
# CONFIGURATION
# ==================================================

# Use the SAME hasher configuration as the application
password_hash = PasswordHash.recommended()

# Development users to seed/update
DEV_USERS = [
    {
        "email": "sneha@test.com",
        "password": "lawyer123",
        "full_name": "Sneha Rao",
        "role": "lawyer",
    },
    {
        "email": "rahul@test.com",
        "password": "password123",
        "full_name": "Rahul Sharma",
        "role": "client",
    },
]


# ==================================================
# SEED FUNCTION
# ==================================================

def seed_users():
    db = SessionLocal()

    try:
        for user_data in DEV_USERS:
            email = user_data["email"]
            password = user_data["password"]
            full_name = user_data["full_name"]
            role = user_data["role"]

            # Check if user already exists
            existing_user = db.query(User).filter(
                User.email == email
            ).first()

            # Generate proper Argon2 hash
            hashed_password = password_hash.hash(password)

            if existing_user:
                # Update existing user
                existing_user.password_hash = hashed_password
                existing_user.full_name = full_name
                existing_user.role = role
                print(f"  [UPDATED] {email} -> password set to '{password}'")
            else:
                # Create new user
                new_user = User(
                    full_name=full_name,
                    email=email,
                    password_hash=hashed_password,
                    role=role,
                )
                db.add(new_user)
                print(f"  [CREATED] {email} -> password set to '{password}'")

        db.commit()
        print("\n  Database committed successfully.")

    except Exception as e:
        db.rollback()
        print(f"\n  ERROR: {e}")
        raise

    finally:
        db.close()


# ==================================================
# VERIFY FUNCTION
# ==================================================

def verify_users():
    db = SessionLocal()

    try:
        print("\n  Verification:")
        print("  " + "-" * 60)

        for user_data in DEV_USERS:
            email = user_data["email"]
            password = user_data["password"]

            user = db.query(User).filter(
                User.email == email
            ).first()

            if not user:
                print(f"  [FAIL] {email} — user not found")
                continue

            try:
                is_valid = password_hash.verify(
                    password,
                    user.password_hash
                )
            except Exception as e:
                print(f"  [FAIL] {email} — hash error: {e}")
                continue

            if is_valid:
                print(f"  [OK]   {email} + '{password}' -> verified")
            else:
                print(f"  [FAIL] {email} + '{password}' -> rejected")

            # Also test wrong password is rejected
            try:
                wrong_valid = password_hash.verify(
                    "wrong_password_123",
                    user.password_hash
                )
                if wrong_valid:
                    print(f"  [WARN] {email} — wrong password was accepted!")
            except Exception:
                pass  # Expected — wrong password should fail

    finally:
        db.close()


# ==================================================
# MAIN
# ==================================================

if __name__ == "__main__":
    print("\n  Seeding development users...")
    print("  " + "=" * 60)

    seed_users()
    verify_users()

    print("\n  Done.\n")
