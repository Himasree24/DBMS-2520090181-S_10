import React from 'react';
import { useNavigate } from 'react-router-dom';
import { FolderOpen, CalendarDays, FileText, Bell, ArrowRight } from 'lucide-react';
import MetricCard from '../../components/ui/MetricCard.jsx';
import StatusBadge from '../../components/ui/StatusBadge.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function ClientDashboard() {
  const navigate = useNavigate();
  const { casesList, analyticsData, user } = useApp();
  const clientId = user?.client_id ? String(user.client_id) : null;

  const myCases = clientId
    ? casesList.filter((c) => c.clientId === clientId)
    : [];
  const activeCases = myCases.filter((c) => c.status === 'Active');
  const pendingCases = myCases.filter((c) => c.status === 'Pending');
  const closedCases = myCases.filter((c) => c.status === 'Closed');

  // Use analytics data for hearings and documents
  const totalHearings = analyticsData?.total_hearings || 0;
  const totalDocuments = analyticsData?.total_documents || 0;

  // Get next hearing from analytics data
  const hearingsByMonth = analyticsData?.hearings_by_month || [];
  const hasUpcomingHearings = hearingsByMonth.length > 0;

  return (
    <div className="page">
      <div className="page-header">
        <h1>Welcome back.</h1>
        <div className="subtitle">Here's an overview of your legal matters.</div>
      </div>

      <div className="metrics-grid">
        <MetricCard icon={<FolderOpen size={20} />} label="My Active Cases" value={activeCases.length} info="in progress" tone="burgundy" onClick={() => navigate('/client/cases')} />
        <MetricCard icon={<CalendarDays size={20} />} label="Total Hearings" value={totalHearings} info="across your cases" tone="amber" onClick={() => navigate('/client/hearings')} />
        <MetricCard icon={<FileText size={20} />} label="Documents" value={totalDocuments} info="shared with you" tone="violet" onClick={() => navigate('/client/documents')} />
        <MetricCard icon={<Bell size={20} />} label="Case Updates" value={pendingCases.length} info="pending cases" tone="crimson" onClick={() => navigate('/client/cases')} />
      </div>

      <div className="grid-2-1">
        <div className="detail-section">
          <div className="section-head">
            <div className="section-title">My Cases</div>
            <button className="btn btn-outline btn-sm" onClick={() => navigate('/client/cases')}>
              View All <ArrowRight size={14} />
            </button>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
            {myCases.length === 0 ? (
              <div className="empty-state">
                <h4>No cases found</h4>
                <p>You have no cases assigned to your account.</p>
              </div>
            ) : (
              myCases.map((c) => (
                <div className="case-card" key={c.id} style={{ boxShadow: 'none', border: '1px solid var(--border)' }}>
                  <div className="case-card-head">
                    <span className="case-id-chip">{c.id}</span>
                    <StatusBadge status={c.status} />
                  </div>
                  <div className="case-title">{c.title}</div>
                  <div className="case-meta">
                    <div className="case-meta-item">
                      <div className="label">Case Type</div>
                      <div className="value">{c.type}</div>
                    </div>
                    <div className="case-meta-item">
                      <div className="label">Filing Date</div>
                      <div className="value">{c.filingDate}</div>
                    </div>
                  </div>
                  <button className="btn btn-primary btn-sm" style={{ marginTop: 18 }} onClick={() => navigate(`/client/cases/${c.id}`)}>
                    View Case <ArrowRight size={14} />
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        <div>
          <button
            className="next-hearing clickable-block"
            style={{ marginBottom: 20, width: '100%', textAlign: 'left', border: 'none', cursor: 'pointer' }}
            onClick={() => hasUpcomingHearings && navigate('/client/hearings')}
          >
            <div className="eyebrow">Hearing Activity</div>
            <h3>{hasUpcomingHearings ? 'Hearings Available' : 'No Upcoming Hearings'}</h3>
            <div className="date">{hasUpcomingHearings ? `${totalHearings} total hearings` : '—'}</div>
            <div className="time-row"><span style={{ color: 'var(--amber)' }}>Status:</span> {hasUpcomingHearings ? 'See hearings page' : 'No data'}</div>
          </button>

          <div className="detail-section">
            <div className="section-title">Case Summary</div>
            <div className="timeline" style={{ marginTop: 18 }}>
              <div className="timeline-item">
                <div className="timeline-dot" />
                <div className="timeline-date">Total Cases</div>
                <div className="timeline-title">{myCases.length} cases on record</div>
              </div>
              <div className="timeline-item">
                <div className="timeline-dot" />
                <div className="timeline-date">Active</div>
                <div className="timeline-title">{activeCases.length} in progress</div>
              </div>
              <div className="timeline-item">
                <div className="timeline-dot" />
                <div className="timeline-date">Pending</div>
                <div className="timeline-title">{pendingCases.length} awaiting action</div>
              </div>
              <div className="timeline-item">
                <div className="timeline-dot" />
                <div className="timeline-date">Closed</div>
                <div className="timeline-title">{closedCases.length} resolved</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
