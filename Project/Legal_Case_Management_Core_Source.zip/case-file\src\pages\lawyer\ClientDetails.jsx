import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, Mail, Phone, MapPin } from 'lucide-react';
import StatusBadge from '../../components/ui/StatusBadge.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function ClientDetails() {
  const { clientId } = useParams();
  const navigate = useNavigate();
  const { pushToast, clientsList, casesList, hearingsList, documentsList } = useApp();

  const client = clientsList.find((c) => String(c.client_id) === String(clientId));

  if (!client) {
    return (
      <div className="page">
        <div className="empty-state">
          <h4>Client not found</h4>
          <button className="btn btn-outline" onClick={() => navigate('/lawyer/clients')}>Back to clients</button>
        </div>
      </div>
    );
  }

  const clientCases = casesList.filter((c) => c.clientId === String(client.client_id));
  const allHearings = clientCases.flatMap((c) =>
    hearingsList.filter((h) => h.case_id === c.dbId)
  );
  const upcoming = allHearings.filter((h) => h.status === 'Upcoming' || h.status === 'Scheduled');
  const allDocs = clientCases.flatMap((c) =>
    documentsList.filter((d) => d.case_id === c.dbId)
  );

  return (
    <div className="page">
      <button className="btn btn-ghost btn-sm" onClick={() => navigate('/lawyer/clients')} style={{ marginBottom: 16, paddingLeft: 0 }}>
        <ArrowLeft size={16} /> Back to Clients
      </button>

      <div className="detail-hero">
        <div>
          <div className="case-id">Client {client.client_id}</div>
          <h1>Client {client.client_id}</h1>
          <div style={{ marginTop: 14 }}>
            <span className="badge badge-active"><span className="badge-dot" />Client</span>
          </div>
        </div>
      </div>

      <div className="detail-section">
        <div className="section-title">Personal &amp; Contact Information</div>
        <div className="info-grid" style={{ marginTop: 16 }}>
          <div className="info-item">
            <div className="label">Phone</div>
            <div className="value" style={{ display: 'flex', alignItems: 'center', gap: 6 }}><Phone size={14} style={{ color: 'var(--burgundy)' }} /> {client.phone || '—'}</div>
          </div>
          <div className="info-item">
            <div className="label">Address</div>
            <div className="value" style={{ display: 'flex', alignItems: 'center', gap: 6 }}><MapPin size={14} style={{ color: 'var(--burgundy)' }} /> {client.address || '—'}</div>
          </div>
          <div className="info-item">
            <div className="label">Total Cases</div>
            <div className="value">{clientCases.length}</div>
          </div>
        </div>
      </div>

      <div className="detail-section">
        <div className="section-title">Associated Cases</div>
        <div className="table-wrap" style={{ boxShadow: 'none' }}>
          <table className="data-table" style={{ minWidth: '640px' }}>
            <thead>
              <tr>
                <th>Case ID</th>
                <th>Case Title</th>
                <th>Case Type</th>
                <th>Status</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              {clientCases.map((c) => (
                <tr key={c.dbId}>
                  <td className="cell-tight"><button className="link-cell" onClick={() => navigate(`/lawyer/cases/${c.id}`)}>{c.id}</button></td>
                  <td>{c.title}</td>
                  <td className="cell-muted">{c.type}</td>
                  <td><StatusBadge status={c.status} /></td>
                  <td><button className="btn btn-outline btn-sm" onClick={() => navigate(`/lawyer/cases/${c.id}`)}>View</button></td>
                </tr>
              ))}
              {clientCases.length === 0 && (
                <tr><td colSpan={5}><div className="empty-state"><h4>No cases found</h4></div></td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <div className="grid-2">
        <div className="detail-section">
          <div className="section-title">Upcoming Hearings</div>
          {upcoming.length === 0 ? (
            <div className="empty-state"><h4>No upcoming hearings</h4></div>
          ) : (
            upcoming.map((h) => {
              const c = casesList.find((cs) => cs.dbId === h.case_id);
              if (!c) return null;
              return (
                <div key={h.hearing_id} style={{ borderBottom: '1px solid var(--border)', padding: '12px 0' }}>
                  <button
                    className="btn btn-ghost btn-sm"
                    style={{ paddingLeft: 0, marginBottom: 6 }}
                    onClick={() => navigate(`/lawyer/cases/${c.id}`)}
                  >
                    {c.title}
                  </button>
                  <div className="section-sub">{h.hearing_date} · {h.hearing_time} — {h.court_room}</div>
                </div>
              );
            })
          )}
        </div>

        <div className="detail-section">
          <div className="section-title">Documents</div>
          {allDocs.length === 0 ? (
            <div className="empty-state"><h4>No documents</h4></div>
          ) : (
            allDocs.map((d) => (
              <div key={d.document_id} style={{ borderBottom: '1px solid var(--border)', padding: '12px 0', display: 'flex', justifyContent: 'space-between' }}>
                <div>
                  <div style={{ fontWeight: 500 }}>{d.document_name}</div>
                  <div className="section-sub">{d.document_type} · {d.upload_date}</div>
                </div>
                <button
                  className="btn btn-outline btn-sm"
                  onClick={() => { pushToast('Document download started.'); }}
                >
                  View
                </button>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
