import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Bell,
  ChevronDown,
  Menu,
  User,
  Settings,
  LogOut,
  CalendarDays,
  FileText,
  ArrowRightLeft,
  Scale,
} from 'lucide-react';
import { useApp } from '../../context/AppContext.jsx';
import { lawyerNotifications, clientNotifications } from '../../data/index.js';

function notifIcon(type) {
  switch (type) {
    case 'hearing': return <CalendarDays size={16} />;
    case 'document': return <FileText size={16} />;
    case 'status': return <ArrowRightLeft size={16} />;
    case 'judgment': return <Scale size={16} />;
    default: return <Bell size={16} />;
  }
}

function useClickOutside(ref, handler) {
  useEffect(() => {
    function listener(e) {
      if (ref.current && !ref.current.contains(e.target)) handler();
    }
    document.addEventListener('mousedown', listener);
    return () => document.removeEventListener('mousedown', listener);
  }, [ref, handler]);
}

export default function Topbar({ role, user, onMenu }) {
  const { logout } = useApp();
  const navigate = useNavigate();
  const [notifOpen, setNotifOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);
  const [readIds, setReadIds] = useState(() => new Set());
  const notifRef = useRef(null);
  const profileRef = useRef(null);

  useClickOutside(notifRef, () => setNotifOpen(false));
  useClickOutside(profileRef, () => setProfileOpen(false));

  const baseNotifs = role === 'lawyer' ? lawyerNotifications : clientNotifications;
  const notifs = baseNotifs.map((n) => ({ ...n, read: n.read || readIds.has(n.id) }));
  const unreadCount = notifs.filter((n) => !n.read).length;

  const markRead = (id) => setReadIds((prev) => new Set(prev).add(id));
  const markAllRead = () => setReadIds((prev) => new Set([...prev, ...baseNotifs.map((n) => n.id)]));

  const openNotification = (n) => {
    markRead(n.id);
    setNotifOpen(false);
    if (n.caseId) {
      navigate(`/${role}/cases/${n.caseId}`);
    }
  };

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="topbar">
      <button className="menu-btn" onClick={onMenu} aria-label="Open menu">
        <Menu size={22} />
      </button>
      <span
        className="topbar-title"
        style={{ fontFamily: 'var(--font-serif)' }}
      >
        {role === 'lawyer' ? 'Advocate Console' : 'Client Portal'}
      </span>
      <div className="topbar-right">
        <div className="dropdown" ref={notifRef}>
          <button className="bell-btn" onClick={() => setNotifOpen((v) => !v)} aria-label="Notifications">
            <Bell size={20} />
            {unreadCount > 0 && <span className="bell-dot" />}
          </button>
          {notifOpen && (
            <div className="dropdown-menu">
              <div className="dropdown-head">Notifications</div>
              {notifs.map((n) => (
                <div
                  key={n.id}
                  className={`notif-item ${n.read ? '' : 'unread'}`}
                  onClick={() => openNotification(n)}
                >
                  <div className="notif-icon">{notifIcon(n.type)}</div>
                  <div>
                    <div className="notif-title">{n.title}</div>
                    <div className="notif-detail">{n.detail}</div>
                    <div className="notif-date">{n.date}</div>
                  </div>
                </div>
              ))}
              <button
                className="footer-link"
                onClick={() => { markAllRead(); setNotifOpen(false); }}
              >
                Mark all as read
              </button>
            </div>
          )}
        </div>

        <div className="dropdown" ref={profileRef}>
          <button
            className="profile-btn"
            onClick={() => setProfileOpen((v) => !v)}
          >
            <div className="avatar">{user.initials}</div>
            <div className="profile-meta">
              <div className="name">{user.name}</div>
              <div className="role">{user.role}</div>
            </div>
            <ChevronDown size={16} style={{ color: 'var(--text-faint)' }} />
          </button>
          {profileOpen && (
            <div className="dropdown-menu" style={{ minWidth: '220px' }}>
              <button
                className="profile-menu-item"
                onClick={() => { setProfileOpen(false); navigate(`/${role}/profile`); }}
              >
                <User size={16} /> My Profile
              </button>
              <button
                className="profile-menu-item"
                onClick={() => { setProfileOpen(false); navigate(`/${role}/settings`); }}
              >
                <Settings size={16} /> Settings
              </button>
              <div className="divider" />
              <button className="profile-menu-item danger" onClick={handleLogout}>
                <LogOut size={16} /> Logout
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}