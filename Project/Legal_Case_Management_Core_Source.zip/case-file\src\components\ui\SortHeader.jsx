import React from 'react';
import { ArrowUpDown, ArrowUp, ArrowDown } from 'lucide-react';

export default function SortHeader({ label, k, sortKey, sortDir, onSort }) {
  const active = sortKey === k;
  return (
    <th>
      <span
        className="sortable"
        style={{ color: active ? 'var(--amber)' : undefined }}
        onClick={() => onSort(k)}
      >
        {label}{' '}
        {active ? (sortDir === 'asc' ? <ArrowUp size={13} /> : <ArrowDown size={13} />) : <ArrowUpDown size={13} />}
      </span>
    </th>
  );
}