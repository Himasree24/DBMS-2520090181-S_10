import React from 'react';
import {
  Briefcase, FolderOpen, Hourglass, CheckCircle2, CalendarDays, FileText,
} from 'lucide-react';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  BarChart, Bar, XAxis, YAxis, CartesianGrid,
  LineChart, Line,
} from 'recharts';
import MetricCard from '../../components/ui/MetricCard.jsx';
import { useApp } from '../../context/AppContext.jsx';

const STATUS_COLORS = ['#181931', '#662249', '#A34054'];
const TYPE_COLORS = ['#662249', '#44174E', '#A34054', '#ED9E5A', '#181931'];

export default function AnalyticsPage() {
  const { analyticsData, analyticsLoading, analyticsError } = useApp();

  // ---- Loading state ----
  if (analyticsLoading && !analyticsData) {
    return (
      <div className="page">
        <div className="page-header">
          <h1>Analytics</h1>
          <div className="subtitle">Loading analytics from database...</div>
        </div>
        <div className="empty-state">
          <h4>Loading analytics...</h4>
          <p>Fetching real data from the database.</p>
        </div>
      </div>
    );
  }

  // ---- Error state ----
  if (analyticsError && !analyticsData) {
    return (
      <div className="page">
        <div className="page-header">
          <h1>Analytics</h1>
          <div className="subtitle">Unable to load analytics</div>
        </div>
        <div className="empty-state">
          <h4>Error loading analytics</h4>
          <p>{analyticsError}</p>
        </div>
      </div>
    );
  }

  // ---- Empty state ----
  if (!analyticsData || analyticsData.total_cases === 0) {
    return (
      <div className="page">
        <div className="page-header">
          <h1>Analytics</h1>
          <div className="subtitle">No data available yet</div>
        </div>
        <div className="empty-state">
          <Briefcase size={40} />
          <h4>No cases found</h4>
          <p>Analytics will appear once cases are added to the database.</p>
          {analyticsError && (
            <p style={{ color: 'var(--crimson)', marginTop: 8 }}>{analyticsError}</p>
          )}
        </div>
      </div>
    );
  }

  const {
    total_cases,
    active_cases,
    pending_cases,
    closed_cases,
    total_hearings,
    total_documents,
    total_judgments,
    cases_by_status,
    cases_by_type,
    cases_by_month,
    hearings_by_month,
    hearings_by_status,
    documents_by_type,
    documents_by_case,
    judgments_by_decision,
  } = analyticsData;

  // Use cases_by_status from API for pie chart
  const statusData = cases_by_status.length > 0
    ? cases_by_status
    : [
        { name: 'Active', value: active_cases },
        { name: 'Pending', value: pending_cases },
        { name: 'Closed', value: closed_cases },
      ];

  // Use cases_by_type from API for bar chart
  const typeData = cases_by_type.length > 0
    ? cases_by_type
    : [{ name: 'No Data', value: 0 }];

  // Use cases_by_month from API for line chart
  const monthData = cases_by_month.length > 0
    ? cases_by_month
    : [{ month: 'No Data', cases: 0 }];

  // Use hearings_by_month from API
  const hearingMonthData = hearings_by_month.length > 0
    ? hearings_by_month
    : [{ month: 'No Data', hearings: 0 }];

  // Use documents_by_case from API
  const docByCaseData = documents_by_case.length > 0
    ? documents_by_case.slice(0, 8)
    : [{ caseId: 'No Data', count: 0 }];

  // Use hearings_by_status from API
  const hearingStatusData = hearings_by_status.length > 0
    ? hearings_by_status
    : [{ name: 'No Data', value: 0 }];

  // Use judgments_by_decision from API
  const judgmentData = judgments_by_decision.length > 0
    ? judgments_by_decision
    : [{ name: 'No Data', value: 0 }];

  // Generate insights from real data
  const insights = [];
  if (active_cases > 0) {
    insights.push(`Active cases currently represent ${total_cases > 0 ? Math.round((active_cases / total_cases) * 100) : 0}% of the case portfolio.`);
  }
  if (pending_cases > 0) {
    insights.push(`${pending_cases} case${pending_cases !== 1 ? 's are' : ' is'} pending and awaiting action.`);
  }
  if (closed_cases > 0) {
    insights.push(`${closed_cases} case${closed_cases !== 1 ? 's have' : ' has'} been closed or resolved.`);
  }
  if (total_hearings > 0) {
    insights.push(`${total_hearings} hearing${total_hearings !== 1 ? 's' : ''} recorded across all cases.`);
  }
  if (total_documents > 0) {
    insights.push(`${total_documents} document${total_documents !== 1 ? 's' : ''} uploaded across all cases.`);
  }
  if (total_judgments > 0) {
    insights.push(`${total_judgments} judgment${total_judgments !== 1 ? 's' : ''} recorded in the database.`);
  }
  if (insights.length === 0) {
    insights.push('No data available yet. Add cases to see insights.');
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Analytics</h1>
        <div className="subtitle">Real-time insights from your case database.</div>
      </div>

      <div className="metrics-grid">
        <MetricCard icon={<Briefcase size={20} />} label="Total Cases" value={total_cases} info="case portfolio" tone="navy" />
        <MetricCard icon={<FolderOpen size={20} />} label="Active Cases" value={active_cases} info="in progress" tone="burgundy" />
        <MetricCard icon={<Hourglass size={20} />} label="Pending Cases" value={pending_cases} info="awaiting action" tone="amber" />
        <MetricCard icon={<CheckCircle2 size={20} />} label="Closed Cases" value={closed_cases} info="resolved" tone="crimson" />
        <MetricCard icon={<CalendarDays size={20} />} label="Total Hearings" value={total_hearings} info="all statuses" tone="violet" />
        <MetricCard icon={<FileText size={20} />} label="Total Documents" value={total_documents} info="across cases" tone="navy" />
      </div>

      <div className="grid-2-1">
        <div className="chart-card">
          <div className="card-title">Cases by Status</div>
          <div className="card-sub">Distribution of the entire case portfolio</div>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={statusData} dataKey="value" nameKey="name" innerRadius={60} outerRadius={85} paddingAngle={2} stroke="none">
                {statusData.map((e, i) => <Cell key={i} fill={STATUS_COLORS[i % STATUS_COLORS.length]} />)}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="chart-legend">
            {statusData.map((d, i) => (
              <div key={d.name} className="legend-item">
                <span className="legend-swatch" style={{ background: STATUS_COLORS[i % STATUS_COLORS.length] }} />
                {d.name} · {d.value}
              </div>
            ))}
          </div>
        </div>

        <div className="chart-card">
          <div className="card-title">Cases by Type</div>
          <div className="card-sub">Case mix across practice areas</div>
          <ResponsiveContainer width="100%" height={260}>
            <BarChart data={typeData} layout="vertical" margin={{ left: 0 }}>
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#eee8e3" />
              <XAxis type="number" stroke="#9c959e" fontSize={12} allowDecimals={false} />
              <YAxis type="category" dataKey="name" stroke="#9c959e" fontSize={12} width={70} />
              <Tooltip />
              <Bar dataKey="value" radius={[0, 4, 4, 0]} barSize={18}>
                {typeData.map((e, i) => <Cell key={i} fill={TYPE_COLORS[i % TYPE_COLORS.length]} />)}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid-2">
        <div className="chart-card">
          <div className="card-title">Cases by Month</div>
          <div className="card-sub">Monthly case filing activity</div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={monthData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee8e3" />
              <XAxis dataKey="month" stroke="#9c959e" fontSize={12} />
              <YAxis stroke="#9c959e" fontSize={12} allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="cases" stroke="#662249" strokeWidth={2.5} dot={{ r: 4, fill: '#ED9E5A', strokeWidth: 0 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <div className="card-title">Hearings by Month</div>
          <div className="card-sub">Monthly hearing activity</div>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={hearingMonthData} margin={{ top: 10, right: 20, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee8e3" />
              <XAxis dataKey="month" stroke="#9c959e" fontSize={12} />
              <YAxis stroke="#9c959e" fontSize={12} allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="hearings" stroke="#662249" strokeWidth={2.5} dot={{ r: 4, fill: '#ED9E5A', strokeWidth: 0 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid-2">
        <div className="chart-card">
          <div className="card-title">Hearings by Status</div>
          <div className="card-sub">Distribution of hearing statuses</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={hearingStatusData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee8e3" />
              <XAxis dataKey="name" stroke="#9c959e" fontSize={11} />
              <YAxis stroke="#9c959e" fontSize={12} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#44174E" radius={[4, 4, 0, 0]} barSize={30} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <div className="card-title">Documents by Case</div>
          <div className="card-sub">Documents uploaded per case</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={docByCaseData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee8e3" />
              <XAxis dataKey="caseId" stroke="#9c959e" fontSize={10} angle={-30} textAnchor="end" height={48} />
              <YAxis stroke="#9c959e" fontSize={12} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="count" fill="#662249" radius={[4, 4, 0, 0]} barSize={16} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid-2">
        <div className="chart-card">
          <div className="card-title">Documents by Type</div>
          <div className="card-sub">Distribution of document types</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={documents_by_type.length > 0 ? documents_by_type : [{ name: 'No Data', value: 0 }]} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee8e3" />
              <XAxis dataKey="name" stroke="#9c959e" fontSize={11} />
              <YAxis stroke="#9c959e" fontSize={12} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#A34054" radius={[4, 4, 0, 0]} barSize={30} />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <div className="chart-card">
          <div className="card-title">Judgments by Decision</div>
          <div className="card-sub">Distribution of judgment outcomes</div>
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={judgmentData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee8e3" />
              <XAxis dataKey="name" stroke="#9c959e" fontSize={11} />
              <YAxis stroke="#9c959e" fontSize={12} allowDecimals={false} />
              <Tooltip />
              <Bar dataKey="value" fill="#181931" radius={[4, 4, 0, 0]} barSize={30} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="chart-card">
        <div className="section-title">Key Insights</div>
        <div className="section-sub" style={{ marginBottom: 18 }}>Automated observations from your case records</div>
        <div className="insight-list">
          {insights.map((insight, i) => (
            <div key={i} className="insight-item">
              <div className="insight-dot" />
              <p>{insight}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
