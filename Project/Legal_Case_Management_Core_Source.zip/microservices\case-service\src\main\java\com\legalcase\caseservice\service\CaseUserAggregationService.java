package com.legalcase.caseservice.service;

import com.legalcase.caseservice.client.UserServiceClient;
import com.legalcase.caseservice.dto.CaseResponse;
import com.legalcase.caseservice.dto.CaseWithUsersResponse;
import com.legalcase.caseservice.entity.Case;
import com.legalcase.caseservice.repository.CaseRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

/**
 * Service that aggregates case data with user information
 * by calling User Service through HTTP REST API.
 */
@Service
public class CaseUserAggregationService {

    private final CaseRepository caseRepository;
    private final UserServiceClient userServiceClient;

    public CaseUserAggregationService(CaseRepository caseRepository,
                                       UserServiceClient userServiceClient) {
        this.caseRepository = caseRepository;
        this.userServiceClient = userServiceClient;
    }

    /**
     * Get a case with aggregated client and lawyer information from User Service.
     *
     * Flow:
     * 1. Load case from local database
     * 2. Call User Service to get client info
     * 3. Call User Service to get lawyer info
     * 4. Return combined response
     */
    public CaseWithUsersResponse getCaseWithUsers(Integer caseId) {
        // Step 1: Load case from local database
        Case caseEntity = caseRepository.findById(caseId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Case not found with id: " + caseId));

        // Step 2: Call User Service to get client information
        Map<String, Object> clientInfo = null;
        if (caseEntity.getClientId() != null) {
            clientInfo = userServiceClient.getClientById(caseEntity.getClientId());
            if (clientInfo == null) {
                throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "Unable to retrieve client information from User Service");
            }
        }

        // Step 3: Call User Service to get lawyer information
        Map<String, Object> lawyerInfo = null;
        if (caseEntity.getLawyerId() != null) {
            lawyerInfo = userServiceClient.getLawyerById(caseEntity.getLawyerId());
            if (lawyerInfo == null) {
                throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                    "Unable to retrieve lawyer information from User Service");
            }
        }

        // Step 4: Build combined response
        CaseWithUsersResponse.CaseInfo caseInfo = new CaseWithUsersResponse.CaseInfo(
            caseEntity.getCaseId(),
            caseEntity.getClientId(),
            caseEntity.getLawyerId(),
            caseEntity.getCaseNumber(),
            caseEntity.getTitle(),
            caseEntity.getCaseType(),
            caseEntity.getDescription(),
            caseEntity.getStatus(),
            caseEntity.getFilingDate(),
            caseEntity.getCourtName()
        );

        return new CaseWithUsersResponse(caseInfo, clientInfo, lawyerInfo);
    }

    /**
     * Validate that a client exists by calling User Service.
     */
    public boolean validateClientExists(Integer clientId) {
        if (clientId == null) {
            return true;
        }
        return userServiceClient.getClientById(clientId) != null;
    }

    /**
     * Validate that a lawyer exists by calling User Service.
     */
    public boolean validateLawyerExists(Integer lawyerId) {
        if (lawyerId == null) {
            return true;
        }
        return userServiceClient.getLawyerById(lawyerId) != null;
    }
}
