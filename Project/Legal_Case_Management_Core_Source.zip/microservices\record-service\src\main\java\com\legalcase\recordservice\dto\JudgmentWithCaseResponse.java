package com.legalcase.recordservice.dto;

import java.time.LocalDate;
import java.util.Map;

/**
 * Aggregated response combining judgment data with case information
 * retrieved from Case Service via REST API.
 */
public class JudgmentWithCaseResponse {

    private JudgmentInfo judgment;
    private Map<String, Object> caseInfo;

    public JudgmentWithCaseResponse() {
    }

    public JudgmentWithCaseResponse(JudgmentInfo judgment, Map<String, Object> caseInfo) {
        this.judgment = judgment;
        this.caseInfo = caseInfo;
    }

    public JudgmentInfo getJudgment() {
        return judgment;
    }

    public void setJudgment(JudgmentInfo judgment) {
        this.judgment = judgment;
    }

    public Map<String, Object> getCaseInfo() {
        return caseInfo;
    }

    public void setCaseInfo(Map<String, Object> caseInfo) {
        this.caseInfo = caseInfo;
    }

    /**
     * Inner class for judgment information.
     */
    public static class JudgmentInfo {
        private Integer judgmentId;
        private Integer caseId;
        private LocalDate judgmentDate;
        private String decision;
        private String summary;
        private String remarks;

        public JudgmentInfo() {
        }

        public JudgmentInfo(Integer judgmentId, Integer caseId, LocalDate judgmentDate,
                            String decision, String summary, String remarks) {
            this.judgmentId = judgmentId;
            this.caseId = caseId;
            this.judgmentDate = judgmentDate;
            this.decision = decision;
            this.summary = summary;
            this.remarks = remarks;
        }

        public Integer getJudgmentId() { return judgmentId; }
        public void setJudgmentId(Integer judgmentId) { this.judgmentId = judgmentId; }
        public Integer getCaseId() { return caseId; }
        public void setCaseId(Integer caseId) { this.caseId = caseId; }
        public LocalDate getJudgmentDate() { return judgmentDate; }
        public void setJudgmentDate(LocalDate judgmentDate) { this.judgmentDate = judgmentDate; }
        public String getDecision() { return decision; }
        public void setDecision(String decision) { this.decision = decision; }
        public String getSummary() { return summary; }
        public void setSummary(String summary) { this.summary = summary; }
        public String getRemarks() { return remarks; }
        public void setRemarks(String remarks) { this.remarks = remarks; }
    }
}
