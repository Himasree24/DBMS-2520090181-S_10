import React, {
  useEffect,
  useState,
} from "react";

import Modal from "../ui/Modal.jsx";
import { useApp } from "../../context/AppContext.jsx";


// ==================================================
// GENERATE CASE NUMBER
// ==================================================

function generateCaseNumber() {

  return `CASE-${Date.now()}`;

}


// ==================================================
// COMPONENT
// ==================================================

export default function CaseFormModal({
  open,
  onClose,
  onSave,
  editCase
}) {

  const { clientsList, lawyersList, user } = useApp();

  const [form, setForm] = useState({
    caseNumber: generateCaseNumber(),

    title: "",

    type: "Civil",

    clientId: "",

    lawyerId: "",

    court: "Telangana High Court",

    filingDate: "",

    description: "",

    status: "Pending",
  });


  const [errors, setErrors] =
    useState({});


  // ==================================================
  // SET DEFAULT VALUES WHEN MODAL OPENS
  // ==================================================

  useEffect(() => {

    if (open) {
      if (editCase) {

        setForm({

          caseNumber:
            editCase.caseNumber ||
            editCase.id ||
            generateCaseNumber(),

          title:
            editCase.title || "",

          type:
            editCase.type || "Civil",

          clientId:
            String(editCase.clientId || ""),

          lawyerId:
            String(editCase.lawyerId || ""),

          court:
            editCase.court ||
            "Telangana High Court",

          filingDate:
            editCase.filingDate || "",

          description:
            editCase.description || "",

          status:
            editCase.status || "Pending",

        });

      } else {

        // For new cases, pre-fill with logged-in user's IDs
        const defaultClientId = user?.client_id ? String(user.client_id) : "";
        const defaultLawyerId = user?.lawyer_id ? String(user.lawyer_id) : "";

        setForm({

          caseNumber:
            generateCaseNumber(),

          title: "",

          type: "Civil",

          clientId: defaultClientId,

          lawyerId: defaultLawyerId,

          court:
            "Telangana High Court",

          filingDate: "",

          description: "",

          status: "Pending",

        });

      }

      setErrors({});
    }

  }, [editCase, open, user]);


  // ==================================================
  // SET FIELD
  // ==================================================

  const set = (key, value) => {

    setForm((previous) => ({
      ...previous,
      [key]: value
    }));

  };


  // ==================================================
  // VALIDATION
  // ==================================================

  const validate = () => {

    const errors = {};


    if (!form.caseNumber.trim()) {

      errors.caseNumber =
        "Case number is required";

    }


    if (!form.title.trim()) {

      errors.title =
        "Case title is required";

    }


    if (!form.clientId) {

      errors.clientId =
        "Select a client";

    }


    if (!form.lawyerId) {

      errors.lawyerId =
        "Select a lawyer";

    }


    if (!form.filingDate) {

      errors.filingDate =
        "Filing date is required";

    }


    if (!form.court.trim()) {

      errors.court =
        "Court is required";

    }


    setErrors(errors);

    return Object.keys(errors).length === 0;

  };


  // ==================================================
  // SUBMIT
  // ==================================================

  const submit = async (event) => {

    event.preventDefault();


    if (!validate()) {
      return;
    }


    // Case Service DTO (CaseCreateRequest) expects camelCase JSON properties
    const caseData = {

      clientId:
        Number(form.clientId),

      lawyerId:
        Number(form.lawyerId),

      caseNumber:
        form.caseNumber.trim(),

      title:
        form.title.trim(),

      caseType:
        form.type,

      description:
        form.description.trim(),

      status:
        form.status,

      filingDate:
        form.filingDate,

      courtName:
        form.court.trim(),

    };


    try {

      await onSave(caseData);

    } catch (error) {

      console.error(
        "CASE SAVE ERROR:",
        error
      );

    }

  };


  return (

    <Modal
      open={open}
      onClose={onClose}

      title={
        editCase
          ? "Edit Case"
          : "Add New Case"
      }

      footer={

        <>

          <button
            type="button"
            className="btn btn-ghost"
            onClick={onClose}
          >
            Cancel
          </button>


          <button
            type="submit"
            className="btn btn-primary"
            form="case-form"
          >

            {editCase
              ? "Update Case"
              : "Save Case"}

          </button>

        </>

      }
    >

      <form
        id="case-form"
        onSubmit={submit}
        className="modal-body"
      >

        {/* ========================================= */}
        {/* CASE NUMBER */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Case Number
          </label>

          <input
            type="text"
            value={form.caseNumber}
            onChange={(e) =>
              set(
                "caseNumber",
                e.target.value
              )
            }
            placeholder="CASE-1001"
          />

          {errors.caseNumber && (

            <span className="form-error">
              {errors.caseNumber}
            </span>

          )}

        </div>


        {/* ========================================= */}
        {/* TITLE */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Case Title
          </label>

          <input
            type="text"
            value={form.title}
            onChange={(e) =>
              set(
                "title",
                e.target.value
              )
            }
            placeholder="Enter case title"
          />

          {errors.title && (

            <span className="form-error">
              {errors.title}
            </span>

          )}

        </div>


        {/* ========================================= */}
        {/* CASE TYPE */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Case Type
          </label>

          <select
            value={form.type}
            onChange={(e) =>
              set(
                "type",
                e.target.value
              )
            }
          >

            <option value="Civil">
              Civil
            </option>

            <option value="Criminal">
              Criminal
            </option>

            <option value="Property">
              Property
            </option>

            <option value="Family">
              Family
            </option>

            <option value="Corporate">
              Corporate
            </option>

            <option value="Inheritance">
              Inheritance
            </option>

          </select>

        </div>


        {/* ========================================= */}
        {/* CLIENT */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Client
          </label>

          <select
            value={form.clientId}
            onChange={(e) =>
              set(
                "clientId",
                e.target.value
              )
            }
          >

            <option value="">
              Select Client
            </option>

            {clientsList.map((client) => {
              const clientId = client.clientId ?? client.client_id;
              const clientName = client.fullName ?? client.full_name ?? `Client ${clientId}`;
              return (
                <option
                  key={clientId}
                  value={clientId}
                >
                  {clientName} (ID: {clientId})
                </option>
              );
            })}

          </select>

          {errors.clientId && (

            <span className="form-error">
              {errors.clientId}
            </span>

          )}

        </div>


        {/* ========================================= */}
        {/* LAWYER */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Lawyer
          </label>

          <select
            value={form.lawyerId}
            onChange={(e) =>
              set(
                "lawyerId",
                e.target.value
              )
            }
          >

            <option value="">
              Select Lawyer
            </option>

            {lawyersList.map((lawyer) => {
              const lawyerId = lawyer.lawyerId ?? lawyer.lawyer_id;
              const lawyerName = lawyer.fullName ?? lawyer.full_name ?? `Lawyer ${lawyerId}`;
              return (
                <option
                  key={lawyerId}
                  value={lawyerId}
                >
                  {lawyerName} (ID: {lawyerId})
                </option>
              );
            })}

          </select>

          {errors.lawyerId && (

            <span className="form-error">
              {errors.lawyerId}
            </span>

          )}

        </div>


        {/* ========================================= */}
        {/* COURT */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Court
          </label>

          <input
            type="text"
            value={form.court}
            onChange={(e) =>
              set(
                "court",
                e.target.value
              )
            }
            placeholder="Court name"
          />

          {errors.court && (

            <span className="form-error">
              {errors.court}
            </span>

          )}

        </div>


        {/* ========================================= */}
        {/* FILING DATE */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Filing Date
          </label>

          <input
            type="date"
            value={form.filingDate}
            onChange={(e) =>
              set(
                "filingDate",
                e.target.value
              )
            }
          />

          {errors.filingDate && (

            <span className="form-error">
              {errors.filingDate}
            </span>

          )}

        </div>


        {/* ========================================= */}
        {/* STATUS */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Status
          </label>

          <select
            value={form.status}
            onChange={(e) =>
              set(
                "status",
                e.target.value
              )
            }
          >

            <option value="Pending">
              Pending
            </option>

            <option value="Active">
              Active
            </option>

            <option value="Closed">
              Closed
            </option>

          </select>

        </div>


        {/* ========================================= */}
        {/* DESCRIPTION */}
        {/* ========================================= */}

        <div className="form-group">

          <label>
            Description
          </label>

          <textarea
            value={form.description}
            onChange={(e) =>
              set(
                "description",
                e.target.value
              )
            }
            placeholder="Enter case description"
            rows="4"
          />

        </div>

      </form>

    </Modal>

  );

}
