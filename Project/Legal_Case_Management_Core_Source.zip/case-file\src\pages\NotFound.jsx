import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Scale, ArrowLeft, Compass } from 'lucide-react';
import { useApp } from '../context/AppContext.jsx';

export default function NotFound() {
  const { role } = useApp();
  const navigate = useNavigate();

  const goHome = () => navigate(role ? `/${role}/dashboard` : '/');

  return (
    <div className="login-wrap auth-center-wrap">
      <div className="login-glow glow-1" />
      <div className="login-glow glow-3" />
      <div className="auth-center">
        <div className="brand-mark lg">
          <Scale size={26} />
        </div>
        <div className="n404">404</div>
        <h1 className="n404-title">Page not found</h1>
        <p className="n404-sub">The page you're looking for doesn't exist.</p>
        <div style={{ display: 'flex', gap: 10, marginTop: 8 }}>
          <button className="btn btn-primary" onClick={goHome}>
            <ArrowLeft size={16} /> Return to Dashboard
          </button>
          {!role && (
            <button className="btn btn-outline" onClick={() => navigate('/')}>
              <Compass size={16} /> Role Selection
            </button>
          )}
        </div>
      </div>
    </div>
  );
}