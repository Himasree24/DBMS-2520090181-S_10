from pydantic import BaseModel
from datetime import date, time
from typing import Optional


# ---------------- USERS ----------------

class UserCreate(BaseModel):
    full_name: str
    email: str
    password: str
    role: str


class UserResponse(BaseModel):
    user_id: int
    full_name: str
    email: str
    role: str
    client_id: Optional[int] = None
    lawyer_id: Optional[int] = None
    phone: Optional[str] = None

    class Config:
        from_attributes = True


class LoginRequest(BaseModel):
    email: str
    password: str


class LoginResponse(BaseModel):
    user_id: int
    full_name: str
    email: str
    role: str
    client_id: Optional[int] = None
    lawyer_id: Optional[int] = None
    phone: Optional[str] = None
    session_token: str


class LawyerRegisterRequest(BaseModel):
    full_name: str
    email: str
    password: str
    confirm_password: str
    bar_registration_no: Optional[str] = None
    specialization: Optional[str] = None
    years_experience: Optional[int] = None
    phone: Optional[str] = None


class ClientRegisterRequest(BaseModel):
    full_name: str
    email: str
    password: str
    confirm_password: str
    address: Optional[str] = None
    phone: Optional[str] = None


# ---------------- CLIENTS ----------------

class ClientCreate(BaseModel):
    user_id: int
    address: Optional[str] = None
    phone: Optional[str] = None


class ClientResponse(BaseModel):
    client_id: int
    user_id: int
    address: Optional[str]
    phone: Optional[str]

    class Config:
        from_attributes = True


# ---------------- LAWYERS ----------------

class LawyerCreate(BaseModel):
    user_id: int
    bar_registration_no: Optional[str] = None
    specialization: Optional[str] = None
    years_experience: Optional[int] = None
    phone: Optional[str] = None


class LawyerResponse(BaseModel):
    lawyer_id: int
    user_id: int
    bar_registration_no: Optional[str]
    specialization: Optional[str]
    years_experience: Optional[int]
    phone: Optional[str] = None

    class Config:
        from_attributes = True


# ---------------- CASES ----------------

class CaseCreate(BaseModel):
    client_id: int
    lawyer_id: int
    case_number: Optional[str] = None
    title: Optional[str] = None
    case_type: Optional[str] = None
    description: Optional[str] = None
    status: Optional[str] = None
    filing_date: Optional[date] = None
    court_name: Optional[str] = None


class CaseResponse(BaseModel):
    case_id: int
    client_id: int
    lawyer_id: int
    case_number: Optional[str]
    title: Optional[str]
    case_type: Optional[str]
    description: Optional[str]
    status: Optional[str]
    filing_date: Optional[date]
    court_name: Optional[str]

    class Config:
        from_attributes = True


# ---------------- JUDGES ----------------

class JudgeCreate(BaseModel):
    full_name: str
    court_name: Optional[str] = None
    appointment_date: Optional[date] = None


class JudgeResponse(BaseModel):
    judge_id: int
    full_name: str
    court_name: Optional[str]
    appointment_date: Optional[date]

    class Config:
        from_attributes = True


# ---------------- HEARINGS ----------------

class HearingCreate(BaseModel):
    case_id: int
    judge_id: int
    hearing_date: Optional[date] = None
    hearing_time: Optional[time] = None
    court_room: Optional[str] = None
    purpose: Optional[str] = None
    status: Optional[str] = None
    remarks: Optional[str] = None


class HearingResponse(BaseModel):
    hearing_id: int
    case_id: int
    judge_id: int
    hearing_date: Optional[date]
    hearing_time: Optional[time]
    court_room: Optional[str]
    purpose: Optional[str]
    status: Optional[str]
    remarks: Optional[str]

    class Config:
        from_attributes = True


# ---------------- DOCUMENTS ----------------

class DocumentResponse(BaseModel):
    document_id: int
    case_id: int
    document_name: Optional[str]
    document_type: Optional[str]
    uploaded_by: Optional[int]
    file_path: Optional[str]

    class Config:
        from_attributes = True


# ---------------- JUDGMENTS ----------------

class JudgmentCreate(BaseModel):
    case_id: int
    judgment_date: Optional[date] = None
    decision: Optional[str] = None
    summary: Optional[str] = None
    remarks: Optional[str] = None


class JudgmentResponse(BaseModel):
    judgment_id: int
    case_id: int
    judgment_date: Optional[date]
    decision: Optional[str]
    summary: Optional[str]
    remarks: Optional[str]

    class Config:
        from_attributes = True