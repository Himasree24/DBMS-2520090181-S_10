package com.legalcase.recordservice.controller;

import com.legalcase.recordservice.dto.HearingCreateRequest;
import com.legalcase.recordservice.dto.HearingResponse;
import com.legalcase.recordservice.dto.HearingUpdateRequest;
import com.legalcase.recordservice.dto.HearingWithCaseResponse;
import com.legalcase.recordservice.service.HearingService;
import com.legalcase.recordservice.service.RecordCaseAggregationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class HearingController {

    private final HearingService hearingService;
    private final RecordCaseAggregationService aggregationService;

    public HearingController(HearingService hearingService,
                             RecordCaseAggregationService aggregationService) {
        this.hearingService = hearingService;
        this.aggregationService = aggregationService;
    }

    @GetMapping("/records/hearings")
    public List<HearingResponse> getAllHearings(
            @RequestParam(required = false) Integer caseId) {
        if (caseId != null) {
            return hearingService.getHearingsByCaseId(caseId);
        }
        return hearingService.getAllHearings();
    }

    @GetMapping("/records/hearings/{id}")
    public ResponseEntity<HearingResponse> getHearingById(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(hearingService.getHearingById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // --------------------------------------------------
    // GET HEARING WITH CASE INFO (Service-to-Service)
    // --------------------------------------------------

    @GetMapping("/records/hearings/{id}/with-case")
    public ResponseEntity<HearingWithCaseResponse> getHearingWithCase(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(aggregationService.getHearingWithCase(id));
        } catch (org.springframework.web.server.ResponseStatusException e) {
            return ResponseEntity.status(e.getStatusCode()).build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/records/hearings")
    public ResponseEntity<HearingResponse> createHearing(@Valid @RequestBody HearingCreateRequest request) {
        HearingResponse created = hearingService.createHearing(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/records/hearings/{id}")
    public ResponseEntity<HearingResponse> updateHearing(@PathVariable Integer id,
                                                         @Valid @RequestBody HearingUpdateRequest request) {
        try {
            return ResponseEntity.ok(hearingService.updateHearing(id, request));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/records/hearings/{id}")
    public ResponseEntity<Void> deleteHearing(@PathVariable Integer id) {
        try {
            hearingService.deleteHearing(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
