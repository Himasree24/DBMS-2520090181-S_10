const API_URL = "http://127.0.0.1:8000";

// Microservice URLs (configurable via Vite env vars)
const USER_SERVICE_URL = import.meta.env.VITE_USER_SERVICE_URL || "http://localhost:8081";
const CASE_SERVICE_URL = import.meta.env.VITE_CASE_SERVICE_URL || "http://localhost:8082";
const RECORD_SERVICE_URL = import.meta.env.VITE_RECORD_SERVICE_URL || "http://localhost:8083";


// ==================================================
// USER STORAGE
// ==================================================

const USER_KEY = "casefile_user";
const SESSION_KEY = "casefile_session_token";


export function getStoredUser() {
  try {
    const raw = localStorage.getItem(USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}


export function storeUser(user) {
  try {
    localStorage.setItem(USER_KEY, JSON.stringify(user));
  } catch {
    // Ignore localStorage errors
  }
}


export function clearUser() {
  try {
    localStorage.removeItem(USER_KEY);
    localStorage.removeItem(SESSION_KEY);
  } catch {
    // Ignore localStorage errors
  }
}


export function getStoredSessionToken() {
  try {
    return localStorage.getItem(SESSION_KEY);
  } catch {
    return null;
  }
}


export function storeSessionToken(token) {
  try {
    localStorage.setItem(SESSION_KEY, token);
  } catch {
    // Ignore localStorage errors
  }
}


// ==================================================
// HELPER FUNCTIONS
// ==================================================

async function handleResponse(response, defaultMessage) {

  if (!response.ok) {

    let message = defaultMessage;

    try {

      const errorData = await response.json();

      if (errorData.detail) {
        message = errorData.detail;
      } else if (errorData.message) {
        message = errorData.message;
      } else if (errorData.error) {
        message = errorData.error;
      }

    } catch {
      // Ignore JSON parsing error
    }

    throw new Error(message);
  }

  // Handle 204 No Content (e.g., DELETE responses)
  if (response.status === 204) {
    return null;
  }

  return response.json();
}


// ==================================================
// AUTHENTICATED FETCH HELPER (FastAPI)
// ==================================================

async function authFetch(url, options = {}) {
  const token = getStoredSessionToken();

  const headers = {
    ...options.headers,
  };

  if (token) {
    headers["X-Session-Token"] = token;
  }

  if (options.body && typeof options.body === 'string') {
    headers["Content-Type"] = "application/json";
  }

  return fetch(url, { ...options, headers });
}


// ==================================================
// SERVICE FETCH HELPERS (Microservices)
// ==================================================

async function serviceFetch(url, options = {}) {
  const headers = {
    ...options.headers,
  };

  if (options.body && typeof options.body === 'string') {
    headers["Content-Type"] = "application/json";
  }

  return fetch(url, { ...options, headers });
}


// ==================================================
// AUTH (FastAPI :8000)
// ==================================================

export async function loginUser(email, password) {

  const response = await fetch(
    `${API_URL}/users/login`,
    {
      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify({ email, password })
    }
  );

  const data = await handleResponse(
    response,
    "Login failed"
  );

  if (data.session_token) {
    storeSessionToken(data.session_token);
  }

  return {
    user_id: data.user_id,
    full_name: data.full_name,
    email: data.email,
    role: data.role,
    client_id: data.client_id,
    lawyer_id: data.lawyer_id,
    phone: data.phone,
  };
}


export async function registerLawyer(formData) {

  const response = await fetch(
    `${API_URL}/users/register/lawyer`,
    {
      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify(formData)
    }
  );

  return handleResponse(
    response,
    "Lawyer registration failed"
  );
}


export async function registerClient(formData) {

  const response = await fetch(
    `${API_URL}/users/register/client`,
    {
      method: "POST",

      headers: {
        "Content-Type": "application/json"
      },

      body: JSON.stringify(formData)
    }
  );

  return handleResponse(
    response,
    "Client registration failed"
  );
}


// ==================================================
// USER SERVICE (:8081)
// ==================================================

export async function getClients() {
  const response = await serviceFetch(`${USER_SERVICE_URL}/clients`);
  return handleResponse(response, "Failed to fetch clients");
}


export async function getLawyers() {
  const response = await serviceFetch(`${USER_SERVICE_URL}/lawyers`);
  return handleResponse(response, "Failed to fetch lawyers");
}


export async function getUsers() {
  const response = await serviceFetch(`${USER_SERVICE_URL}/users`);
  return handleResponse(response, "Failed to fetch users");
}


// ==================================================
// CASE SERVICE (:8082)
// ==================================================

export async function getCases() {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases`);
  return handleResponse(response, "Failed to fetch cases");
}


export async function getCase(caseId) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases/${caseId}`);
  return handleResponse(response, "Failed to fetch case");
}


export async function createCase(caseData) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases`, {
    method: "POST",
    body: JSON.stringify(caseData)
  });
  return handleResponse(response, "Failed to create case");
}


export async function updateCase(caseId, caseData) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases/${caseId}`, {
    method: "PUT",
    body: JSON.stringify(caseData)
  });
  return handleResponse(response, "Failed to update case");
}


export async function deleteCase(caseId) {
  const response = await serviceFetch(`${CASE_SERVICE_URL}/cases/${caseId}`, {
    method: "DELETE"
  });
  return handleResponse(response, "Failed to delete case");
}


// ==================================================
// RECORD SERVICE (:8083) — HEARINGS
// ==================================================

export async function getHearings() {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings`);
  return handleResponse(response, "Failed to fetch hearings");
}


export async function createHearing(hearingData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings`, {
    method: "POST",
    body: JSON.stringify(hearingData)
  });
  return handleResponse(response, "Failed to create hearing");
}


export async function updateHearing(hearingId, hearingData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings/${hearingId}`, {
    method: "PUT",
    body: JSON.stringify(hearingData)
  });
  return handleResponse(response, "Failed to update hearing");
}


export async function deleteHearing(hearingId) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/hearings/${hearingId}`, {
    method: "DELETE"
  });
  return handleResponse(response, "Failed to delete hearing");
}


// ==================================================
// RECORD SERVICE (:8083) — DOCUMENTS
// ==================================================

export async function getDocuments() {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents`);
  return handleResponse(response, "Failed to fetch documents");
}


export async function createDocument(documentData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents`, {
    method: "POST",
    body: JSON.stringify(documentData)
  });
  return handleResponse(response, "Failed to create document");
}


export async function updateDocument(documentId, documentData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents/${documentId}`, {
    method: "PUT",
    body: JSON.stringify(documentData)
  });
  return handleResponse(response, "Failed to update document");
}


export async function deleteDocument(documentId) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/documents/${documentId}`, {
    method: "DELETE"
  });
  return handleResponse(response, "Failed to delete document");
}


// ==================================================
// RECORD SERVICE (:8083) — JUDGMENTS
// ==================================================

export async function getJudgments() {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments`);
  return handleResponse(response, "Failed to fetch judgments");
}


export async function createJudgment(judgmentData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments`, {
    method: "POST",
    body: JSON.stringify(judgmentData)
  });
  return handleResponse(response, "Failed to create judgment");
}


export async function updateJudgment(judgmentId, judgmentData) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments/${judgmentId}`, {
    method: "PUT",
    body: JSON.stringify(judgmentData)
  });
  return handleResponse(response, "Failed to update judgment");
}


export async function deleteJudgment(judgmentId) {
  const response = await serviceFetch(`${RECORD_SERVICE_URL}/records/judgments/${judgmentId}`, {
    method: "DELETE"
  });
  return handleResponse(response, "Failed to delete judgment");
}


// ==================================================
// ANALYTICS (FastAPI :8000 — still used for analytics)
// ==================================================

export async function getAnalytics() {

  const response = await authFetch(
    `${API_URL}/analytics/overview`
  );

  return handleResponse(
    response,
    "Failed to fetch analytics"
  );
}
