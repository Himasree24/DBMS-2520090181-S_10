package com.legalcase.user.entity;

import jakarta.persistence.*;

@Entity
@Table(name = "lawyers")
public class Lawyer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "lawyer_id")
    private Integer lawyerId;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @Column(name = "bar_registration_no", unique = true, length = 80)
    private String barRegistrationNo;

    @Column(name = "specialization", length = 100)
    private String specialization;

    @Column(name = "years_experience")
    private Integer yearsExperience;

    @Column(name = "phone", length = 30)
    private String phone;

    public Lawyer() {
    }

    public Integer getLawyerId() {
        return lawyerId;
    }

    public void setLawyerId(Integer lawyerId) {
        this.lawyerId = lawyerId;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getBarRegistrationNo() {
        return barRegistrationNo;
    }

    public void setBarRegistrationNo(String barRegistrationNo) {
        this.barRegistrationNo = barRegistrationNo;
    }

    public String getSpecialization() {
        return specialization;
    }

    public void setSpecialization(String specialization) {
        this.specialization = specialization;
    }

    public Integer getYearsExperience() {
        return yearsExperience;
    }

    public void setYearsExperience(Integer yearsExperience) {
        this.yearsExperience = yearsExperience;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
