import React, { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FolderOpen,
  Hourglass,
  CalendarDays,
  FileText,
  Plus,
} from 'lucide-react';
import {
  PieChart, Pie, Cell, ResponsiveContainer, Tooltip,
  LineChart, Line, XAxis, YAxis, CartesianGrid,
} from 'recharts';
import MetricCard from '../../components/ui/MetricCard.jsx';
import StatusBadge from '../../components/ui/StatusBadge.jsx';
import SearchBar from '../../components/ui/SearchBar.jsx';
import FilterDropdown from '../../components/ui/FilterDropdown.jsx';
import { useApp } from '../../context/AppContext.jsx';

const PIE_COLORS = ['#181931', '#662249', '#A34054'];

export default function LawyerDashboard() {
  const navigate = useNavigate();
  const { casesList, analyticsData, user } = useApp();
  const [caseSearch, setCaseSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [typeFilter, setTypeFilter] = useState('');

  // Get lawyer_id from authenticated user (support both snake_case and camelCase)
  const lawyerId = user?.lawyer_id ? String(user.lawyer_id) : (user?.lawyerId ? String(user.lawyerId) : null);

  // Filter cases for this lawyer
  const myCases = useMemo(() => {
    if (!lawyerId) return [];
    return casesList.filter((c) => c.lawyerId === lawyerId);
  }, [casesList, lawyerId]);

  const activeCount = myCases.filter((c) => c.status === 'Active').length;
  const pendingCount = myCases.filter((c) => c.status === 'Pending').length;
  const closedCount = myCases.filter((c) => c.status === 'Closed').length;

  // Use analytics data for hearings count
  const upcomingCount = analyticsData?.total_hearings || 0;

  const caseStatusData = [
    { name: 'Active', value: activeCount },
    { name: 'Pending', value: pendingCount },
    { name: 'Closed', value: closedCount },
  ];

  // Use analytics data for hearing stats
  const hearingStatsData = analyticsData?.hearings_by_month || [];

  const filteredCases = useMemo(() => {
    return myCases.filter((c) => {
      const s = caseSearch.toLowerCase();
      const matchesText = c.id.toLowerCase().includes(s) || c.title.toLowerCase().includes(s);
      const matchesStatus = !statusFilter || c.status === statusFilter;
      const matchesType = !typeFilter || c.type === typeFilter;
      return matchesText && matchesStatus && matchesType;
    });
  }, [myCases, caseSearch, statusFilter, typeFilter]);

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  }, []);

  return (
    <div className="page">
      <div className="page-header">
        <h1>{greeting}, Advocate.</h1>
        <div className="subtitle">Here's an overview of your cases and upcoming activities.</div>
      </div>

      <div className="metrics-grid">
        <MetricCard icon={<FolderOpen size={20} />} label="Active Cases" value={activeCount} info="in progress" tone="burgundy" onClick={() => navigate('/lawyer/cases?status=Active')} />
        <MetricCard icon={<Hourglass size={20} />} label="Pending Cases" value={pendingCount} info="awaiting action" tone="amber" onClick={() => navigate('/lawyer/cases?status=Pending')} />
        <MetricCard icon={<CalendarDays size={20} />} label="Total Hearings" value={upcomingCount} info="across your cases" tone="violet" onClick={() => navigate('/lawyer/hearings')} />
        <MetricCard icon={<FileText size={20} />} label="Documents" value={analyticsData?.total_documents || 0} info="across your cases" tone="navy" onClick={() => navigate('/lawyer/documents')} />
      </div>

      <div className="grid-2-1">
        <div className="chart-card">
          <div className="section-title">My Cases</div>
          <div className="section-sub" style={{ marginBottom: 16 }}>Cases assigned to you</div>
          <div className="table-wrap" style={{ boxShadow: 'none' }}>
            <table className="data-table" style={{ minWidth: '680px' }}>
              <thead>
                <tr>
                  <th>Case ID</th>
                  <th>Case</th>
                  <th>Type</th>
                  <th>Status</th>
                  <th>Filing Date</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {filteredCases.map((c) => (
                  <tr key={c.dbId}>
                    <td className="cell-tight">
                      <button className="link-cell" onClick={() => navigate(`/lawyer/cases/${c.id}`)}>{c.id}</button>
                    </td>
                    <td>{c.title}</td>
                    <td className="cell-muted">{c.type}</td>
                    <td><StatusBadge status={c.status} /></td>
                    <td className="cell-tight">{c.filingDate}</td>
                    <td>
                      <button className="btn btn-outline btn-sm" onClick={() => navigate(`/lawyer/cases/${c.id}`)}>Open</button>
                    </td>
                  </tr>
                ))}
                {filteredCases.length === 0 && (
                  <tr><td colSpan={6}><div className="empty-state"><h4>No cases found</h4></div></td></tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="chart-card clickable-chart" onClick={() => navigate('/lawyer/analytics')}>
          <div className="card-title">Case Status Overview</div>
          <div className="card-sub">Current distribution of your case portfolio</div>
          <ResponsiveContainer width="100%" height={220}>
            <PieChart>
              <Pie
                data={caseStatusData}
                dataKey="value"
                nameKey="name"
                innerRadius={60}
                outerRadius={85}
                paddingAngle={2}
                stroke="none"
              >
                {caseStatusData.map((entry, i) => (
                  <Cell key={i} fill={PIE_COLORS[i]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
          <div className="chart-legend" style={{ justifyContent: 'center' }}>
            {caseStatusData.map((d, i) => (
              <div key={d.name} className="legend-item">
                <span className="legend-swatch" style={{ background: PIE_COLORS[i] }} />
                {d.name} · {d.value}
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="chart-card clickable-chart" style={{ marginBottom: 24 }} onClick={() => navigate('/lawyer/analytics')}>
        <div className="section-title">Hearing Statistics</div>
        <div className="section-sub">Hearings per month from your case records</div>
        {hearingStatsData.length > 0 ? (
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={hearingStatsData} margin={{ top: 20, right: 20, left: -10, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#eee8e3" />
              <XAxis dataKey="month" stroke="#9c959e" fontSize={12} />
              <YAxis stroke="#9c959e" fontSize={12} allowDecimals={false} />
              <Tooltip />
              <Line type="monotone" dataKey="hearings" stroke="#662249" strokeWidth={2.5} dot={{ r: 4, fill: '#ED9E5A', strokeWidth: 0 }} activeDot={{ r: 6 }} />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="empty-state">
            <h4>No hearing data available</h4>
            <p>Hearings will appear here once added to your cases.</p>
          </div>
        )}
      </div>

      <div className="section-head">
        <div>
          <div className="section-title">My Cases</div>
          <div className="section-sub">Cases assigned to you</div>
        </div>
        <button className="btn btn-primary" onClick={() => navigate('/lawyer/cases')}>
          <Plus size={16} /> View All
        </button>
      </div>

      <div className="toolbar">
        <SearchBar value={caseSearch} onChange={setCaseSearch} placeholder="Search cases..." />
        <FilterDropdown label="Status" value={statusFilter} onChange={setStatusFilter} options={['Active', 'Pending', 'Closed']} />
        <FilterDropdown label="Type" value={typeFilter} onChange={setTypeFilter} options={['Civil', 'Criminal', 'Property', 'Family', 'Corporate']} />
      </div>

      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Case ID</th>
              <th>Case Title</th>
              <th>Case Type</th>
              <th>Status</th>
              <th>Filing Date</th>
            </tr>
          </thead>
          <tbody>
            {filteredCases.map((c) => (
              <tr key={c.dbId} style={{ cursor: 'pointer' }} onClick={() => navigate(`/lawyer/cases/${c.id}`)}>
                <td className="cell-tight">{c.id}</td>
                <td>{c.title}</td>
                <td className="cell-muted">{c.type}</td>
                <td><StatusBadge status={c.status} /></td>
                <td className="cell-tight">{c.filingDate}</td>
              </tr>
            ))}
            {filteredCases.length === 0 && (
              <tr><td colSpan={5}><div className="empty-state"><h4>No cases found</h4><p>Try adjusting your search or filters.</p></div></td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
