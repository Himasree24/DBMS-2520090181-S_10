package com.legalcase.caseservice.dto;

import java.time.LocalDate;

public class CaseResponse {

    private Integer caseId;
    private Integer clientId;
    private Integer lawyerId;
    private String caseNumber;
    private String title;
    private String caseType;
    private String description;
    private String status;
    private LocalDate filingDate;
    private String courtName;

    public CaseResponse() {
    }

    public CaseResponse(Integer caseId, Integer clientId, Integer lawyerId, String caseNumber,
                        String title, String caseType, String description, String status,
                        LocalDate filingDate, String courtName) {
        this.caseId = caseId;
        this.clientId = clientId;
        this.lawyerId = lawyerId;
        this.caseNumber = caseNumber;
        this.title = title;
        this.caseType = caseType;
        this.description = description;
        this.status = status;
        this.filingDate = filingDate;
        this.courtName = courtName;
    }

    public Integer getCaseId() {
        return caseId;
    }

    public void setCaseId(Integer caseId) {
        this.caseId = caseId;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public Integer getLawyerId() {
        return lawyerId;
    }

    public void setLawyerId(Integer lawyerId) {
        this.lawyerId = lawyerId;
    }

    public String getCaseNumber() {
        return caseNumber;
    }

    public void setCaseNumber(String caseNumber) {
        this.caseNumber = caseNumber;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getCaseType() {
        return caseType;
    }

    public void setCaseType(String caseType) {
        this.caseType = caseType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public LocalDate getFilingDate() {
        return filingDate;
    }

    public void setFilingDate(LocalDate filingDate) {
        this.filingDate = filingDate;
    }

    public String getCourtName() {
        return courtName;
    }

    public void setCourtName(String courtName) {
        this.courtName = courtName;
    }
}
