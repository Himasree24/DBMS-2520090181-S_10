import React, { useMemo, useState } from 'react';
import { FileText, Download, Eye, CheckCircle2 } from 'lucide-react';
import SearchBar from '../../components/ui/SearchBar.jsx';
import FilterDropdown from '../../components/ui/FilterDropdown.jsx';
import Modal from '../../components/ui/Modal.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function ClientDocuments() {
  const { casesList, documentsList, pushToast, user, documentsLoading } = useApp();
  const [search, setSearch] = useState('');
  const [type, setType] = useState('');
  const [previewDoc, setPreviewDoc] = useState(null);

  const clientId = user?.client_id ? String(user.client_id) : null;

  const docs = useMemo(() => {
    const myCases = clientId
      ? casesList.filter((c) => c.clientId === clientId)
      : [];
    const ids = new Set(myCases.map((c) => c.id));
    return documentsList
      .filter((d) => {
        const c = casesList.find((cs) => cs.dbId === d.case_id);
        return c && ids.has(c.id);
      })
      .filter((d) => {
        const s = search.toLowerCase();
        const matchesText = (d.document_name || '').toLowerCase().includes(s) || (d.document_type || '').toLowerCase().includes(s);
        const matchesType = !type || d.document_type === type;
        return matchesText && matchesType;
      });
  }, [casesList, documentsList, search, type, clientId]);

  const handleDownload = () => {
    pushToast('Document download started.');
  };

  if (documentsLoading) {
    return (
      <div className="page">
        <div className="page-header">
          <h1>Documents</h1>
          <div className="subtitle">Loading documents...</div>
        </div>
        <div className="empty-state">Loading documents...</div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header">
        <h1>Documents</h1>
        <div className="subtitle">Documents shared with you for your cases.</div>
      </div>

      <div className="toolbar">
        <SearchBar value={search} onChange={setSearch} placeholder="Search documents..." />
        <FilterDropdown label="Type" value={type} onChange={setType} options={['Petition', 'Evidence', 'Court Order', 'Hearing Notice', 'Affidavit', 'Agreement']} />
      </div>

      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Document</th>
              <th>Case</th>
              <th>Type</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {docs.map((d) => {
              const c = casesList.find((cs) => cs.dbId === d.case_id);
              return (
                <tr key={d.document_id}>
                  <td style={{ fontWeight: 500 }}>{d.document_name}</td>
                  <td className="cell-tight">{c?.title}</td>
                  <td className="cell-muted">{d.document_type}</td>
                  <td className="cell-tight">{d.upload_date}</td>
                  <td className="cell-tight">
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button className="btn btn-outline btn-sm" onClick={() => setPreviewDoc(d)}><Eye size={14} /> View</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => handleDownload(d)}><Download size={14} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {docs.length === 0 && (
              <tr><td colSpan={5}><div className="empty-state"><FileText size={38} /><h4>No documents found</h4><p>Try adjusting your search or filters.</p></div></td></tr>
            )}
          </tbody>
        </table>
      </div>

      <Modal
        open={!!previewDoc}
        onClose={() => setPreviewDoc(null)}
        title={previewDoc ? previewDoc.document_name : 'Document'}
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setPreviewDoc(null)}>Close</button>
            <button className="btn btn-primary" onClick={() => handleDownload(previewDoc)}>
              <Download size={15} /> Download
            </button>
          </>
        }
      >
        {previewDoc && (
          <div className="doc-preview">
            <div className="doc-preview-icon"><FileText size={34} /></div>
            <div className="doc-preview-meta">
              <div><span className="label">Type</span><span className="value">{previewDoc.document_type}</span></div>
              <div><span className="label">Case</span><span className="value">{previewDoc.case_id}</span></div>
              <div><span className="label">Uploaded By</span><span className="value">{previewDoc.uploaded_by}</span></div>
              <div><span className="label">Date</span><span className="value">{previewDoc.upload_date}</span></div>
            </div>
            <div className="doc-preview-body">
              <CheckCircle2 size={18} />
              <span>Document preview is simulated in this demo. In a production build, the actual file would be rendered here.</span>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
