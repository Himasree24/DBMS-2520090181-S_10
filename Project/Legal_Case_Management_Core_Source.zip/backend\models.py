from sqlalchemy import (
    Column,
    Integer,
    String,
    Text,
    Date,
    Time,
    DateTime,
    ForeignKey
)
from sqlalchemy.sql import func

from database import Base


# =========================
# USER
# =========================

class User(Base):
    __tablename__ = "users"

    user_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    full_name = Column(
        String(120),
        nullable=False
    )

    email = Column(
        String(150),
        unique=True,
        nullable=False
    )

    password_hash = Column(
        String(255),
        nullable=False
    )

    role = Column(
        String(30),
        nullable=False
    )


# =========================
# CLIENT
# =========================

class Client(Base):
    __tablename__ = "clients"

    client_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    user_id = Column(
        Integer,
        ForeignKey("users.user_id"),
        nullable=False
    )

    address = Column(
        String(255)
    )

    phone = Column(
        String(30)
    )

    created_at = Column(
        DateTime,
        server_default=func.now()
    )


# =========================
# LAWYER
# =========================

class Lawyer(Base):
    __tablename__ = "lawyers"

    lawyer_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    user_id = Column(
        Integer,
        ForeignKey("users.user_id"),
        nullable=False
    )

    bar_registration_no = Column(
        String(80),
        unique=True
    )

    specialization = Column(
        String(100)
    )

    years_experience = Column(
        Integer
    )

    phone = Column(
        String(30)
    )


# =========================
# JUDGE
# =========================

class Judge(Base):
    __tablename__ = "judges"

    judge_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    full_name = Column(
        String(120),
        nullable=False
    )

    court_name = Column(
        String(150)
    )

    appointment_date = Column(
        Date
    )


# =========================
# CASE
# =========================

class Case(Base):
    __tablename__ = "cases"

    case_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    client_id = Column(
        Integer,
        ForeignKey("clients.client_id"),
        nullable=False
    )

    lawyer_id = Column(
        Integer,
        ForeignKey("lawyers.lawyer_id"),
        nullable=False
    )

    case_number = Column(
        String(50),
        unique=True
    )

    title = Column(
        String(200)
    )

    case_type = Column(
        String(60)
    )

    description = Column(
        Text
    )

    status = Column(
        String(30)
    )

    filing_date = Column(
        Date
    )

    court_name = Column(
        String(150)
    )


# =========================
# HEARING
# =========================

class Hearing(Base):
    __tablename__ = "hearings"

    hearing_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    case_id = Column(
        Integer,
        ForeignKey("cases.case_id"),
        nullable=False
    )

    judge_id = Column(
        Integer,
        ForeignKey("judges.judge_id"),
        nullable=False
    )

    hearing_date = Column(
        Date
    )

    hearing_time = Column(
        Time
    )

    court_room = Column(
        String(50)
    )

    purpose = Column(
        String(150)
    )

    status = Column(
        String(30)
    )

    remarks = Column(
        Text
    )


# =========================
# DOCUMENT
# =========================

class Document(Base):
    __tablename__ = "documents"

    document_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    case_id = Column(
        Integer,
        ForeignKey("cases.case_id"),
        nullable=False
    )

    document_name = Column(
        String(255)
    )

    document_type = Column(
        String(60)
    )

    uploaded_by = Column(
        Integer,
        ForeignKey("users.user_id")
    )

    upload_date = Column(
        DateTime,
        server_default=func.now()
    )

    file_path = Column(
        String(500)
    )


# =========================
# JUDGMENT
# =========================

class Judgment(Base):
    __tablename__ = "judgments"

    judgment_id = Column(
        Integer,
        primary_key=True,
        index=True
    )

    case_id = Column(
        Integer,
        ForeignKey("cases.case_id"),
        unique=True,
        nullable=False
    )

    judgment_date = Column(
        Date
    )

    decision = Column(
        String(100)
    )

    summary = Column(
        Text
    )

    remarks = Column(
        Text
    )