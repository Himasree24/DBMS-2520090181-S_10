from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy.exc import IntegrityError

from database import get_db
from models import Case, Client, Lawyer
from schemas import CaseCreate, CaseResponse

from auth import get_current_user


# ==================================================
# ROUTER
# ==================================================

router = APIRouter(
    prefix="/cases",
    tags=["Cases"]
)


# ==================================================
# GET ALL CASES
# ==================================================

@router.get("/", response_model=list[CaseResponse])
def get_cases(
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    """
    Get cases based on the logged-in user's role.
    - Lawyers see all cases.
    - Clients see only their own cases.
    """
    if current_user.role == "lawyer":
        cases = db.query(Case).all()
    elif current_user.role == "client":
        # Get the client's client_id
        client = db.query(Client).filter(
            Client.user_id == current_user.user_id
        ).first()
        if not client:
            return []
        cases = db.query(Case).filter(
            Case.client_id == client.client_id
        ).all()
    else:
        raise HTTPException(
            status_code=403,
            detail="Access denied"
        )

    return cases


# ==================================================
# GET ONE CASE
# ==================================================

@router.get("/{case_id}", response_model=CaseResponse)
def get_case(
    case_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    case = (
        db.query(Case)
        .filter(Case.case_id == case_id)
        .first()
    )

    if not case:
        raise HTTPException(
            status_code=404,
            detail="Case not found"
        )

    # Check access
    if current_user.role == "client":
        client = db.query(Client).filter(
            Client.user_id == current_user.user_id
        ).first()
        if not client or case.client_id != client.client_id:
            raise HTTPException(
                status_code=403,
                detail="Access denied"
            )

    return case


# ==================================================
# CREATE CASE
# ==================================================

@router.post(
    "/",
    response_model=CaseResponse
)
def create_case(
    case_data: CaseCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    # Only lawyers can create cases
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can create cases"
        )

    # Verify the lawyer exists
    lawyer = db.query(Lawyer).filter(
        Lawyer.user_id == current_user.user_id
    ).first()
    if not lawyer:
        raise HTTPException(
            status_code=403,
            detail="Lawyer profile not found"
        )

    # Verify the client exists
    client = db.query(Client).filter(
        Client.client_id == case_data.client_id
    ).first()
    if not client:
        raise HTTPException(
            status_code=400,
            detail="Client not found"
        )

    new_case = Case(
        client_id=case_data.client_id,
        lawyer_id=lawyer.lawyer_id,
        case_number=case_data.case_number,
        title=case_data.title,
        case_type=case_data.case_type,
        description=case_data.description,
        status=case_data.status,
        filing_date=case_data.filing_date,
        court_name=case_data.court_name
    )

    try:
        db.add(new_case)
        db.commit()
        db.refresh(new_case)
        return new_case
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail=(
                "Could not create case. "
                "Make sure the client_id and lawyer_id "
                "exist in the database."
            )
        )


# ==================================================
# UPDATE CASE
# ==================================================

@router.put(
    "/{case_id}",
    response_model=CaseResponse
)
def update_case(
    case_id: int,
    case_data: CaseCreate,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    # Only lawyers can update cases
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can update cases"
        )

    case = (
        db.query(Case)
        .filter(Case.case_id == case_id)
        .first()
    )

    if not case:
        raise HTTPException(
            status_code=404,
            detail="Case not found"
        )

    case.client_id = case_data.client_id
    case.lawyer_id = case_data.lawyer_id
    case.case_number = case_data.case_number
    case.title = case_data.title
    case.case_type = case_data.case_type
    case.description = case_data.description
    case.status = case_data.status
    case.filing_date = case_data.filing_date
    case.court_name = case_data.court_name

    try:
        db.commit()
        db.refresh(case)
        return case
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail=(
                "Could not update case. "
                "Make sure the client_id and lawyer_id "
                "exist in the database."
            )
        )


# ==================================================
# DELETE CASE
# ==================================================

@router.delete("/{case_id}")
def delete_case(
    case_id: int,
    db: Session = Depends(get_db),
    current_user=Depends(get_current_user),
):
    # Only lawyers can delete cases
    if current_user.role != "lawyer":
        raise HTTPException(
            status_code=403,
            detail="Only lawyers can delete cases"
        )

    case = (
        db.query(Case)
        .filter(Case.case_id == case_id)
        .first()
    )

    if not case:
        raise HTTPException(
            status_code=404,
            detail="Case not found"
        )

    try:
        db.delete(case)
        db.commit()
        return {
            "message": "Case deleted successfully",
            "case_id": case_id
        }
    except IntegrityError:
        db.rollback()
        raise HTTPException(
            status_code=400,
            detail=(
                "This case cannot be deleted because "
                "it has related hearings, documents, "
                "or judgments."
            )
        )
