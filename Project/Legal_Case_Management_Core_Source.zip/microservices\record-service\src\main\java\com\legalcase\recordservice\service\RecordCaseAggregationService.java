package com.legalcase.recordservice.service;

import com.legalcase.recordservice.client.CaseServiceClient;
import com.legalcase.recordservice.dto.*;
import com.legalcase.recordservice.entity.Document;
import com.legalcase.recordservice.entity.Hearing;
import com.legalcase.recordservice.entity.Judgment;
import com.legalcase.recordservice.repository.DocumentRepository;
import com.legalcase.recordservice.repository.HearingRepository;
import com.legalcase.recordservice.repository.JudgmentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Map;

/**
 * Service that aggregates record data with case information
 * by calling Case Service through HTTP REST API.
 */
@Service
public class RecordCaseAggregationService {

    private final HearingRepository hearingRepository;
    private final DocumentRepository documentRepository;
    private final JudgmentRepository judgmentRepository;
    private final CaseServiceClient caseServiceClient;

    public RecordCaseAggregationService(HearingRepository hearingRepository,
                                        DocumentRepository documentRepository,
                                        JudgmentRepository judgmentRepository,
                                        CaseServiceClient caseServiceClient) {
        this.hearingRepository = hearingRepository;
        this.documentRepository = documentRepository;
        this.judgmentRepository = judgmentRepository;
        this.caseServiceClient = caseServiceClient;
    }

    /**
     * Get a hearing with aggregated case information from Case Service.
     */
    public HearingWithCaseResponse getHearingWithCase(Integer hearingId) {
        // Step 1: Load hearing from local database
        Hearing hearing = hearingRepository.findById(hearingId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Hearing not found with id: " + hearingId));

        // Step 2: Call Case Service to get case information
        Map<String, Object> caseInfo = caseServiceClient.getCaseById(hearing.getCaseId());
        if (caseInfo == null) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                "Unable to retrieve case information from Case Service");
        }

        // Step 3: Build combined response
        HearingWithCaseResponse.HearingInfo hearingInfo = new HearingWithCaseResponse.HearingInfo(
            hearing.getHearingId(),
            hearing.getCaseId(),
            hearing.getJudgeId(),
            hearing.getHearingDate(),
            hearing.getHearingTime(),
            hearing.getCourtRoom(),
            hearing.getPurpose(),
            hearing.getStatus(),
            hearing.getRemarks()
        );

        return new HearingWithCaseResponse(hearingInfo, caseInfo);
    }

    /**
     * Get a document with aggregated case information from Case Service.
     */
    public DocumentWithCaseResponse getDocumentWithCase(Integer documentId) {
        // Step 1: Load document from local database
        Document document = documentRepository.findById(documentId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Document not found with id: " + documentId));

        // Step 2: Call Case Service to get case information
        Map<String, Object> caseInfo = caseServiceClient.getCaseById(document.getCaseId());
        if (caseInfo == null) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                "Unable to retrieve case information from Case Service");
        }

        // Step 3: Build combined response
        DocumentWithCaseResponse.DocumentInfo documentInfo = new DocumentWithCaseResponse.DocumentInfo(
            document.getDocumentId(),
            document.getCaseId(),
            document.getDocumentName(),
            document.getDocumentType(),
            document.getUploadedBy(),
            document.getUploadDate(),
            document.getFilePath()
        );

        return new DocumentWithCaseResponse(documentInfo, caseInfo);
    }

    /**
     * Get a judgment with aggregated case information from Case Service.
     */
    public JudgmentWithCaseResponse getJudgmentWithCase(Integer judgmentId) {
        // Step 1: Load judgment from local database
        Judgment judgment = judgmentRepository.findById(judgmentId)
            .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Judgment not found with id: " + judgmentId));

        // Step 2: Call Case Service to get case information
        Map<String, Object> caseInfo = caseServiceClient.getCaseById(judgment.getCaseId());
        if (caseInfo == null) {
            throw new ResponseStatusException(HttpStatus.SERVICE_UNAVAILABLE,
                "Unable to retrieve case information from Case Service");
        }

        // Step 3: Build combined response
        JudgmentWithCaseResponse.JudgmentInfo judgmentInfo = new JudgmentWithCaseResponse.JudgmentInfo(
            judgment.getJudgmentId(),
            judgment.getCaseId(),
            judgment.getJudgmentDate(),
            judgment.getDecision(),
            judgment.getSummary(),
            judgment.getRemarks()
        );

        return new JudgmentWithCaseResponse(judgmentInfo, caseInfo);
    }

    /**
     * Validate that a case exists by calling Case Service.
     */
    public boolean validateCaseExists(Integer caseId) {
        if (caseId == null) {
            return true;
        }
        return caseServiceClient.getCaseById(caseId) != null;
    }
}
