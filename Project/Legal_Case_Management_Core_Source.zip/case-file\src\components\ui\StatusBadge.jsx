import React from 'react';

const map = {
  active: { cls: 'badge-active', dot: true },
  pending: { cls: 'badge-pending', dot: true },
  closed: { cls: 'badge-closed', dot: true },
  upcoming: { cls: 'badge-upcoming', dot: true },
  completed: { cls: 'badge-completed', dot: true },
  postponed: { cls: 'badge-postponed', dot: true },
  delivered: { cls: 'badge-delivered', dot: true },
  won: { cls: 'badge-won', dot: true },
  lost: { cls: 'badge-lost', dot: true },
  partially: { cls: 'badge-partial', dot: true },
  verified: { cls: 'badge-verified', dot: true },
  review: { cls: 'badge-review', dot: true },
};

function keyFor(value) {
  const v = String(value).toLowerCase();
  if (v.includes('won')) return 'won';
  if (v.includes('lost')) return 'lost';
  if (v.includes('partial')) return 'partially';
  if (v.includes('verif')) return 'verified';
  if (v.includes('review')) return 'review';
  if (v.includes('clos')) return 'closed';
  if (v.includes('postpon')) return 'postponed';
  return v;
}

export default function StatusBadge({ status }) {
  const k = keyFor(status);
  const conf = map[k] || { cls: 'badge-active', dot: true };
  return (
    <span className={`badge ${conf.cls}`}>
      {conf.dot && <span className="badge-dot" />}
      {status}
    </span>
  );
}
