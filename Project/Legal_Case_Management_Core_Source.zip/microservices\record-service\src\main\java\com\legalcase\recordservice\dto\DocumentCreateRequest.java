package com.legalcase.recordservice.dto;

import jakarta.validation.constraints.NotNull;

public class DocumentCreateRequest {

    @NotNull(message = "Case ID is required")
    private Integer caseId;

    private String documentName;
    private String documentType;
    private Integer uploadedBy;
    private String filePath;

    public DocumentCreateRequest() {
    }

    public Integer getCaseId() { return caseId; }
    public void setCaseId(Integer caseId) { this.caseId = caseId; }
    public String getDocumentName() { return documentName; }
    public void setDocumentName(String documentName) { this.documentName = documentName; }
    public String getDocumentType() { return documentType; }
    public void setDocumentType(String documentType) { this.documentType = documentType; }
    public Integer getUploadedBy() { return uploadedBy; }
    public void setUploadedBy(Integer uploadedBy) { this.uploadedBy = uploadedBy; }
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
}
