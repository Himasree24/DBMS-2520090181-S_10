import React, { useMemo, useState } from 'react';
import { Upload, Eye, Download, FileText, CheckCircle2 } from 'lucide-react';
import SearchBar from '../../components/ui/SearchBar.jsx';
import FilterDropdown from '../../components/ui/FilterDropdown.jsx';
import Modal from '../../components/ui/Modal.jsx';
import DocumentModal from '../../components/ui/DocumentModal.jsx';
import { useApp } from '../../context/AppContext.jsx';

export default function DocumentsPage() {
  const { documentsList, casesList, documentsLoading, addDocument, pushToast, user } = useApp();
  const [search, setSearch] = useState('');
  const [caseFilter, setCaseFilter] = useState('');
  const [type, setType] = useState('');
  const [sort, setSort] = useState('');
  const [uploadOpen, setUploadOpen] = useState(false);
  const [previewDoc, setPreviewDoc] = useState(null);

  const uniqueCases = [...new Set(documentsList.map((d) => d.case_id))];

  const docs = useMemo(() => {
    let list = documentsList.filter((d) => {
      const s = search.toLowerCase();
      const matchesText = (d.document_name || '').toLowerCase().includes(s) || (d.document_type || '').toLowerCase().includes(s);
      const matchesCase = !caseFilter || d.case_id === Number(caseFilter);
      const matchesType = !type || d.document_type === type;
      return matchesText && matchesCase && matchesType;
    });
    if (sort === 'Newest') list = [...list].reverse();
    else if (sort === 'Oldest') list = [...list];
    return list;
  }, [documentsList, search, caseFilter, type, sort]);

  const handleSave = async (newDoc) => {
    try {
      await addDocument({
        case_id: Number(newDoc.caseId),
        document_name: newDoc.name,
        document_type: newDoc.type,
        file_path: null,
      });
      setUploadOpen(false);
      pushToast('Document uploaded successfully.');
    } catch (error) {
      pushToast(error.message || 'Failed to upload document.', 'error');
    }
  };

  const handleDownload = () => {
    pushToast('Document download started.');
  };

  if (documentsLoading) {
    return (
      <div className="page">
        <div className="page-header">
          <h1>Documents</h1>
          <div className="subtitle">Loading documents...</div>
        </div>
        <div className="empty-state">Loading documents...</div>
      </div>
    );
  }

  return (
    <div className="page">
      <div className="page-header" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
          <h1>Documents</h1>
          <div className="subtitle">Manage documents associated with your cases.</div>
        </div>
        <button className="btn btn-primary" onClick={() => setUploadOpen(true)}>
          <Upload size={16} /> Upload Document
        </button>
      </div>

      <div className="toolbar">
        <SearchBar value={search} onChange={setSearch} placeholder="Search documents..." />
        <FilterDropdown label="Case" value={caseFilter} onChange={setCaseFilter} options={uniqueCases.map(String)} />
        <FilterDropdown label="Type" value={type} onChange={setType} options={['Petition', 'Evidence', 'Court Order', 'Hearing Notice', 'Affidavit', 'Agreement']} />
        <FilterDropdown label="Sort" value={sort} onChange={setSort} options={['Newest', 'Oldest']} />
      </div>

      <div className="table-wrap">
        <table className="data-table">
          <thead>
            <tr>
              <th>Document</th>
              <th>Case</th>
              <th>Type</th>
              <th>Date</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {docs.map((d) => {
              const c = casesList.find((cs) => cs.dbId === d.case_id);
              return (
                <tr key={d.document_id}>
                  <td style={{ fontWeight: 500 }}>{d.document_name}</td>
                  <td className="cell-tight">{c?.title} <span className="cell-muted" style={{ fontSize: 12 }}>({c?.id || d.case_id})</span></td>
                  <td className="cell-muted">{d.document_type}</td>
                  <td className="cell-tight">{d.upload_date || '—'}</td>
                  <td><span className="badge badge-verified"><span className="badge-dot" />Uploaded</span></td>
                  <td className="cell-tight">
                    <div style={{ display: 'flex', gap: 6 }}>
                      <button className="btn btn-outline btn-sm" onClick={() => setPreviewDoc(d)}><Eye size={14} /> View</button>
                      <button className="btn btn-ghost btn-sm" onClick={() => handleDownload(d)}><Download size={14} /></button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {docs.length === 0 && (
              <tr><td colSpan={6}><div className="empty-state"><h4>No documents found</h4><p>Try adjusting your search or filters.</p></div></td></tr>
            )}
          </tbody>
        </table>
      </div>

      <DocumentModal
        open={uploadOpen}
        count={documentsList.length}
        uploadedBy={user?.full_name || 'Lawyer'}
        onClose={() => setUploadOpen(false)}
        onSave={handleSave}
      />

      <Modal
        open={!!previewDoc}
        onClose={() => setPreviewDoc(null)}
        title={previewDoc ? previewDoc.document_name : 'Document'}
        footer={
          <>
            <button className="btn btn-ghost" onClick={() => setPreviewDoc(null)}>Close</button>
            <button className="btn btn-primary" onClick={() => handleDownload(previewDoc)}>
              <Download size={15} /> Download
            </button>
          </>
        }
      >
        {previewDoc && (
          <div className="doc-preview">
            <div className="doc-preview-icon"><FileText size={34} /></div>
            <div className="doc-preview-meta">
              <div><span className="label">Type</span><span className="value">{previewDoc.document_type}</span></div>
              <div><span className="label">Case</span><span className="value">{previewDoc.case_id}</span></div>
              <div><span className="label">Uploaded By</span><span className="value">{previewDoc.uploaded_by}</span></div>
              <div><span className="label">Date</span><span className="value">{previewDoc.upload_date}</span></div>
            </div>
            <div className="doc-preview-body">
              <CheckCircle2 size={18} />
              <span>Document preview is simulated in this demo. In a production build, the actual file would be rendered here.</span>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
