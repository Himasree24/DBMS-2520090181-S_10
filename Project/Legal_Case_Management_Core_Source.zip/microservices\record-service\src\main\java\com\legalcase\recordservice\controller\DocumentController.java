package com.legalcase.recordservice.controller;

import com.legalcase.recordservice.dto.DocumentCreateRequest;
import com.legalcase.recordservice.dto.DocumentResponse;
import com.legalcase.recordservice.dto.DocumentUpdateRequest;
import com.legalcase.recordservice.dto.DocumentWithCaseResponse;
import com.legalcase.recordservice.service.DocumentService;
import com.legalcase.recordservice.service.RecordCaseAggregationService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class DocumentController {

    private final DocumentService documentService;
    private final RecordCaseAggregationService aggregationService;

    public DocumentController(DocumentService documentService,
                             RecordCaseAggregationService aggregationService) {
        this.documentService = documentService;
        this.aggregationService = aggregationService;
    }

    @GetMapping("/records/documents")
    public List<DocumentResponse> getAllDocuments(
            @RequestParam(required = false) Integer caseId) {
        if (caseId != null) {
            return documentService.getDocumentsByCaseId(caseId);
        }
        return documentService.getAllDocuments();
    }

    @GetMapping("/records/documents/{id}")
    public ResponseEntity<DocumentResponse> getDocumentById(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(documentService.getDocumentById(id));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    // --------------------------------------------------
    // GET DOCUMENT WITH CASE INFO (Service-to-Service)
    // --------------------------------------------------

    @GetMapping("/records/documents/{id}/with-case")
    public ResponseEntity<DocumentWithCaseResponse> getDocumentWithCase(@PathVariable Integer id) {
        try {
            return ResponseEntity.ok(aggregationService.getDocumentWithCase(id));
        } catch (org.springframework.web.server.ResponseStatusException e) {
            return ResponseEntity.status(e.getStatusCode()).build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/records/documents")
    public ResponseEntity<DocumentResponse> createDocument(@Valid @RequestBody DocumentCreateRequest request) {
        DocumentResponse created = documentService.createDocument(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/records/documents/{id}")
    public ResponseEntity<DocumentResponse> updateDocument(@PathVariable Integer id,
                                                           @Valid @RequestBody DocumentUpdateRequest request) {
        try {
            return ResponseEntity.ok(documentService.updateDocument(id, request));
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/records/documents/{id}")
    public ResponseEntity<Void> deleteDocument(@PathVariable Integer id) {
        try {
            documentService.deleteDocument(id);
            return ResponseEntity.noContent().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
