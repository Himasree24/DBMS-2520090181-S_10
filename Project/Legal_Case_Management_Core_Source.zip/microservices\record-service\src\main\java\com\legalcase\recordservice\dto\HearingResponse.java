package com.legalcase.recordservice.dto;

import java.time.LocalDate;
import java.time.LocalTime;

public class HearingResponse {

    private Integer hearingId;
    private Integer caseId;
    private Integer judgeId;
    private LocalDate hearingDate;
    private LocalTime hearingTime;
    private String courtRoom;
    private String purpose;
    private String status;
    private String remarks;

    public HearingResponse() {
    }

    public HearingResponse(Integer hearingId, Integer caseId, Integer judgeId,
                           LocalDate hearingDate, LocalTime hearingTime, String courtRoom,
                           String purpose, String status, String remarks) {
        this.hearingId = hearingId;
        this.caseId = caseId;
        this.judgeId = judgeId;
        this.hearingDate = hearingDate;
        this.hearingTime = hearingTime;
        this.courtRoom = courtRoom;
        this.purpose = purpose;
        this.status = status;
        this.remarks = remarks;
    }

    public Integer getHearingId() { return hearingId; }
    public void setHearingId(Integer hearingId) { this.hearingId = hearingId; }
    public Integer getCaseId() { return caseId; }
    public void setCaseId(Integer caseId) { this.caseId = caseId; }
    public Integer getJudgeId() { return judgeId; }
    public void setJudgeId(Integer judgeId) { this.judgeId = judgeId; }
    public LocalDate getHearingDate() { return hearingDate; }
    public void setHearingDate(LocalDate hearingDate) { this.hearingDate = hearingDate; }
    public LocalTime getHearingTime() { return hearingTime; }
    public void setHearingTime(LocalTime hearingTime) { this.hearingTime = hearingTime; }
    public String getCourtRoom() { return courtRoom; }
    public void setCourtRoom(String courtRoom) { this.courtRoom = courtRoom; }
    public String getPurpose() { return purpose; }
    public void setPurpose(String purpose) { this.purpose = purpose; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
}
