CREATE DATABASE legal_case_management;
USE legal_case_management;
CREATE TABLE users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(30) NOT NULL
);
CREATE TABLE clients (
    client_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    address VARCHAR(255),
    phone VARCHAR(30),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);
CREATE TABLE lawyers (
    lawyer_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    bar_registration_no VARCHAR(80) UNIQUE,
    specialization VARCHAR(100),
    years_experience INT,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);
CREATE TABLE judges (
    judge_id INT AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(120) NOT NULL,
    court_name VARCHAR(150),
    appointment_date DATE
);
CREATE TABLE cases (
    case_id INT AUTO_INCREMENT PRIMARY KEY,
    client_id INT NOT NULL,
    lawyer_id INT NOT NULL,
    case_number VARCHAR(50) UNIQUE,
    title VARCHAR(200),
    case_type VARCHAR(60),
    description TEXT,
    status VARCHAR(30),
    filing_date DATE,
    court_name VARCHAR(150),
    FOREIGN KEY (client_id) REFERENCES clients(client_id),
    FOREIGN KEY (lawyer_id) REFERENCES lawyers(lawyer_id)
);
CREATE TABLE hearings (
    hearing_id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    judge_id INT NOT NULL,
    hearing_date DATE,
    hearing_time TIME,
    court_room VARCHAR(50),
    purpose VARCHAR(150),
    status VARCHAR(30),
    remarks TEXT,
    FOREIGN KEY (case_id) REFERENCES cases(case_id),
    FOREIGN KEY (judge_id) REFERENCES judges(judge_id)
);
CREATE TABLE documents (
    document_id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL,
    document_name VARCHAR(255),
    document_type VARCHAR(60),
    uploaded_by INT,
    upload_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    file_path VARCHAR(500),
    FOREIGN KEY (case_id) REFERENCES cases(case_id),
    FOREIGN KEY (uploaded_by) REFERENCES users(user_id)
);
CREATE TABLE judgments (
    judgment_id INT AUTO_INCREMENT PRIMARY KEY,
    case_id INT NOT NULL UNIQUE,
    judgment_date DATE,
    decision VARCHAR(100),
    summary TEXT,
    remarks TEXT,
    FOREIGN KEY (case_id) REFERENCES cases(case_id)
);
SHOW TABLES;
USE legal_case_management;

SELECT * FROM users;
SELECT * FROM clients;
SELECT * FROM lawyers;
SELECT * FROM judges;
SELECT * FROM cases;
USE legal_case_management;

SELECT * FROM clients;
SELECT * FROM lawyers;
SELECT * FROM judges;
USE legal_case_management;

-- Create a client user (password: password123)
INSERT INTO users (full_name, email, password_hash, role)
VALUES ('Rahul Sharma', 'rahul@test.com', '$argon2id$v=19$m=65536,t=3,p=4$K/0fTwXCKVT5xQrFgjaZvw$Od99adf+VpZiDMv116dZ+joBe39OU/QMCfjRrEqpFSw', 'client');

-- Create client profile
INSERT INTO clients (user_id, address, phone)
VALUES (
    LAST_INSERT_ID(),
    'Jubilee Hills, Hyderabad',
    '9988011223'
);

-- Create lawyer profile for your existing lawyer user
INSERT INTO lawyers (
    user_id,
    bar_registration_no,
    specialization,
    years_experience
)
VALUES (
    1,
    'BAR-TS-001',
    'Property & Civil Litigation',
    8
);

-- Create judge
INSERT INTO judges (
    full_name,
    court_name,
    appointment_date
)
VALUES (
    'Justice Anil Kumar',
    'Telangana High Court',
    '2020-01-15'
);

SELECT * FROM users;
SELECT * FROM clients;
SELECT * FROM lawyers;
SELECT * FROM judges;

USE legal_case_management;

INSERT INTO cases (
    client_id,
    lawyer_id,
    case_number,
    title,
    case_type,
    description,
    status,
    filing_date,
    court_name
)
VALUES (
    (SELECT c.client_id
     FROM clients c
     JOIN users u ON c.user_id = u.user_id
     WHERE u.email = 'rahul@test.com'),

    (SELECT l.lawyer_id
     FROM lawyers l
     JOIN users u ON l.user_id = u.user_id
     WHERE u.email = 'lawyer@test.com'),

    'CASE-1024',
    'Property Dispute',
    'Property',
    'Dispute regarding residential property ownership.',
    'Active',
    '2026-08-01',
    'Telangana High Court'
);

SELECT * FROM cases;
USE legal_case_management;

INSERT INTO cases (
    client_id,
    lawyer_id,
    case_number,
    title,
    case_type,
    description,
    status,
    filing_date,
    court_name
)
VALUES (
    1,
    1,
    'DB-TEST-001',
    'Database Integration Test',
    'Civil',
    'This case was inserted directly into MySQL to demonstrate database integration.',
    'Active',
    '2026-09-10',
    'Telangana High Court'
);
SELECT * FROM cases;
USE legal_case_management;

SHOW TABLES;
DESCRIBE users;
DESCRIBE clients;
DESCRIBE lawyers;
DESCRIBE judges;
DESCRIBE cases;
DESCRIBE hearings;
DESCRIBE documents;
DESCRIBE judgments;
SELECT * FROM users;
SELECT * FROM clients;
SELECT * FROM lawyers;
SELECT * FROM judges;
SELECT * FROM cases;
SELECT * FROM hearings;
SELECT * FROM documents;
SELECT * FROM judgments;

SELECT * FROM cases
WHERE case_number = '10001';

USE legal_case_management;

INSERT INTO users (full_name, email, password_hash, role)
VALUES
('Priya Reddy', 'priya@test.com', '$argon2id$v=19$m=65536,t=3,p=4$K/0fTwXCKVT5xQrFgjaZvw$Od99adf+VpZiDMv116dZ+joBe39OU/QMCfjRrEqpFSw', 'client'),
('Arjun Mehta', 'arjun@test.com', '$argon2id$v=19$m=65536,t=3,p=4$K/0fTwXCKVT5xQrFgjaZvw$Od99adf+VpZiDMv116dZ+joBe39OU/QMCfjRrEqpFSw', 'client'),
('Sneha Rao', 'sneha@test.com', '$argon2id$v=19$m=65536,t=3,p=4$Bucgxd8H0iC64lE7oscraA$SeOczWNT4KZCxvjtGkZdmt9vCzfrSW1PKJXg8gG0bwE', 'lawyer'),
('Vikram Singh', 'vikram@test.com', '$argon2id$v=19$m=65536,t=3,p=4$Bucgxd8H0iC64lE7oscraA$SeOczWNT4KZCxvjtGkZdmt9vCzfrSW1PKJXg8gG0bwE', 'lawyer');

INSERT INTO clients (user_id, address, phone)
VALUES
(2, 'Banjara Hills, Hyderabad', '9876543210'),
(3, 'Madhapur, Hyderabad', '9876543211'),
(4, 'Kukatpally, Hyderabad', '9876543212'),
(5, 'Secunderabad, Hyderabad', '9876543213');

INSERT INTO lawyers
(user_id, bar_registration_no, specialization, years_experience)
VALUES
(4, 'BAR-TS-002', 'Criminal Law', 6),
(5, 'BAR-TS-003', 'Family Law', 10),
(6, 'BAR-TS-004', 'Corporate Law', 12),
(7, 'BAR-TS-005', 'Cyber Law', 5);
INSERT INTO judges
(full_name, court_name, appointment_date)
VALUES
('Justice Priya Sharma', 'Telangana High Court', '2019-06-20'),
('Justice Ramesh Rao', 'Hyderabad District Court', '2021-03-15'),
('Justice Kavita Reddy', 'Secunderabad District Court', '2018-11-10'),
('Justice Suresh Kumar', 'Cyberabad Court', '2022-01-25');

INSERT INTO cases
(client_id, lawyer_id, case_number, title, case_type,
 description, status, filing_date, court_name)
VALUES
(2, 2, 'CASE-1002', 'Property Boundary Dispute', 'Property',
 'Dispute regarding property boundaries between two parties.',
 'Active', '2026-08-05', 'Telangana High Court'),

(3, 3, 'CASE-1003', 'Divorce Petition', 'Family',
 'Petition regarding matrimonial dispute.',
 'Under Review', '2026-08-10', 'Hyderabad Family Court'),

(4, 4, 'CASE-1004', 'Cyber Fraud Complaint', 'Cyber Crime',
 'Complaint regarding online financial fraud.',
 'Active', '2026-08-18', 'Cyberabad Court'),

(5, 5, 'CASE-1005', 'Business Contract Dispute', 'Civil',
 'Dispute regarding breach of a business agreement.',
 'Pending', '2026-08-25', 'Hyderabad District Court');
 
 INSERT INTO cases (
    client_id,
    lawyer_id,
    case_number,
    title,
    case_type,
    description,
    status,
    filing_date,
    court_name
)
VALUES (
    1,
    1,
    'CASE-1002',
    'Property Dispute',
    'Civil',
    'Dispute regarding property ownership.',
    'Active',
    '2026-09-11',
    'Telangana High Court'
);

INSERT INTO users (full_name, email, password_hash, role)
VALUES
('Sneha Rao', 'sneha.law@test.com', '$argon2id$v=19$m=65536,t=3,p=4$Bucgxd8H0iC64lE7oscraA$SeOczWNT4KZCxvjtGkZdmt9vCzfrSW1PKJXg8gG0bwE', 'lawyer'),
('Vikram Singh', 'vikram.law@test.com', '$argon2id$v=19$m=65536,t=3,p=4$Bucgxd8H0iC64lE7oscraA$SeOczWNT4KZCxvjtGkZdmt9vCzfrSW1PKJXg8gG0bwE', 'lawyer'),
('Kavya Reddy', 'kavya.law@test.com', '$argon2id$v=19$m=65536,t=3,p=4$Bucgxd8H0iC64lE7oscraA$SeOczWNT4KZCxvjtGkZdmt9vCzfrSW1PKJXg8gG0bwE', 'lawyer'),
('Rohit Sharma', 'rohit.law@test.com', '$argon2id$v=19$m=65536,t=3,p=4$Bucgxd8H0iC64lE7oscraA$SeOczWNT4KZCxvjtGkZdmt9vCzfrSW1PKJXg8gG0bwE', 'lawyer');

SELECT user_id, full_name, email, role
FROM users
WHERE role = 'lawyer';

INSERT INTO lawyers (
    user_id,
    bar_registration_no,
    specialization,
    years_experience
)
VALUES
(6, 'BAR-TS-002', 'Criminal Law', 6),
(7, 'BAR-TS-003', 'Family Law', 10),
(8, 'BAR-TS-004', 'Corporate Law', 12),
(9, 'BAR-TS-005', 'Cyber Law', 5);

INSERT INTO cases (
    client_id,
    lawyer_id,
    case_number,
    title,
    case_type,
    description,
    status,
    filing_date,
    court_name
)
VALUES
(1, 1, 'CASE-1006', 'Property Boundary Dispute', 'Property',
 'Dispute regarding property boundaries.',
 'Active', '2026-09-11', 'Telangana High Court'),

(2, 2, 'CASE-1003', 'Cyber Fraud Case', 'Cyber Crime',
 'Online financial fraud complaint.',
 'Under Review', '2026-09-11', 'Cyberabad Court'),

(3, 3, 'CASE-1004', 'Family Dispute', 'Family',
 'Family property and legal dispute.',
 'Pending', '2026-09-11', 'Hyderabad Family Court'),

(4, 4, 'CASE-1005', 'Business Contract Dispute', 'Civil',
 'Dispute regarding breach of contract.',
 'Active', '2026-09-11', 'Hyderabad District Court');
 USE legal_case_management;

SELECT client_id, user_id
FROM clients;

SELECT lawyer_id, user_id
FROM lawyers;

SELECT case_id, case_number, client_id, lawyer_id
FROM cases;

USE legal_case_management;

INSERT INTO cases (
    client_id,
    lawyer_id,
    case_number,
    title,
    case_type,
    description,
    status,
    filing_date,
    court_name
)
VALUES (
    1,
    1,
    'CASE-1003',
    'Cyber Fraud Complaint',
    'Cyber Crime',
    'Complaint regarding an online financial fraud incident.',
    'Active',
    '2026-09-11',
    'Telangana High Court'
);

USE legal_case_management;

SELECT judge_id, full_name, court_name
FROM judges;

INSERT INTO hearings (
    case_id,
    judge_id,
    hearing_date,
    hearing_time,
    court_room,
    purpose,
    status,
    remarks
)
VALUES
(1, 1, '2026-09-20', '10:30:00',
 'Court Hall 1', 'Initial Hearing', 'Scheduled',
 'Initial arguments will be presented.'),

(2, 2, '2026-09-22', '11:00:00',
 'Court Hall 2', 'Evidence Submission', 'Scheduled',
 'Property documents will be submitted.'),

(5, 3, '2026-09-24', '12:00:00',
 'Court Hall 3', 'Case Review', 'Scheduled',
 'Both parties will appear.'),

(10, 4, '2026-09-26', '10:00:00',
 'Court Hall 4', 'Investigation Review', 'Scheduled',
 'Investigation progress will be reviewed.'),

(11, 5, '2026-09-28', '11:30:00',
 'Court Hall 5', 'Final Arguments', 'Scheduled',
 'Final arguments will be presented.');
 
 USE legal_case_management;

SELECT case_id, case_number, title
FROM cases;

SELECT judge_id, full_name, court_name
FROM judges;

USE legal_case_management;

INSERT INTO hearings (
    case_id,
    judge_id,
    hearing_date,
    hearing_time,
    court_room,
    purpose,
    status,
    remarks
)
VALUES
(2, 1, '2026-09-20', '10:30:00',
 'Court Hall 1', 'Initial Hearing', 'Scheduled',
 'Initial arguments will be presented.'),

(5, 2, '2026-09-22', '11:00:00',
 'Court Hall 2', 'Evidence Submission', 'Scheduled',
 'Evidence documents will be submitted.'),

(10, 3, '2026-09-24', '12:00:00',
 'Court Hall 3', 'Case Review', 'Scheduled',
 'Both parties will appear before the court.'),

(19, 4, '2026-09-26', '10:00:00',
 'Court Hall 4', 'Investigation Review', 'Scheduled',
 'Investigation progress will be reviewed.'),

(2, 5, '2026-09-29', '11:30:00',
 'Court Hall 5', 'Final Arguments', 'Scheduled',
 'Final arguments will be presented.');
 
 USE legal_case_management;

SELECT user_id, full_name, email, role
FROM users;
USE legal_case_management;

INSERT INTO documents (
    case_id,
    document_name,
    document_type,
    uploaded_by,
    file_path
)
VALUES
(2, 'Case Application.pdf', 'Application', 1,
 'uploads/case_application.pdf'),

(5, 'Police Report.pdf', 'Police Report', 2,
 'uploads/police_report.pdf'),

(10, 'Property Deed.pdf', 'Legal Document', 5,
 'uploads/property_deed.pdf'),

(19, 'Cyber Crime Complaint.pdf', 'Complaint', 6,
 'uploads/cyber_complaint.pdf'),

(5, 'Evidence Document.pdf', 'Evidence', 1,
 'uploads/evidence_document.pdf');
 
 USE legal_case_management;

INSERT INTO judgments (
    case_id,
    judgment_date,
    decision,
    summary,
    remarks
)
VALUES
(2, '2026-09-05',
 'Case Pending',
 'The court has reviewed the initial submissions.',
 'Further hearing is required.'),

(5, '2026-09-06',
 'Guilty',
 'The court found sufficient evidence supporting the complaint.',
 'Appropriate legal action recommended.'),

(10, '2026-09-07',
 'Pending Decision',
 'The property ownership documents were reviewed.',
 'Final decision will be announced later.'),

(19, '2026-09-10',
 'Under Review',
 'The cyber fraud complaint is currently under judicial review.',
 'Additional evidence may be submitted.');
 
 SELECT 'users' AS table_name, COUNT(*) AS total_rows FROM users
UNION ALL
SELECT 'clients', COUNT(*) FROM clients
UNION ALL
SELECT 'lawyers', COUNT(*) FROM lawyers
UNION ALL
SELECT 'judges', COUNT(*) FROM judges
UNION ALL
SELECT 'cases', COUNT(*) FROM cases
UNION ALL
SELECT 'hearings', COUNT(*) FROM hearings
UNION ALL
SELECT 'documents', COUNT(*) FROM documents
UNION ALL
SELECT 'judgments', COUNT(*) FROM judgments;

USE legal_case_management;

SELECT * FROM users;

SELECT * FROM clients;

SELECT * FROM lawyers;

SELECT * FROM judges;

SELECT * FROM cases;

SELECT * FROM hearings;

SELECT * FROM documents;

SELECT * FROM judgments;

DESCRIBE cases;

USE legal_case_management;

SELECT *
FROM clients
WHERE client_id = 33;

SELECT * FROM clients;
SELECT * FROM lawyers;

USE legal_case_management;

SELECT * FROM users;

SELECT * FROM clients;

SELECT * FROM cases;

USE legal_case_management;

SELECT * FROM cases;

SELECT case_id, case_number, title, status
FROM cases;