package com.legalcase.recordservice.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.Map;

/**
 * HTTP client for Record Service to communicate with Case Service.
 * All calls go through REST APIs - no direct database access.
 */
@Component
public class CaseServiceClient {

    private final RestClient restClient;

    public CaseServiceClient(
            @Value("${case.service.url}") String caseServiceUrl) {
        this.restClient = RestClient.builder()
            .baseUrl(caseServiceUrl)
            .build();
    }

    /**
     * Call Case Service to get case information by ID.
     * Returns null if case not found (404).
     */
    public Map<String, Object> getCaseById(Integer caseId) {
        try {
            return restClient.get()
                .uri("/cases/{id}", caseId)
                .retrieve()
                .body(Map.class);
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Check if Case Service is available.
     */
    public boolean isCaseServiceAvailable() {
        try {
            restClient.get()
                .uri("/cases/health")
                .retrieve()
                .toBodilessEntity();
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}
